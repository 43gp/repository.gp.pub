#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""imgProxy service"""

from collections import namedtuple
from http.server import BaseHTTPRequestHandler, HTTPServer
import json
from socketserver import ThreadingMixIn
import sys
import threading
import time

import requests

try:
    import xbmc
    import xbmcaddon
    __KODI__ = True
except ImportError:
    __KODI__ = False

CONFIG = None

class ProxyHTTPRequestHandler(BaseHTTPRequestHandler):
    """Обработчик HTTP запроса."""
    protocol_version = 'HTTP/1.1'

    ###
    def do_HEAD(self):  # pylint: disable=invalid-name
        """Обработчик HEAD запросов."""
        self.do_GET(body=False)

    ###
    def do_GET(self, body=True):  # pylint: disable=invalid-name
        """Обработчик GET запросов."""
        if not self.path.startswith('/?http'):
            logmessage(f'Bad request "{self.path}"', 2)
            self.send_error(400, 'Bad request')
            return
        url = self.path[2:]
        req_headers = dict(self.headers)
        for key in list(req_headers.keys()):
            if key.lower() == 'host':
                req_headers.pop(key)
                break
        try:
            response = requests.request(
                    'GET' if body else 'HEAD',
                    url,
                    headers=req_headers,
                    timeout=CONFIG.net_timeout,
                    proxies={
                        'http': CONFIG.net_proxy,
                        'https': CONFIG.net_proxy,
                    }
            )
            response.raise_for_status()
        except requests.RequestException as e:
            logmessage(f'{e}', 2)
            try:
                response
            except NameError:
                response = namedtuple(
                        'Response',
                        ['status_code', 'reason', 'content'])(500, str(e).replace('&', '&amp;'), '')
        if response.status_code < 300:
            lvl = 0
            self.send_response(response.status_code)
            for key in response.headers:
                self.send_header(key, response.headers[key])
            self.end_headers()
            if body and response.content:
                try:
                    self.wfile.write(response.content)
                except BrokenPipeError:
                    logmessage(f'client close connection? request was {self.command} {url}', 2)
                    return
        else:
            try:
                self.send_error(response.status_code, response.reason)
            except BrokenPipeError:
                pass
            lvl = 2
        logmessage(
                f'{self.command} {url} {self.request_version} '
                f'{response.status_code} {len(response.content)}',
                lvl
        )

    ###
    def log_message(self, format, *args):  # pylint: disable=redefined-builtin
        pass


class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    """Будем обрабатывать запросы в отдельных потоках."""
    daemon_threads = True


class Monitor(xbmc.Monitor):  #pylint: disable=too-few-public-methods
    """KODI монитор"""
    def onSettingsChanged(self):  # pylint: disable=invalid-name
        """Отслеживаем изменеие настроек аддона."""
        global CONFIG  # pylint: disable=global-statement
        new = configure()
        if not new.net_proxy:
            logmessage('Settings changed, but net_proxy unset', 2)
        elif new.net_proxy == CONFIG.net_proxy and new.net_timeout == CONFIG.net_timeout:
            logmessage('Settings changed, but net_proxy and net_timeout unchanged', 0)
        else:
            CONFIG = new
            logmessage(
                    f'Settings changed: proxy={CONFIG.net_proxy}, '
                    f'timeout={CONFIG.net_timeout}',
                    1
            )

###
def configure():
    """ Читаем настройки и возвращаем их как namedtuple."""
    settings = {}
    if __KODI__:
        config = xbmcaddon.Addon().getSettings()
        settings['net_proxy'] = config.getString('net_proxy')
        settings['net_serverport'] = config.getInt('net_serverport')
        settings['net_timeout'] = config.getInt('net_timeout')
        settings['plugin_imgproxy']  = config.getBool('plugin_imgproxy')
    else:
        try:
            with open('settings.json', 'r', encoding='utf-8') as file:
                loaded = json.load(file)
        except (OSError, json.JSONDecodeError) as err:
            print(f'Cannot load settings.json - {err}')
            sys.exit(1)
        settings['net_proxy'] = loaded.get('net_proxy', '')
        settings['net_serverport'] = loaded.get('net_serverport', 0)
        settings['net_timeout'] = loaded.get('net_timeout', 0)
        settings['plugin_imgproxy'] = loaded.get('plugin_imgproxy', False)
    return namedtuple('Settings', settings.keys())(**settings)

###
def logmessage(msg, lvl=0):
    """Обертка логера."""
    if __KODI__:
        match lvl:
            case 0:
                level = xbmc.LOGDEBUG
            case 1:
                level = xbmc.LOGINFO
            case _:
                level = xbmc.LOGERROR
        xbmc.log(f'imgProxy: {msg}', level)
    else:
        print(msg)

if __name__ == '__main__':
    # Читаем настройки
    CONFIG = configure()
    if not CONFIG.plugin_imgproxy:
        logmessage('Disabled by addon settings. Exiting', 2)
        sys.exit(0)
    if not CONFIG or not CONFIG.net_proxy or not CONFIG.net_serverport:
        logmessage('net_proxy not configured', 2)
        sys.exit(1)
    # Пытаемся запустить сервер.
    server_address = ('127.0.0.1', CONFIG.net_serverport)
    try:
        httpd = ThreadedHTTPServer(server_address, ProxyHTTPRequestHandler)
    except OSError as errno:
        logmessage(f'{errno}', 2)
        sys.exit(1)
    # Запускаем рабочий цикл сервера.
    threading.Thread(target=httpd.serve_forever).start()
    logmessage(f'listen at {server_address[0]}:{server_address[1]}', 1)
    if __KODI__:
        monitor = Monitor()
        while not monitor.abortRequested():
            if monitor.waitForAbort(1):
                logmessage('got shutdown signal', 1)
                break
    else:
        logmessage('Waiting keyboard intterupt', 0)
        try:
            while True:
                time.sleep(60)
        except KeyboardInterrupt:
            pass
    logmessage('waiting threads...', 1)
    threading.Thread(target=httpd.shutdown).start()
    httpd.server_close()
    xbmc.log('exiting', 1)
    sys.exit(0)
