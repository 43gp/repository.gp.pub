# -*- coding: utf-8 -*-
"""GPcache module."""

import json

from debug import Debug
from network import Network, ReqParams
from scraper import Scraper

class GPcache:
    """GPcache class."""
    ###
    def __init__(self, key, proxy):
        Debug.log('G', 2, f'GPcache.init({key}, {proxy})')
        self.base_url = 'https://kodi.gp.spb.su/api/'
        self.net_params = ReqParams(
                 proxy=proxy,
                 headers={
                    'content-type': 'application/json; charset=utf-8',
                    'X-Auth-Key': key
                },
        )

    ###
    def get(self, get_list):
        """Запрашивает info по списку tid из кэша."""
        Debug.log('G', 2, f'GPcache.get(): querying {len(get_list)} info records')
        url = self.base_url + 'get/' + ','.join([str(item['tid']) for item in get_list])
        Debug.log('G', 3, f'GPcache.get(): url={url}')
        response = Network.geturl(url, params=self.net_params)
        if response.status_code != 200:
            Debug.log('G', 0, 'GPcache.get(): request failed.')
            return []
        try:
            data = json.loads(response.text)
        except json.JSONDecodeError as e:
            Debug.log('G', 0, f'GPcache.get(): bad response: {e}')
            return []
        Debug.log('G', 4, f'GPcache.get(): json={response.text}')
        from_gpcache = []
        for entry in data:
            Debug.log('G', 2, f'GPcache.get(): found {entry}')
            if Scraper.is_success(data.get(entry)):
                from_gpcache.append(data.get(entry))
            else:
                Debug.log('G', 0, f'GPcache.get(): BAD info {entry}')
        Debug.log('G', 1, f'GPcache.get(): {len(from_gpcache)} info records received')
        return from_gpcache

    ###
    def set(self, save_list):
        """Отправляет info в кэш."""
        Debug.log('G', 1, f'GPcache.set(): {len(save_list)} info records to save')
        post_dict = {int(item['Id']): item for item in save_list}
        Debug.log('G', 2, f'GPcache.set(): sending {len(post_dict)} info records')
        url = self.base_url + 'post'
        Debug.log('G', 3, f'GPcache.set(): url={url}')
        qparams = self.net_params
        qparams.data = json.dumps(post_dict)
        response = Network.geturl(url, method='POST', params=qparams)
        if response.status_code != 200:
            Debug.log('G', 0, f'GPcache.set(): request failed. {response.status_code} {response.reason}') # pylint: disable=C0301
            Debug.log('G', 3, f'GPcache.set(): data={qparams.data}')
            return
        try:
            data = json.loads(response.text)
        except json.JSONDecodeError as e:
            Debug.log('G', 0, f'GPcache.set(): bad response: {e}')
            return
        Debug.log('G', 1, f'GPcache.set(): {data.get("status")}')
