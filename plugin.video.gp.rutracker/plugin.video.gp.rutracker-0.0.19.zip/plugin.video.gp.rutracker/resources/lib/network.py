# -*- coding: utf-8 -*-
"""
Обертка над requests.
Класс Cookies нужно вызвать до создания потоков и
удалить пока жив класс Cache
"""

from collections import namedtuple
from dataclasses import dataclass
from threading import Lock
import requests

from cache import Cache
from debug import Debug

class Cookies:
    """Cookies class"""
    __init = False
    __changed = False
    __cookies = {}

    ###
    @classmethod
    def __init__(cls):
        Debug.log('N', 3, 'Cookies.init(): Loading cookies')
        if not cls.__cookies:
            cookies = Cache.get('COOKIES')
            if not cookies:
                cookies = {}
            cls.__cookies = cookies
            cls.__init = True

    ###
    @classmethod
    def __del__(cls):
        Debug.log('N', 3, 'Cookies.del()')
        cls.save()

    ###
    def __contains__(self, name):
        return name in self.__cookies

    ###
    @classmethod
    def clear(cls):
        Debug.log('N', 3, 'Cookies.clear()')
        cls.__cookies = {}
        cls.__changed = False
        Cache.add('COOKIES', 0, cls.__cookies)

    ###
    @classmethod
    def get(cls, url):
        """Returns cookies for given url as list()."""
        if not cls.__init:
            cls.__init__()
        start = url.find('://') + 3
        end = url.find('/', start)
        if end == -1:
            end = len(url)
        domain = url[start:end].split('@')[-1].split(':')[0]
        if domain in cls.__cookies:
            ret = cls.__cookies[domain]
        else:
            ret = {}
        Debug.log('N', 3, f'Cookies.get({url}): {domain}={ret}')
        return ret

    ###
    @classmethod
    def save(cls):
        Debug.log('N', 3, 'Cookies.save()')
        if cls.__changed:
            Debug.log('N', 3, 'Cookies.save(): Saving cookies')
            Cache.add('COOKIES', 0, cls.__cookies)
            cls.__changed = False

    ###
    @classmethod
    def set(cls, url, cookies):
        """Set cookies for domain."""
        if not cls.__init:
            cls.__init__()
        start = url.find('://') + 3
        end = url.find('/', start)
        if end == -1:
            end = len(url)
        domain = url[start:end].split('@')[-1].split(':')[0]
        if cls.__cookies.get(domain) != cookies:
            cls.__cookies[domain] = cookies
            cls.__changed = True
        Debug.log('N', 3, f'Cookies.set({url}): {domain}={cookies}')


@dataclass
class ReqAuth:
    """Параметры авторизации."""
    method: str = 'POST'
    url: str = None
    data: str = None
    validator: object = None


@dataclass
class ReqParams:
    """Параметры запроса."""
    proxy: bool = False
    data: str = None
    headers: list = None
    timeout: int = 0


class Network:
    """Обертка над requests."""
    __lock = Lock()
    cookies = None
    counter = 0
    proxy = {}
    session = None
    timeout = 0

    ###
    @classmethod
    def __init__(cls):
        Debug.log('N', 3, "Network.init()")
        if not cls.cookies:
            Debug.log('N', 3, f'Network.init(): Initializing cookies')
            cls.cookies = Cookies()

    ###
    @classmethod
    def __del__(cls):
        Debug.log('N', 3, "Network.del()")
        if cls.cookies:
            del cls.cookies
            cls.cookies = None

    ###
    @classmethod
    def __request(cls, req_id, method, url, params=ReqParams()):
        """Вовращает объект requests.response для url."""
        Debug.log('N', 2, f'Network.request(#{req_id}): url={url}')
        Debug.log('N', 3, f'Network.request(#{req_id}): method={method}')
        Debug.log('N', 3, f'Network.request(#{req_id}): params={params}')
        if params.proxy:
            proxy = cls.proxy
        else:
            proxy = {}
        Debug.log('N', 3, f'Network.request(#{req_id}): proxy={proxy}')
        #
        if not params.timeout:
            timeout = cls.timeout
        else:
            timeout = params.timeout
        Debug.log('N', 3, f'Network.request(#{req_id}): timeout={timeout}')
        #
        if not cls.session:
            Debug.log('N', 3, f'Network.request(#{req_id}): Initializing new session')
            cls.session = requests.Session()
        #
        if not cls.cookies:
            Debug.log('N', 3, f'Network.request(#{req_id}): Initializing cookies')
            cls.cookies = Cookies()
        cls.session.cookies.clear()
        cls.session.cookies.update(Cookies.get(url))
        Debug.log('N', 3, f'Network.request(#{req_id}): Cookies={cls.session.cookies.get_dict()}')
        try:
            response = cls.session.request(
                    method,
                    url,
                    data=params.data,
                    headers=params.headers,
                    timeout=timeout,
                    proxies=proxy
            )
            response.raise_for_status()
        # XXXX: добавить обработку конретных исключений.
        except requests.RequestException as e:
            try:
                response
            except NameError:
                response = namedtuple(
                        'Response',
                        ['status_code', 'reason', 'text', 'content'])(0, e, None, None)
            Debug.log('N', 0, f'Network.request({url}): #{req_id}, Exception - {e}')
        Debug.log('N', 1, f'Network.request(#{req_id}): status={response.status_code}')
        if response.status_code == 200 and Cookies.get(url) != cls.session.cookies.get_dict():
            Cookies.set(url, cls.session.cookies.get_dict())
        return response

    ###
    @classmethod
    def geturl(cls, url, method='GET', params=ReqParams(), auth=ReqAuth()):
        """Выполняет HTTP запрос с проверкой авторизации"""
        cls.__lock.acquire()
        req_id = cls.counter
        cls.counter += 1
        cls.__lock.release()
        Debug.log('N', 1, f'Network.geturl({url}): #{req_id}')
        # выполняем запрос
        response = cls.__request(req_id, method, url, params)
        if response.status_code == 200 and auth.validator and not auth.validator(req_id, response):
            # пытаемся авторизоваться:
            Cookies.set(auth.url, {})
            a_params = ReqParams(params.proxy, auth.data, params.headers, params.timeout)
            cls.__lock.acquire()
            req_id = cls.counter
            cls.counter += 1
            cls.__lock.release()
            a_result = cls.__request(req_id, auth.method, auth.url, a_params)
            if a_result.status_code != 200 or not auth.validator(req_id, a_result):
                Debug.log('N', 0, f'Network.geturl({url}): Authorization Failed')
                return namedtuple(
                        'Response',
                        ['status_code', 'reason', 'text', 'content']
                )(0, 'Authorization Failed', None, None)
            # повторяем исходный запрос.
            cls.__lock.acquire()
            req_id = cls.counter
            cls.counter += 1
            cls.__lock.release()
            response = cls.__request(req_id, method, url, params)
            if response.status_code == 200 and not auth.validator(req_id, response):
                Debug.log('N', 0, f'Network.geturl({url}): Authorization Failed')
                Cookies.set(auth.url, {})
                Cookies.set(url, {})
                return namedtuple(
                        'Response',
                        ['status_code', 'reason', 'text', 'content']
                )(0, 'Authorization Failed', None, None)
        return response

    ###
    @classmethod
    def setproxy(cls, proxy):
        """Устанавливает url прокси сервера."""
        Debug.log('N', 3, f'Network.setproxy({proxy})')
        cls.proxy = {'http': proxy, 'https': proxy}

    ###
    @classmethod
    def settimeout(cls, timeout):
        """Устанавливает таймаут по умолчанию."""
        Debug.log('N', 3, f'Network.settimeout({timeout})')
        cls.timeout = timeout

    ###
    @staticmethod
    def save():
        Cookies.save()

    ###
    @staticmethod
    def clear():
        Cookies.clear()
