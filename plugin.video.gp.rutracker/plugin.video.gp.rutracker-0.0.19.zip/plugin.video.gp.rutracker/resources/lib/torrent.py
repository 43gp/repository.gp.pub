import os

from bencode import bdecode
from cache import Cache
from debug import Debug


class Torrent:
    VALIDMEDIA = (
        '.avi', '.mov', '.mp4', '.mpg', '.mpeg', '.m4v', '.mkv', '.ts', '.wmv', '.m2ts'
    )

    ###
    def __init__(self, base_dir, max_torrents):
        Debug.log('P', 3, f'Torrent.init({base_dir}, {max_torrents})')
        path = os.path.join(base_dir, 'torrents')
        if not os.path.exists(path):
            Debug.log('P', 2, f'Torrent.init(): mkdir({path})')
            Cache.delete('TORRENTS')
            try:
                os.makedirs(path)
            except OSError as e:
                Debug.log('P', 0, f'Torrent.init() makedirs({path}) failed - {e}')
                sys.exit(1)
        self.base_dir = path
        self.max_torrents = max_torrents
        torrents = Cache.get('TORRENTS')
        if not torrents:
            torrents = []
        for torrent in torrents:
            fname = self.getfname(torrent)
            if not os.path.isfile(fname):
                torrents.remove(torrent)
        self.torrents = torrents

    ###
    @staticmethod
    def __convert_size(size):
        units = ['B', 'KB', 'MB', 'GB', 'TB', 'PB']
        for unit in units:
            if size < 1024:
                return f"{size:.2f}{unit}"
            size /= 1024

    ###
    def cache(self, tid):
        Debug.log('P', 3, f'Torrent.cache({tid})')
        if tid in self.torrents:
            self.torrents.remove(tid)
        self.torrents.insert(0, tid)
        while len(self.torrents) > self.max_torrents:
            fname = self.getfname(self.torrents.pop())
            Debug.log('P', 1, f'Torrent.cache({tid}): removing {fname}')
            if os.path.isfile(fname):
                try:
                    os.remove(fname)
                except OSError as e:
                    Debug.log('P', 0, f'Torrent.cache({tid}): removing {fname} failed - {e}')
        Cache.add('TORRENTS', 0, self.torrents)

    ###
    def getfname(self, tid):
        return os.path.join(self.base_dir, str(tid) + '.torrent')

    ###
    def getvideos(self, tid):
        """Returns dict of video files from torrent file."""
        Debug.log('P', 3, f'Torrent.getvideos({tid})')
        # Читаем файл
        with open(self.getfname(tid), 'rb') as file:
            data = file.read()
        # Декодируем
        videos = {}
        try:
            torrent = bdecode(data)
        except BencodeDecodeError as e:
            Debug.log('P', 0, f'Torrent.getvideos({tid}): bdecode - {e}')
            return videos
        # Ищем видео.
        if 'files' not in torrent['info']:
            ext = torrent['info']['name'][torrent['info']['name'].rfind('.'):].lower()
            if ext in Torrent.VALIDMEDIA:
                videos[0] = {}
                videos[0]['size'] = self.__convert_size(torrent['info']['length'])
                if 'name.utf-8' in torrent['info']:
                    videos[0]['name'] = torrent['info']['name.utf-8']
                else:
                    videos[0]['name'] = torrent['info']['name']
            else:
                Debug.log('P', 0, f'Torrent.getvideos({tid}): unsupported file extension "{ext}"')
        else:
            for ind, tfile in enumerate(torrent['info']['files']):
                ext = tfile['path'][-1][tfile['path'][-1].rfind('.'):].lower()
                if ext in Torrent.VALIDMEDIA:
                    videos[ind] = {}
                    videos[ind]['size'] = self.__convert_size(tfile['length'])
                    if 'path.utf-8' in tfile:
                        videos[ind]['name'] = tfile['path.utf-8'][-1]
                    else:
                        videos[ind]['name'] = tfile['path'][-1]
                else:
                    Debug.log('P', 0, f'Torrent.getvideos({tid}): unsupported file extension "{ext}"')
        return videos

    ###
    def is_cached(self, tid):
        if tid in self.torrents and os.path.isfile(self.getfname(tid)):
            cached = True
        else:
            cached = False
        Debug.log('P', 3, f'Torrent.is_cached({tid}): {cached}')
        return cached
