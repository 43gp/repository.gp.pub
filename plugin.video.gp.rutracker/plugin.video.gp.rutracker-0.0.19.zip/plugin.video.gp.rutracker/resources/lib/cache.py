# -*- coding: utf-8 -*-
"""
Кэш:
id - уникальный текстовый индификатор объекта
hash - числовой НЕ уникальный индификатор объекта
expiries - время по достижении которого объект будет удален из кэша
           если 0, то объект храниться вечно.
data - к данным должен быть применим json.dumps()
"""

import hashlib
import json
import sys
import sqlite3
import time
import zlib

from debug import Debug


class Cache:
    """SQLite3 cache class"""
    __initialized = False
    __connection = None
    __cursor = None
    __zlvl = 0

    ###
    @classmethod
    def __init__(cls, fname, zlvl=0):
        """Инициализация модуля."""
        Debug.log('C', 2, f'Cache.init({fname}, {zlvl})')
        try:
            cls.__connection = sqlite3.connect(fname)
            cls.__cursor = cls.__connection.cursor()
        except sqlite3.OperationalError as e:
            Debug.log('C', 0, f'Cache.init({fname}, {zlvl}): {e}')
            sys.exit(1)
        cls.__cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='cache';")
        if not cls.__cursor.fetchone():
            Debug.log('C', 3, f'Cache.init({fname}, {zlvl}) creating table')
            cls.__cursor.execute("""
               CREATE TABLE IF NOT EXISTS cache (
                hash INTEGER PRIMARY KEY,
                expire INTEGER NOT NULL,
                id TEXT NOT NULL UNIQUE,
                data BLOB NOT NULL
            );""")
            cls.__cursor.execute("CREATE INDEX expired ON cache (expire);")
            cls.__connection.commit()
        cls.__zlvl = zlvl
        cls.__initialized = True
        cls.cleanup(int(time.time()))

    ###
    @classmethod
    def __del__(cls):
        Debug.log('C', 3, 'Cache.del()')
        if cls.__initialized:
            cls.cleanup(int(time.time()))
            cls.__connection.close()

    ###
    @staticmethod
    def __hash_id(cid):
        if isinstance(cid, int):
            hid = cid
        else:
            hid = int(hashlib.sha256(cid.encode('utf-8')).hexdigest()[:16], 16)-(1 << 63)
        return hid

    @classmethod
    def add(cls, cid, expiries, data):
        """Add record to cache."""
        Debug.log('C', 2, f'Cache.add({cid})')
        if expiries:
            expiries = int(time.time()) + expiries
        try:
            cls.__cursor.execute(
                "INSERT OR REPLACE INTO cache (id, hash, expire, data) VALUES (?, ?, ?, ?)",
                (
                    cid,
                    cls.__hash_id(cid),
                    expiries,
                    zlib.compress(
                        json.dumps(data, ensure_ascii=False).encode('utf-8'),
                        level=cls.__zlvl
                    ),
                )
            )
            cls.__connection.commit()
        except sqlite3.Error as e:
            Debug.log('C', 0, f'Cache.add({cid}): {e}')

    ###
    @classmethod
    def cleanup(cls, expire):
        """Remove all expired records from cache."""
        try:
            cls.__cursor.execute('DELETE FROM cache WHERE expire>0 AND expire<?', (expire,))
            cls.__connection.commit()
            Debug.log('C', 3, f'Cache.cleanup({expire}): {cls.__cursor.rowcount} records removed')
        except sqlite3.Error as e:
            Debug.log('C', 0, f'Cache.cleanup({expire}): {e}')

    ###
    @classmethod
    def get(cls, cid):
        """Get record from cache by cid"""
        if not cls.__initialized:
            Debug.log('C', 0, f'Cache.get({cid}): ERROR')
        cls.__cursor.execute(
                "SELECT data FROM cache WHERE hash=? AND id=?",
                (cls.__hash_id(cid), cid,)
        )
        res = cls.__cursor.fetchone()
        if not res:
            Debug.log('C', 2, f'Cache.get({cid}): miss')
            return None
        data = json.loads(zlib.decompress(res[0]))
        Debug.log('C', 2, f'Cache.get({cid}): hit')
        Debug.log('C', 3, f'Cache.get({cid}): "{data}"')
        return data

    ###
    @classmethod
    def delete(cls, cid):
        """Удаляет cid из кэша"""
        if not cls.__initialized:
            Debug.log('C', 0, f'Cache.delete({cid}): ERROR')
        try:
            cls.__cursor.execute(
                "DELETE FROM cache WHERE hash = ? AND id = ?",
                (
                    cls.__hash_id(cid),
                    cid
                )
            )
            cls.__connection.commit()
            Debug.log('C', 1, f'Cache.delete({cid}): {cls.__cursor.rowcount} records removed')
        except sqlite3.Error as e:
            Debug.log('C', 0, f'Cache.delete({cid}): {e}')

    @classmethod
    def update(cls, cid, expiries):
        """Обновляет поле expires для cid в базе."""
        Debug.log('C', 2, f'Cache.update({cid}, {expiries})')
        expire = int(time.time()) + expiries
        try:
            cls.__cursor.execute(
                "UPDATE cache SET expire = ? WHERE hash = ? and id = ?",
                (
                    expire,
                    cls.__hash_id(cid),
                    cid
                )
            )
            cls.__connection.commit()
        except sqlite3.Error as e:
            Debug.log('C', 0, f'Cache.update({cid}, {expiries}): {e}')
