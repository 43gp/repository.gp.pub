# -*- coding: utf-8 -*-
"""TMDB scraper module"""

import json

from urllib.parse import urlencode

from debug import Debug
from network import Network, ReqParams
from scraper import Scraper

# pylint: disable=too-few-public-methods
class TMDB:
    """Скрапер TMDB"""
    BASE_URL = 'https://api.themoviedb.org'
    API_URL = BASE_URL + '/3/{}'
    FIND_URL = API_URL.format('find/{}')
    SEARCH_URL = API_URL.format('search/movie')
    MOVIE_URL = API_URL.format('movie/{}')
    IMAGE_PATH = 'https://image.tmdb.org/t/p/original'
    GENDERS = ['', 'FEMALE', 'MALE', 'PIDOR',]

    ###
    def __init__(self, key, proxy):
        Debug.log('T', 2, f'TMDB.init({key}, {proxy=})')
        self.api_key = key
        self.net_params = ReqParams(
                proxy=proxy,
                headers={'accept': 'application/json'},
        )

    ###
    def __get_akas(self, tmdb_id):
        """Загружает AKAs для tmdb_id"""
        response = Network.geturl(
                TMDB.MOVIE_URL.format(tmdb_id) + '?' +
                urlencode({
                        'api_key': self.api_key,
                        'language': 'en-US'
                }),
                params=self.net_params
        )
        movie = {}
        if response.status_code == 200:
            try:
                movie = json.loads(response.text)
            except json.JSONDecodeError:
                pass
        return movie.get('title', '')

    ###
    def __getinfo(self, info, tmdb_id):
        """
        Грузит инфу о tmdb_id из TMDB и возвращает ее в виде:
        {'success': True, 'info': {}}
        """
        result = {'success': False, 'info': {}}
        Debug.log('T', 2, f'TMDB.getinfo(#{info["Id"]}): tmdb_id={tmdb_id}')
        response = Network.geturl(
                TMDB.MOVIE_URL.format(tmdb_id) + '?' +
                urlencode({
                        'api_key': self.api_key,
                        'append_to_response': 'credits',
                        'language': 'ru-Ru'
                }),
                params=self.net_params
        )
        if response.status_code != 200:
            Debug.log('T', 0, f'TMDB.getinfo(#{info["Id"]}): request failed.')
            return result
        try:
            movie = json.loads(response.text)
        except json.JSONDecodeError as e:
            Debug.log('T', 0, f'TMDB.getinfo(#{info["Id"]}): bad response: {e}')
            return result
        result['success'] = True
        if not movie.get('id'):
            Debug.log('T', 0, f'TMDB.getinfo(#{info["Id"]}): bad response.')
            Debug.log('T', 3, f'TMDB.getinfo(#{info["Id"]}): json={response.text}')
            return result
        # парсим json
        myinfo = Scraper.info_new()
        myinfo['Id'] = info['Id']
        myinfo['imdbId'] = movie.get('imdb_id') if movie.get('imdb_id') else ''
        myinfo['Scraper'] = Scraper.SCRAPERS['tmdb']
        myinfo['Genres'] = [genre.get('name') for genre in movie.get('genres', [])]
        myinfo['Studios'] = [studio.get('name') for studio in movie.get('production_companies', [])]
        myinfo['Countries'] = [
            country['n']  for country in Scraper.COUNTRIES if country['c'] in
                [country.get('iso_3166_1', 'NO_KEY') for
                    country in movie.get('production_countries', [])]
        ]
        if movie.get('poster_path'):
            myinfo['Cover'] = TMDB.IMAGE_PATH + movie.get('poster_path')
        try:
            myinfo['Year'] = int(movie.get('release_date', '0-').split('-')[0])
        except ValueError:
            myinfo['Year'] = 0
        myinfo['Plot'] = movie.get('overview')
        # названия
        if (title := movie.get('title')):
            if Scraper.is_rus(title):
                myinfo['ruTitle'] = title
            elif Scraper.is_lat(title):
                myinfo['origTitle'] = title
        if (title := movie.get('original_title')):
            if Scraper.is_rus(title) and not myinfo['ruTitle']:
                myinfo['ruTitle'] = title
            elif Scraper.is_lat(title) and not myinfo['origTitle']:
                myinfo['origTitle'] = title
        self.__getpersons(movie, myinfo)
        if not myinfo['ruTitle'] and not myinfo['origTitle']:
            myinfo['origTitle'] = self.__get_akas(tmdb_id)
        Scraper.is_success(myinfo)
        result['info'] = myinfo
        Debug.log('T', 1, f'TMDB.getinfo(#{info["Id"]}): {myinfo["Success"]}')
        return result

    ###
    def __getpersons(self, movie, info):
        for item in (
                Scraper.nested_get(movie, ['credits', 'crew'], []) +
                Scraper.nested_get(movie, ['credits', 'cast'], [])
                ):
            # Куда будем пихать
            if item.get('job'):
                if item['job'] == 'Director':
                    tag = 'Directors'
                elif item['job'] == 'Screenplay':
                    tag = 'Writers'
                else:
                    continue
            elif len(info['Artists']) < 12:
                tag = 'Artists'
            else:
                continue
            # имя
            ru_name = ''
            en_name = ''
            if Scraper.is_rus(item.get('name')):
                ru_name = item.get('name')
                en_name = Scraper.to_english(item.get('name'))
            else:
                ru_name = ''
                en_name = item.get('name')
            if Scraper.is_rus(item.get('original_name')):
                ru_name = item.get('original_name')
            else:
                en_name = item.get('original_name')
            # картинка
            img = ''
            if item.get('profile_path'):
                img = TMDB.IMAGE_PATH + item['profile_path']
            # пол
            gender = TMDB.GENDERS[item.get('gender', 0)]
            # почти готово
            info[tag].append({
                    'ruName': ru_name,
                    'enName': en_name,
                    'gender': gender,
                    'Role': item.get('character', ''),
                    'Img': img
            })

    ###
    def __get_id(self, imdb_id):
        """Ищет tmbd_id по imdb_id"""
        response = Network.geturl(
            TMDB.FIND_URL.format(imdb_id) + '?' +
                urlencode({
                    'api_key': self.api_key,
                    'external_source': 'imdb_id'
                }),
                params=self.net_params
        )
        if response.status_code != 200:
            Debug.log('T', 0, f'TMDB.get_id({imdb_id}): request failed.')
            return 0
        try:
            tmdb_id = Scraper.nested_get(
                    json.loads(response.text),
                    ['movie_results', 0, 'id'],
                    0
            )
        except json.JSONDecodeError as e:
            Debug.log('T', 0, f'TMDB.get_id({imdb_id}): bad response: {e}')
            Debug.log('T', 3, f'TMDB.get_id({imdb_id}): response={response.text}')
            return 0
        return tmdb_id

    ###
    def __search(self, info_id, query):
        """
        Запрашивает query у TMDB и возвращает словарь вида:
         {'success': True, 'tmdb_ids': []}
        """
        result = {'success': False, 'tmdb_ids': []}

        Debug.log('T', 3, f'TMDB.search(#{info_id}, {query})')
        params = {
            'api_key': self.api_key,
            'language': 'ru-Ru'
        }
        params.update(query)
        response = Network.geturl(TMDB.SEARCH_URL + "?" + urlencode(params), params=self.net_params)
        if response.status_code != 200:
            Debug.log('T', 0, f'TMDB.search(#{info_id}, {query}): request failed.')
            return result
        Debug.log('T', 4, f'TMDB.search(#{info_id}, {query}): json={response.text}')
        try:
            movies = Scraper.nested_get(json.loads(response.text), ['results'])
        except json.JSONDecodeError as e:
            Debug.log('T', 0, f'TMDB.search(#{info_id}, {query}): bad response: {e}')
            return result
        result['success'] = True
        if not movies:
            Debug.log('T', 1, f'TMDB.search(#{info_id}, {query}): not found.')
            return result
        result['tmdb_ids'] = [d['id'] for d in movies]
        Debug.log('T', 1, f'TMDB.search(#{info_id}, {query}): {result["tmdb_ids"]}')
        return result

    ###
    def scrape(self, info):
        """
        Пытается найти данные по видео из info в базе TMDB
        {'success': True, 'info': {}}
        """
        imdb_id = info.get('imdbId')
        tmdb_result = {'success': False, 'info': {}}
        if not imdb_id:
            Debug.log('T', 2, f'TMDB.scrape(#{info["Id"]}): searching imdbId')
            checked = []
            queries = [query for query in list(set([
                    info.get('origTitle') if info.get('origTitle') else '',
                    info.get('ruTitle') if info.get('ruTitle') else '',
                ] + [
                    f'"{other}"' for other in info.get('otherTitles')
                ])) if query
            ]
            Debug.log('T', 3, f'TMDB.scrape(#{info["Id"]}): queries={queries}')
            for query in queries:
                squery = {'query': query}
                found = False
                if info.get('Year'):
                    squery['year'] = info['Year']
                result = self.__search(info['Id'], squery)
                if result['success']:
                    for tmdb_id in result['tmdb_ids']:
                        if tmdb_id in checked:
                            continue
                        checked.append(tmdb_id)
                        Debug.log('T', 2, f'TMDB.scrape(#{info["Id"]}): checking {tmdb_id}')
                        tmdb_result = self.__getinfo(info, tmdb_id)
                        if (
                                tmdb_result['success'] and
                                tmdb_result['info'] and
                                Scraper.is_same(info, tmdb_result['info'])
                        ):
                            Debug.log('T', 2, f'TMDB.scrape(#{info["Id"]}): hit {tmdb_id}')
                            found = True
                            break
                if found:
                    break
                tmdb_result['info'] = {}
        else:
            # imdbId известен, запрашиваем tmdb_id
            tmdb_id = self.__get_id(imdb_id)
            if not tmdb_id:
                # tmdbId не найден, пробуем вырулить через поиск.
                Debug.log('T', 1, f'TMDB.scrape(#{info["Id"]}): imdb={imdb_id} not found')
                tmp_info = info.copy()
                tmp_info['imdbId'] = ''
                res = self.scrape(tmp_info)
                if res and res.get('success') and res.get('info') and res['info']:
                    res['info']['imdbId'] = tmp_info['imdbId']
                    tmdb_result = res
            else:
                tmdb_result = self.__getinfo(info, tmdb_id)
        Debug.log('T', 1,
                f'TMDB.scrape(#{info["Id"]}): {tmdb_result["success"]}/'
                f'{tmdb_result["info"].get("Success", False)}'
        )
        return tmdb_result
