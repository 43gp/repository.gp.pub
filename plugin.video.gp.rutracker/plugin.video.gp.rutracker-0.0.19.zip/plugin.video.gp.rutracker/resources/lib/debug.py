# -*- coding: utf-8 -*-
"""
Этот модуль нужно подключать первым и удалаять последним
"""
import sys
import time
try:
    import xbmc
except ModuleNotFoundError:
    pass


class Debug():
    """Debug class"""
    __file = sys.stderr
    modules = {}

    ###
    @classmethod
    def log(cls, mod, lvl, msg):
        """
        Логирует сообщение msg если lvl <= заданного,
        при lvl=0 дополнительно логируем в лог Kodi.
        """
        if mod in cls.modules and cls.modules[mod] >= lvl:
            print(f'[{time.time():.7f}][{mod}][{lvl}]{msg}', flush=True, file=cls.__file)
        if lvl == 0:
            try:
                xbmc.log(f'RuTracker[{mod}]{msg}', xbmc.LOGERROR)
            except NameError:
                pass

    ###
    @classmethod
    def setloglevel(cls, mod, lvl):
        """Устанавливает максимально разрешенный уровень логирования для mod."""
        cls.modules[mod] = lvl

    ###
    @staticmethod
    def setlogfile(fname):
        """Перенаправляет stderr в указанный файл."""
        try:
            # pylint: disable=consider-using-with
            Debug.__file = open(fname, 'a', encoding="utf-8")
        except OSError:
            pass
