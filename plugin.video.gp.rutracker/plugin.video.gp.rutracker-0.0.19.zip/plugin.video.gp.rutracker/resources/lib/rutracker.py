# -*- coding: utf-8 -*-
"""RuTracker module."""
from html import unescape
import re

from urllib.parse import urlencode
from cache import Cache
from debug import Debug
from network import Network, ReqParams, ReqAuth
from scraper import Scraper

class RuTracker:
    CONTENT = {
        'movies': {
            'title': 'Фильмы',
            'include': (22, 7, 124, 2198, 718),
            'exclude': (
                44, 65, 69, 93, 94, 96, 100, 101, 106, 125, 149, 166, 185, 186, 212, 254, 267,
                376, 531, 572, 653, 709, 771, 772, 789, 877, 905, 906, 1454, 1543, 1576, 1577,
                1640, 1670, 1692, 2220, 2373, 2374, 2459
            ),
            'scrapers': ['rt', 'imdb', 'tmdb', 'kp']
        },
        'serials': {
            'title': 'Сериалы',
            'include': (9, 189, 2366, 911, 2100),
            'exclude': (26, 32, 190, 191, 195, 913, 914, 920, 1147, 1359, 1395, 1498, 1537, 1539, 1574, 2101, 2102, 2369),
            'scrapers': ['rt', 'imdb', 'tmdb', 'kp']
        },
        'cartoons': {
            'title': 'Мультфильмы',
            'include': (84, 930, 2343, 2365, 208, 539, 2183,209, 484, 181),
            'exclude': (86, 521, 665, 822, 1900, 2258),
            'scrapers': ['rt', 'imdb', 'tmdb', 'kp']
        },
    }
    INFOTAGS = [
        {'tag': 'Year', 'tags': ['год', 'год выпуска']},
        {'tag': 'Plot', 'tags': ['описание', 'сюжет', 'о фильме']},
        {'tag': 'Countries', 'tags': ['страна', 'страна-производитель', 'производство']},
        {'tag': 'Genres', 'tags': ['жанр']},
        {'tag': 'Directors', 'tags': ['режиссер', 'режиссеры', 'режиссёр', 'режиссёры']},
        {'tag': 'Writers', 'tags': ['сценарий', 'автор сценария']},
        {'tag': 'Artists', 'tags': ['в ролях', 'исполнители']},
    ]
    URLS = {
        'forum': 'viewforum.php?sort=2&order=0&f=',
        'topic': 'viewtopic.php?t=',
        'torrent': 'dl.php?t=',
        'tracker': 'tracker.php'
    }
    RE_CID = re.compile(r'(?:<a href="viewforum\.php\?f=)([0-9]+)">', re.S)
    RE_CLEAR = re.compile(r'<.*?>|&([a-z0-9]+|#[0-9]{1,6}|#x[0-9a-f]{1,6});', re.S)
    RE_COVER = re.compile(r'postImg[^>]+title="([^"]+)"', re.S)
    RE_FORUM = re.compile(r'class="forumlink"><a href="viewforum\.php\?f=([0-9]+)">([^<]+)</a>')
    RE_POST = re.compile(r'<div class="post_body"[^>]+>(.+?)<table class="attach bordered med">', re.U|re.S)
    RE_TOPIC = re.compile(r'<a id="tt-(?P<id>[0-9]+)"[^>]+>(.*?)</a>.*title="Seeders"><b>([0-9]+).*dl-stub">([^<]+)<', re.S)
    RE_FPAGE = re.compile(r'<a class="pg".{15,60}start=[0-9]+">([0-9]+)</a>.{0,15}<a class="pg".{15,60}start=([0-9]+)">След\.</a>', re.U|re.S)
    RE_SPAGE = re.compile(r'<a class="pg".{15,60}start=[0-9]+">([0-9]+)</a>.{0,15}<a class="pg".{15,60}search_id=([^&]+)&amp;start=([0-9]+)">След\.</a>', re.U|re.S)
    RE_IMDB = re.compile(r'imdb\.com.*?(tt[0-9]+)', re.S)
    #RE_KP = re.compile(r'kinopoisk\.ru(?:%2F|/)?(images(?:%2F|/)?)?(?:series|film|rating)(?:%2F|/)?([0-9]+)', re.S)
    RE_KP = re.compile(r'kinopoisk\.ru(?:%2F|/)?(?:images(?:%2F|/)|level(?:%2F|/)[0-9](?:%2F|/))?(?:series|film|rating)(?:%2F|/)?([0-9]+)', re.S)
    RE_SEARCH = re.compile(r'="tracker\.php\?f=([0-9]+)".*?viewtopic\.php\?t=(?P<id>[0-9]+)">([^<]+)</a>.{100,500}\.php\?t=(?P=id)">([^<]+)</a>.*?<b class="seedmed">([0-9]+)</b>', re.S)
    RE_SPLIT = re.compile(r'^(.{2,})(\([^\)]{2,}\))$', re.U|re.S)
    FORUM_INDEX = {}
    SEARCH_INDEX = {}

    ###
    def __init__(self, url, login, password, proxy):
        Debug.log('R', 2, f'RuTracker.init({url}, {login[0] + "*" * (len(login) - 1)}, {"*" * len(password)}, {proxy})')
        self.base_url = url
        self.req_params = ReqParams(proxy=proxy,)
        self.req_auth = ReqAuth(
                method='POST',
                url=self.base_url + '/forum/login.php',
                data={'login_username': login, 'login_password': password, 'login': 'Вход'},
                validator=RuTracker.__is_authorized
        )
        RuTracker.FORUM_INDEX = Cache.get('FORUM_INDEX')
        if not RuTracker.FORUM_INDEX:
            RuTracker.FORUM_INDEX = {}
        RuTracker.SEARCH_INDEX = Cache.get('SEARCH_INDEX')
        if not RuTracker.SEARCH_INDEX:
            RuTracker.SEARCH_INDEX = {}

    @staticmethod
    def __is_authorized(request_id, response):
        authorized = False
        lvl = 0
        if response.status_code == 200:
            if 'logged-in-username' in response.text or 'attachment; filename=' in response.headers.get('Content-Disposition', ''):
                authorized = True
                lvl = 3
        Debug.log('N', lvl, f'RuTracker.is_authorized(#{request_id}): {authorized}')
        return authorized

    @staticmethod
    def __getforums(html):
        """Returns list of {id, title}."""
        Debug.log('R', 3, 'RuTracker.getforums(): Started')
        forums = []
        for forum in RuTracker.RE_FORUM.findall(html):
            forums.append({'id': int(forum[0]), 'title': forum[1]})
        Debug.log('R', 3, f'RuTracker.getforums(): found {len(forums)} forums')
        return forums

    ###
    def __loadindex(self):
        url = self.geturl('tracker')
        Debug.log('R', 2, f'RuTracker.loadindex(): Loading {url}')
        response = Network.geturl(url, params=self.req_params, auth=self.req_auth)
        if response and response.status_code == 200:
            forum_index = {}
            for forum in re.compile(r'<option id="fs-([0-9]+)"[^>]+>([^<]+)', re.U).findall(response.text):
                forum_index[forum[0]] = unescape(forum[1]).strip().removeprefix('|-').strip()
            Debug.log('R', 3, f'RuTracker.loadindex(): {forum_index}')
            RuTracker.FORUM_INDEX = forum_index
            Cache.add('FORUM_INDEX', 0, RuTracker.FORUM_INDEX)
            search_index = {}
            catalog = {}
            root = None
            for cat, is_root in re.compile(r'<option id="fs\-([0-9]+)"([^>]+)>', re.U).findall(response.text):
                cat = int(cat)
                if 'root_forum' in is_root:
                    root = cat
                    catalog[root] = [cat]
                elif root:
                    catalog[root].append(cat)
            for content in RuTracker.CONTENT:
                search_index[content] = []
                for entry in RuTracker.CONTENT[content]['include']:
                    if entry in catalog:
                        for cat in catalog[entry]:
                            if not cat in RuTracker.CONTENT[content]['exclude']:
                                search_index[content].append(cat)
                    else:
                        search_index[content].append(entry)
                for entry in search_index[content]:
                    if entry in catalog:
                        search_index[entry] = []
                        for cat in catalog[entry]:
                            if not cat in RuTracker.CONTENT[content]['exclude']:
                                search_index[entry].append(cat)
            Debug.log('R', 3, f'RuTracker.loadindex(): {search_index}')
            RuTracker.SEARCH_INDEX = search_index
            Cache.add('SEARCH_INDEX', 0, RuTracker.SEARCH_INDEX)

    ###
    @staticmethod
    def __getpages(html):
        """Returns pagenator info as dict()."""
        page = {}
        if 'search_id=' in html and (res := RuTracker.RE_SPAGE.search(html)):
            page = {'max': int(res.group(1)), 'cur': int(int(res.group(3)) / 50), 'key': res.group(2)}
        elif (res := RuTracker.RE_FPAGE.search(html)):
            page = {'max': int(res.group(1)), 'cur': int(int(res.group(2)) / 50)}
        Debug.log('R', 3, f'RuTracker.getpages(): {page}')
        return page

    ###
    @staticmethod
    def __gettopics(html):
        """Returns list of {id, title, seeders, size}."""
        Debug.log('R', 3, 'RuTracker.gettopics(): Started')
        topics = []
        topics_list = html.split('data-topic_id')
        if len(topics_list) > 1:
            topics_list = topics_list[1:]
        for entry in topics_list:
            item = RuTracker.RE_TOPIC.search(entry)
            if item:
                topic = {
                    'id': int(item.group(1)),
                    'title': unescape(RuTracker.RE_CLEAR.sub('', item.group(2))),
                    'seeders': int(item.group(3)),
                    'size': RuTracker.RE_CLEAR.sub('', item.group(4))
                }
                Debug.log('R', 3, f'RuTracker.gettopics(): append {topic}')
                topics.append(topic)
        return topics

    ###
    def getcid(self, fid):
        if not RuTracker.SEARCH_INDEX:
            self.__loadindex()
        if not RuTracker.SEARCH_INDEX:
            return None
        for cid in RuTracker.CONTENT:
            if fid in RuTracker.SEARCH_INDEX[cid]:
                return cid
        return None

    ###
    @staticmethod
    def getscrapers(cid):
        return RuTracker.CONTENT[cid]['scrapers']

    ###
    def geturl(self, view, view_id = 0, page=0, query=None):
        url = self.base_url + '/forum/'
        if view in RuTracker.URLS:
            url += RuTracker.URLS[view]
            if view_id:
                url += str(view_id)
        else:
            url += 'index.php'
        if page:
            url += '&start=' + str((page - 1) * 50)
        if query:
            if '?' in url:
                url += '&'
            else:
                url += '?'
            url += query
        Debug.log('R', 3, f'RuTracer.geturl({view}, {view_id}, {page}, {query}): {url}')
        return url


    ###
    @staticmethod
    def viewroot():
        """Returns RuTracker root entries as list()."""
        Debug.log('R', 2, 'RuTracker.viewroot()')
        content = list()
        for entry in RuTracker.CONTENT:
            item = {
                'mode': 'content',
                'cid': entry,
                'title': RuTracker.CONTENT[entry]['title'],
                'is_folder': True
            }
            Debug.log('R', 3, f'RuTracker.viewroot(): append {item}')
            content.append(item)
        return content

    ###
    def viewcontent(self, cid):
        """Returns content of cid as list()."""
        Debug.log('R', 2, f'RuTracker.viewcontent({cid})')
        if not RuTracker.FORUM_INDEX:
            self.__loadindex()
        content = list()
        if RuTracker.FORUM_INDEX:
            for fid in RuTracker.CONTENT[cid]['include']:
                title = RuTracker.FORUM_INDEX.get(str(fid))
                if not title:
                    # Индекс протух?
                    Debug.log('R', 1, f'RuTracker.viewcontent({cid}): {fid} not in FORUM_INDEX, reloading')
                    self.__loadindex()
                    title = RuTracker.FORUM_INDEX.get(str(fid))
                if title:
                    item = {
                        'fid': fid,
                        'mode': 'forum',
                        'title': title,
                        'is_folder': True,
                        'cid': cid
                    }
                    Debug.log('R', 3, f'RuTracker.viewcontent({cid}): append {item}')
                    content.append(item)
                else:
                    Debug.log('R', 0, f'RuTracker.viewcontent({cid}): unknown fid {fid}')
        return content

    ###
    def viewforum(self, cid, fid, page=0):
        """Returns forum content as list()."""
        Debug.log('R', 2, f'RuTracker.viewforum({cid}, {fid}, {page})')
        if not RuTracker.FORUM_INDEX.get(str(fid)):
            # Индекс протух?
            Debug.log('R', 1, f'RuTracker.viewforum({cid}, {fid}, {page}): {fid} not in FORUM_INDEX, reloading')
            self.__loadindex()
        content = list()
        response = Network.geturl(self.geturl('forum', fid, page=page), params=self.req_params, auth=self.req_auth)
        if response.status_code == 200:
            sub_forums = self.__getforums(response.text)
            for entry in sub_forums:
                if entry['id'] not in RuTracker.CONTENT[cid]['exclude']:
                    item = {
                        'mode': 'forum',
                        'cid': cid,
                        'fid': entry['id'],
                        'title': unescape(entry['title']),
                        'is_folder': True,
                    }
                    Debug.log('R', 3, f'RuTracker.viewforum({cid}, {fid}, {page}): append {item}')
                    content.append(item)
                else:
                    Debug.log('R', 3, f'RuTracker.viewforum({cid}, {fid}, {page}): exclude {entry}')
            topics = self.__gettopics(response.text)
            for topic in topics:
                item = {
                    'mode': 'topic',
                    'cid': cid,
                    'fid': fid,
                    'tid': topic['id'],
                    'title': topic['title'],
                    'size': topic['size'],
                    'seeders': topic['seeders'],
                    'is_torrent': True,
                }
                Debug.log('R', 3, f'RuTracker.viewforum({cid}, {fid}, {page}): append {item}')
                content.append(item)
            pages = self.__getpages(response.text)
            if pages and pages['cur'] != pages['max']:
                page = pages['cur'] + 1
                item = {
                    'mode': 'forum',
                    'cid': cid,
                    'fid': fid,
                    'page': page,
                    'title': f'[{pages["cur"]}/{pages["max"]}]',
                    'max': pages['max'],
                    'is_folder': True,
                    'is_page': True,
                }
                Debug.log('R', 3, f'RuTracker.viewforum({cid}, {fid}, {page}): append {item}')
                content.append(item)
        return content

    ###
    def viewtopic(self, tid):
        Debug.log('R', 3, 'RuTracker.viewtopic({tid})')
        return Network.geturl(self.geturl('torrent', tid), params=self.req_params, auth=self.req_auth)

    ###
    def viewtracker(self, cid=None, fid=None, sid=None, tm=None, page=None, query=None):
        Debug.log('R', 2, f'RuTracker.viewtracker({cid}, {fid}, {sid}, {tm}, {page}, {query})')
        if not RuTracker.SEARCH_INDEX or (fid and not RuTracker.FORUM_INDEX.get(str(fid))):
            self.__loadindex()
        if not RuTracker.SEARCH_INDEX:
            return []
        if not sid:
            #параметры поиска
            forums = []
            if not cid:
                #главное меню
                for entry in RuTracker.CONTENT:
                    forums += RuTracker.SEARCH_INDEX[entry]
            elif not fid:
                #подраздел главного меню
                forums = RuTracker.SEARCH_INDEX[cid]
            elif str(fid) in RuTracker.SEARCH_INDEX:
                #все вложенные форумы
                forums = RuTracker.SEARCH_INDEX[str(fid)]
            else:
                #только текущий форум
                forums.append(fid)
            Debug.log('R', 3, f'RuTracker.viewtracker(): forums={forums}')
            qparams = {
                'o': 10,
                's': 2,
                'prev_my': 0,
                'prev_new': 0,
                'prev_oop': 0,
                'f[]': forums
            }
            if tm:
                qparams['tm'] = tm
            if query:
                qparams['nm'] = query
            url = self.geturl('tracker', None, query=urlencode(qparams, True))
        else:
            url = self.geturl('tracker', None, query=f'search_id={sid}&start={str((page - 1) * 50)}')
        response = Network.geturl(url, params=self.req_params, auth=self.req_auth)
        if response.status_code != 200:
            return []
        topics = []
        for entry in RuTracker.RE_SEARCH.findall(response.text):
            entry_fid = int(entry[0])
            if not RuTracker.FORUM_INDEX.get(str(entry_fid)):
                # Индекс протух?
                Debug.log('R', 1, f'RuTracker.viewtracker(): {entry_fid} not in FORUM_INDEX, reloading')
                self.__loadindex()
            entry_cid = ''
            for content in RuTracker.CONTENT:
                if entry_fid in RuTracker.SEARCH_INDEX[content]:
                    entry_cid = content
                    break
            if not entry_cid:
                Debug.log('R', 1, f'RuTracker.viewtracker(): {entry_fid} - unknown cid')
                self.__loadindex()
            topic = {
                'mode': 'topic',
                'cid': entry_cid,
                'fid': entry_fid,
                'tid': int(entry[1]),
                'title': unescape(entry[2]),
                'size': RuTracker.RE_CLEAR.sub('', entry[3]),
                'seeders': int(entry[4]),
                'is_torrent': True,
            }
            topics.append(topic)
        pages = self.__getpages(response.text)
        if pages and pages['cur'] != pages['max']:
            page = pages['cur'] + 1
            item = {
                'mode': 'query',
                'cid': cid,
                'fid': fid,
                'page': page,
                'sid': pages['key'],
                'title': f'[{pages["cur"]}/{pages["max"]}]',
                'max': pages['max'],
                'is_folder': True,
                'is_page': True
            }
            Debug.log('R', 3, f'RuTracker.viewtracker({query}): append {item}')
            topics.append(item)
        Debug.log('R', 1, f'RuTracker.viewtracker({query}): found {len(topics)} topics')
        return topics

    ###
    def __get_post(self, tid, html):
        post = RuTracker.RE_POST.search(html)
        if not post:
            Debug.log('r', 0, f'RuTracker.get_post(#{tid}): post not found')
            return
        text = ''
        data = post.group(1)
        while True:
            post = data.partition('<div class="sp-wrap')
            text += post[0]
            if not post[1]:
                break
            #cut <div ...>
            data = post[2].partition('>')[2]
            while True:
                data = data.partition('</div>')
                if data[0].find('<div') == -1:
                    data = data[2]
                    break
                else:
                    data = data[2]
        Debug.log('r', 3, f'RuTracker.get_post(#{tid}) text={text}')
        return text

    ###
    def scrape(self, info):
        """
        Пытается найти данные по видео из info в первом посте темы РуТрекера
        {'success': True, 'info': {}}
        """
        rt_result = {'success': False, 'info': {}}
        topic_id = info['Id']
        Debug.log('r', 3, f'RuTracker.scrape(#{info["Id"]})')
        response = Network.geturl(self.geturl('topic', info['Id']), params=self.req_params, auth=self.req_auth)
        if response.status_code != 200:
            Debug.log('r', 0, f'RuTracker.scrape({info["Id"]}) network error')
            return rt_result
        # fid и cid
        forums = RuTracker.RE_CID.findall(response.text)
        if not forums:
            Debug.log('r', 0, f'RuTracker.scrape({info["Id"]}) no any forum link')
            return rt_result
        for forum in forums:
            if cid := self.getcid(int(forum)):
                break
            cid = ''
        if not cid:
            Debug.log('r', 0, f'RuTracker.scrape({info["Id"]}) cannot get cid for {forum.group(1)}')
            return rt_result
        # Первое сообщение в теме
        html = self.__get_post(info['Id'], response.text)
        if not html:
            Debug.log('r', 0, f'RuTracker.scrape(#{info["Id"]}): cannot get 1st post')
            return rt_result
        rt_result['success'] = True
        if cid == 'movies' or cid == 'serials' or cid == 'cartoons':
            myinfo = self.movie_scrape(info['Id'], html)
        else:
            Debug.log('r', 0, f'RuTracker(#{tid}): bad cid')
            myinfo = info
        myinfo['Id'] = info['Id']
        myinfo['Scraper'] = Scraper.SCRAPERS['rt']
        myinfo['ruTitle'] = info['ruTitle']
        myinfo['origTitle'] = info['origTitle']
        rt_result['info'] = myinfo
        return rt_result

    def movie_scrape(self, tid, html):
        my_info = {}
        # kpId
        kp = RuTracker.RE_KP.search(html)
        if kp:
            my_info['kpId'] = int(kp.group(1))
        elif 'kinopoisk' in html:
            Debug.log('r', 0, f'RuTracker.movie_scrape(#{tid}) kpId FAIL')
        # imdbId
        imdbId = RuTracker.RE_IMDB.search(html)
        if imdbId:
            my_info['imdbId'] = imdbId.group(1)
        elif 'imdb' in html:
            Debug.log('r', 0, f'RuTracker.movie_scrape(#{tid}) imdbId FAIL')
        # cover
        cover = RuTracker.RE_COVER.search(html)
        if cover:
            my_info['Cover'] = cover.group(1)
        # Чистим html
        data = self.__clear_html(html)
        tag = None
        for line in data.split('\n'):
            if not line:
                continue
            if ':' in line and len(line.partition(':')[0].split()) < 4:
                tag = None
                is_tag = line.partition(':')[0].lower()
                tag = [d['tag'] for d in RuTracker.INFOTAGS if d['tags'] and is_tag in d['tags']]
                if not tag:
                    continue
                tag = tag[0]
                my_info[tag] = line.partition(':')[2].strip()
            elif tag:
                my_info[tag] += line.strip()
        #
        Debug.log('r', 3, f'RuTracker.movie_scrape(#{tid}): my_info={my_info}')
        rt_info = Scraper.info_new()
        if my_info.get('kpId'):
            rt_info['kpId'] = my_info['kpId']
        if my_info.get('imdbId'):
            rt_info['imdbId'] = my_info['imdbId']
        if my_info.get('Cover'):
            rt_info['Cover'] = my_info['Cover']
        if my_info.get('Plot'):
            rt_info['Plot'] = my_info['Plot']
        if 'Year' in my_info:
            if re.match(r'[12][0-9]{3}', my_info['Year']):
                rt_info['Year'] = int(my_info['Year'][0:4])
        if my_info.get('Genres'):
            rt_info['Genres'] = list(map(str.strip, my_info['Genres'].lower().split(',')))
        if my_info.get('Countries'):
            rt_info['Countries'] = list(map(str.strip, my_info['Countries'].split(',')))
        if my_info.get('Artists'):
            artists = list()
            for entry in list(map(str.strip, my_info['Artists'].split(','))):
                if '/' in entry:
                    ru_name = entry.partition('/')[0].strip()
                    en_name = entry.partition('/')[2].strip().partition('/')[0].strip()
                elif '(' in entry and entry.strip().endswith(')'):
                    ru_name = entry.partition('(')[0].strip()
                    en_name = Scraper.to_english(ru_name)
                else:
                    ru_name = entry
                    en_name = Scraper.to_english(ru_name)
                artists.append({'ruName': ru_name, 'enName': en_name, 'Role': '', 'Img': ''})
            rt_info['Artists'] = artists
        if my_info.get('Directors'):
            directors = list()
            for entry in list(map(str.strip, my_info['Directors'].split(','))):
                if '/' in entry:
                    ru_name = entry.partition('/')[0].strip()
                    en_name = entry.partition('/')[2].strip().partition('/')[0].strip()
                else:
                    ru_name = entry
                    en_name = Scraper.to_english(entry)
                directors.append({'ruName': ru_name, 'enName': en_name, 'Role': '', 'img': ''})
            rt_info['Directors'] = directors
        if my_info.get('Writers'):
            writers = list()
            for entry in list(map(str.strip, my_info['Writers'].split(','))):
                if '/' in entry:
                    ru_name = entry.partition('/')[0].strip()
                    en_name = entry.partition('/')[2].strip().partition('/')[0].strip()
                else:
                    ru_name = entry
                    en_name = Scraper.to_english(entry)
                writers.append({'ruName': ru_name, 'enName': en_name, 'Role': '', 'Img': ''})
            rt_info['Writers'] = writers
        Debug.log('r', 2, f'RuTracker.movie_scrape(#{tid}): rt_info={rt_info}')
        return rt_info

    @staticmethod
    def __clear_html(html):
        data = re.sub('(<a[ >].*?</a>)', '', html)
        data = re.sub('<br>', '\n', data)
        data = re.sub('<hr class="post-hr">', '\n', data)
        data = RuTracker.RE_CLEAR.sub('', data)
        return data


class Title:
    QUALITY = {
            '4K': ['2160p'],
            'FHD': ['1080', '1080i', '1080p'],
            '720': ['720', '720i', '720p'],
    }
    RE_CLEAR = re.compile(r'(?:^\[[^\]]+\])?(.*\).?\[[^\]]+\]).?(\[[^\]]+\])?.*$')
    RE_PARTS = re.compile(r'(.*)\[(.*)\]')

    ###
    @staticmethod
    def parse_numbers(string):
        numbers = set()
        Debug.log('r', 3, f'Title.parse_numbers({string})')
        parts = string.lower().partition('из')[0].strip().partition('(')[0].strip().split(',')
        Debug.log('r', 3, f'Title.parse_numbers({string}): parts={parts}')
        for part in parts:
            Debug.log('r', 3, f'Title.parse_numbers({string}): part={part}')
            try:
                if '-' in part:
                    # Добавляем диапазон чисел
                    start, end = map(int, part.split('-'))
                    numbers.update(range(start, end + 1))
                else:
                    # Добавляем отдельное число
                    numbers.add(int(part))
            except ValueError:
                pass
        return sorted(numbers)

    @staticmethod
    def split_titles_dirs(string):
        stack = []
        last_closing_index = string.rfind(')')
        # Проходим по строке до самой правой закрывающей скобки
        for i, char in enumerate(string[:last_closing_index + 1]):
            if char == '(':
                stack.append(i)
            elif char == ')':
                if not stack:
                    return None
                last_open = stack.pop()
        return last_open

    ###
    @staticmethod
    def scrape(tid, cid, title):
        Debug.log('r', 2, f'Title.scrape(#{tid}, {cid}, {title})')
        if cid == 'movies' or cid == 'serials' or cid == 'cartoons':
            return Title.movie_scrape(tid, title)
        else:
            Debug.log('r', 0, f'Title.scrape(#{tid}, {cid}, {title}): bad cid')
            info = Scraper.info_new()
            info['Id'] = tid
            info['Scraper'] = Scraper.SCRAPERS['title']
            info['origTitle'] = title
            return info

    ###
    @staticmethod
    def movie_scrape(tid, title):
        Debug.log('r', 2, f'Title.movie_scrape(#{tid}): title={title}')
        info = Scraper.info_new()
        info['Id'] = tid
        info['Scraper'] = Scraper.SCRAPERS['title']
        # Приводим title к виду <titles and directors><tags> обрезая начальные и конечные тэги
        clear = Title.RE_CLEAR.match(title)
        if not clear:
            Debug.log('r', 0, f'Title.movie_scrape(#{tid}): cannot clear - {title}')
            info['origTitle'] = title
            return info
        Debug.log('r', 3, f'Title.movie_scrape(#{tid}): group1={clear.group(1)}')
        Debug.log('r', 3, f'Title.movie_scrape(#{tid}): group2={clear.group(2)}')
        # Разбиваем очищенный title на <titles and directors> и <tags>
        parts = Title.RE_PARTS.match(clear.group(1).strip())
        if not parts:
            Debug.log('r', 0, f'Title.movie_scrape(#{tid}): cannot split TitlesDirectors_Tags  -  {clear.group(1)}')
            info['origTitle'] = clear.group(1).strip()
            return info
        tags = parts.group(2).strip()
        if not tags[0].isdigit() and clear.group(2):
            Debug.log('r', 2, f'Title.movie_scrape(#{tid}): tags - fallback to group2')
            tags = clear.group(2)[1:-1]
        Debug.log('r', 2, f'Title.movie_scrape(#{tid}): tags={tags}')
        titles_dirs = parts.group(1).strip()
        Debug.log('r', 3, f'Title.movie_scrape(#{tid}): titles_dirs={titles_dirs}')
        # Разбиваем <titles and directors> на <titles> и <directors>
        # в <directors> попадает самое правое содержимое круглых скобок.
        split_pos = Title.split_titles_dirs(titles_dirs)
        if not split_pos:
            Debug.log('r', 0, f'Title.movie_scrape(#{tid}): cannot split TitlesDirectors - {titles_dirs}')
            info['origTitle'] = titles_dirs
            return info
        directors = titles_dirs[split_pos+1:-1].strip()
        Debug.log('r', 2, f'Title.movie_scrape(#{tid}): directors={directors}')
        titles = titles_dirs[:split_pos].strip()
        Debug.log('r', 2, f'Title.movie_scrape(#{tid}): titles={titles}')
        # название фильма:
        for title in list(map(str.strip, titles.split('/'))):
            Debug.log('r', 3, f'Title.movie_scrape(#{tid}): title={title}')
            if title.lower().startswith('сезон'):
                sname = title.lower().removeprefix('сезон').strip()
                if sname.startswith(':'):
                    sname = sname[1:].strip()
                if has_number := any(char.isdigit() for char in sname):
                    if seasons := Title.parse_numbers(sname):
                        info['Serial']['fromSeason'] = min(seasons)
                        info['Serial']['toSeason'] = max(seasons)
                        Debug.log('r', 2, f'Title.movie_scrape(#{tid}): info.Serial={info["Serial"]}')
                    else:
                        Debug.log('r', 1, f'Title.movie_scrape(#{tid}): cannot parse season - {title}')
                    continue
            if title.lower().startswith('серии'):
                ename = title.lower().removeprefix('серии').strip()
                if ename.startswith(':'):
                    ename = ename[1:].strip()
                if has_number := any(char.isdigit() for char in ename):
                    if episodes := Title.parse_numbers(ename):
                        if not info['Serial']:
                            info['Serial'] = {'fromSeason': 1, 'toSeason': 1}
                        info['Serial']['fromEpisode'] = min(episodes)
                        info['Serial']['toEpisode'] = max(episodes)
                        Debug.log('r', 2, f'Title.movie_scrape(#{tid}): info.Serial={info["Serial"]}')
                    else:
                        Debug.log('r', 1, f'Title.movie_scrape(#{tid}): cannot parse episodes - {title}')
                    continue
            if not info.get('ruTitle'):
                # Русское название.
                info['ruTitle'] = title
            else:
                if info['origTitle']:
                    info['otherTitles'].append(info['origTitle'])
                info['origTitle'] = title
        Debug.log('r', 2, f'Title.movie_scrape(#{tid}): info.ruTitle={info["ruTitle"]}')
        Debug.log('r', 2, f'Title.movie_scrape(#{tid}): info.origTitle={info["origTitle"]}')
        Debug.log('r', 2, f'Title.movie_scrape(#{tid}): info.otherTitles={info["otherTitles"]}')
        # режиссер(ы):
        for director in list(map(str.strip, directors.split(','))):
            if '/' in director:
                info['Directors'].append({'ruName': director.partition('/')[0].strip(), 'enName': director.partition('/')[2].strip()})
            elif ' и др' in director:
                info['Directors'].append({'ruName': director.split(' и др', 1)[0].strip()})
            else:
                info['Directors'].append({'ruName': director.strip()})
        Debug.log('r', 2, f'Title.movie_scrape(#{tid}): info.Directors={info["Directors"]}')
        # год, странa, жанр, прочие тэги:
        for tag in list(map(str.strip, tags.split(','))):
            Debug.log('r', 3, f'Title.movie_scrape(#{tid}): tag={tag}')
            if not info.get('Year') and Scraper.RE_YEAR.match(tag):
                info['Year'] = int(tag[0:4])
                Debug.log('r', 2, f'Title.movie_scrape(#{tid}): info.Year={info["Year"]}')
            elif (tag.istitle() or tag.isupper()) and not info.get('Countries') and not info.get('Genres'):
                info['Countries'] = [tag]
                Debug.log('r', 2, f'Title.movie_scrape(#{tid}): info.Coutries={info["Countries"]}')
            elif not info.get('Genres') and not tag.istitle() and Scraper.is_rus(tag):
                info['Genres'] = [tag]
                Debug.log('r', 2, f'Title.movie_scrape(#{tid}): info.Genres={info["Genres"]}')
            elif not info.get('Quality'):
                subtags = tag.split(' ')
                Debug.log('r', 3, f'Title.movie_scrape(#{tid}): subtags={subtags}')
                for subtag in subtags:
                    info['Quality'] = next((entry for entry in Title.QUALITY if subtag.lower() in Title.QUALITY[entry]), None)
                    if info['Quality']:
                        Debug.log('r', 2, f'Title.movie_scrape(#{tid}): info.Quality={info["Quality"]}')
                        break
        # Фикс Countries у отечественных фильмов
        if (not info.get('Countries') and info.get('ruTitle') and not info.get('origTitle')):
            if info['Year'] >= 1924 and info['Year'] <= 1993:
                info['Countries'] = ['СССР']
            else:
                info['Countries'] = ['Россия']
        # Фикс Quality
        if not info.get('Quality'):
            info['Quality'] = 'SD'
        Debug.log('r', 2, f'Title.movie_scrape(#{tid}): info={info}')
        return info
