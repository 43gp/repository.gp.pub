# -*- coding: utf-8 -*-
"""Версии"""
VERSIONS = {
    'COOKIES': 1,
    'HISTORY': 1,
    'INDEX': 1,
    'INFO': 3,
    'TORRENTS': 1
}
