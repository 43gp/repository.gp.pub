# -*- coding: utf-8 -*-
"""IMDB scraper module"""
import json
from urllib.parse import urlencode

from debug import Debug
from network import Network, ReqParams
from scraper import Scraper


# pylint: disable=too-few-public-methods
class IMDB:
    """Скрапер IMDB"""
    BASE_URL = 'https://api.imdbapi.dev'
    SEARCH_URL = f'{BASE_URL}/search/titles?'
    MOVIE_URL = f'{BASE_URL}/titles/'

    ###
    def __init__(self, proxy):
        Debug.log('I', 2, f'IMDB.init({proxy=})')
        self.net_params = ReqParams(
                proxy=proxy,
                headers={'accept': 'application/json'},
        )

    ###
    @staticmethod
    def __get_persons(movie, tag):
        """Заполняет и возвращает словарь с описанием Режесеров/Сценаристов/Актеров"""
        persons = []
        for entry in movie.get(tag, []):
            person = Scraper.person_new()
            person['enName'] = entry.get('displayName', '')
            person['Img'] = Scraper.nested_get(entry, ['primaryImage', 'url'], '')
            persons.append(person)
        Debug.log('I', 3, f'IMDB.get_persons({tag}): {persons}')
        return persons

    def __getinfo(self, info, imdb_id):
        """
        Грузит инфу о imdb_id с сайта IMDb и возвращает ее в виде:
        {'success': True, 'info': {}}
        """
        result = {'success': False, 'info': {}}
        myinfo = Scraper.info_new()
        # AKAs
        response = Network.geturl(
                f'{IMDB.MOVIE_URL}{imdb_id}/akas',
                params=self.net_params
        )
        if response.status_code == 200:
            try:
                akas = Scraper.nested_get(json.loads(response.text), ['akas'], [])
            except json.JSONDecodeError as e:
                Debug.log('I', 0, f'IMDB.getinfo(#{info["Id"]}, {imdb_id}): AKAs bad response: {e}')
            if akas:
                Debug.log('I', 3, f'IMDB.getinfo(#{info["Id"]}, {imdb_id}): akas={akas}')
                title = [
                        n.get('text') for n in akas if
                            'country' in n and 
                            'code' in n['country'] and
                            n['country']['code'] in ['XWW']
                ]
                if title:
                    myinfo['origTitle'] = title[0]
                title = [
                        n.get('text') for n in akas if
                            'country' in n and 
                            'code' in n['country'] and
                            n['country']['code'] in ['RU']
                ]
                if title and Scraper.is_rus(title[0]):
                    myinfo['ruTitle'] = title[0]
        response = Network.geturl(
                f'{IMDB.MOVIE_URL}{imdb_id}',
                params=self.net_params
        )
        if response.status_code != 200:
            Debug.log('I', 0, f'IMDB.getinfo(#{info["Id"]}, {imdb_id}): request failed.')
            return result
        try:
            movie = json.loads(response.text)
        except json.JSONDecodeError as e:
            Debug.log('I', 0, f'IMDB.getinfo(#{info["Id"]}, {imdb_id}): bad response: {e}')
            return result
        result['success'] = True
        Debug.log('I', 3, f'IMDB.getinfo(#{info["Id"]}, {imdb_id}): json={response.text}')
        if movie.get('id') != imdb_id:
            Debug.log('I', 0, f'IMDB.getinfo(#{info["Id"]}, {imdb_id}): no or wrong id tag')
            return result
        myinfo['Id'] = info['Id']
        myinfo['imdbId'] = imdb_id
        myinfo['Scraper'] = Scraper.SCRAPERS['imdb']
        # Title
        if not myinfo['origTitle']:
            myinfo['origTitle'] = movie.get('primaryTitle', '')
        myinfo['Countries'] = [
            country['n']  for country in Scraper.COUNTRIES if country['c'] in
                [country.get('code', 'NO_KEY') for
                    country in movie.get('originCountries', [])]
        ]
        # XXXX: язык
        myinfo['Genres'] = movie.get('genres', [])
        myinfo['Plot'] = movie.get('plot', '')
        myinfo['Year'] = movie.get('startYear', 0)
        myinfo['Cover'] = Scraper.nested_get(movie, ['primaryImage', 'url'], '')
        myinfo['Directors'] = self.__get_persons(movie, 'directors')
        myinfo['Writers'] = self.__get_persons(movie, 'writers')
        myinfo['Artists'] = self.__get_persons(movie, 'stars')
        Scraper.is_success(myinfo)
        Debug.log('I', 3, f'IMDB.getinfo(#{info["Id"]}, {imdb_id}): {myinfo}')
        result['info'] = myinfo
        Debug.log('I', 1, f'IMDB.getinfo(#{info["Id"]}, {imdb_id}): {myinfo["Success"]}')
        return result

    ###
    def __search(self, info_id, query):
        """
        Запрашивает query у IMDb и возвращает словарь вида:
         {'success': True, 'imdb_ids': []}
        """
        result = {'success': False, 'imdb_ids': []}

        Debug.log('T', 3, f'IMDB.search(#{info_id}, {query})')
        response = Network.geturl(
                IMDB.SEARCH_URL + urlencode({'query': query}), params=self.net_params
        )
        if response.status_code != 200:
            Debug.log('T', 0, f'IMDB.search(#{info_id}, {query}): request failed.')
            return result
        Debug.log('T', 3, f'IMDB.search(#{info_id}, {query}): json={response.text}')
        try:
            titles = Scraper.nested_get(json.loads(response.text), ['titles'])
        except json.JSONDecodeError as e:
            Debug.log('I', 0, f'IMDB.search(#{info_id}, {query}): bad response: {e}')
            return result
        result['success'] = True
        if not titles:
            Debug.log('T', 1, f'IMDB.search(#{info_id}, {query}): not found.')
            return result
        # XXXX: проверять type???
        result['imdb_ids'] = [[d['id'] for d in titles][0]]
        Debug.log('I', 1, f'IMDB.search(#{info_id}, {query}): {result["imdb_ids"]}')
        return result

    ###
    def scrape(self, info):
        """
        Пытается найти данные по видео из info в базе IMDB
        {'success': True, 'info': {}}
        """
        imdb_id = info.get('imdbId')
        imdb_result = {'success': False, 'info': {}}
        if not imdb_id:
            Debug.log('I', 2, f'IMDB.scrape(#{info["Id"]}): searching imdbId')
            checked = []
            queries = [
                    f'"{info.get("origTitle")}",{info.get("Year")}' if
                        info.get('origTitle') and info.get('Year') else '',
                    f'"{info.get("ruTitle")}",{info.get("Year")}' if
                        info.get('ruTitle') and info.get('Year') else '',
            ] + [
                    f'"{other}",{info.get("Year")}' for other in
                        info.get('otherTitles') if info.get('Year')
            ] + [
                    f'"{info.get("origTitle")}"' if
                        info.get('origTitle') else '',
                    f'"{info.get("ruTitle")}"' if info.get('ruTitle') else '',
            ] + [
                    f'"{other}"' for other in info.get('otherTitles')
            ]
            Debug.log('K', 3, f'IMDB.scrape(#{info["Id"]}): queries={queries}')
            for query in queries:
                found = False
                if not query:
                    continue
                result = self.__search(info['Id'], query)
                imdb_result['success'] = result['success']
                if result['success']:
                    for imdb_id in result['imdb_ids']:
                        if imdb_id in checked:
                            continue
                        checked.append(imdb_id)
                        Debug.log('I', 2, f'IMDB.scrape(#{info["Id"]}): checking {imdb_id}')
                        imdb_result = self.__getinfo(info, imdb_id)
                        if (
                            imdb_result['success'] and
                            imdb_result['info'] and
                            Scraper.is_same(info, imdb_result['info'])
                        ):
                            Debug.log('I', 2, f'IMDB.scrape(#{info["Id"]}): hit {imdb_id}')
                            found = True
                            break
                if found:
                    break
                imdb_result['info'] = {}
        else:
            # imdbId известен
            Debug.log('I', 1, f'IMDB.scrape(#{info["Id"]}): {imdb_id}')
            imdb_result = self.__getinfo(info, imdb_id)
        return imdb_result
