# The contents of this file are subject to the BitTorrent Open Source License
# Version 1.1 (the License).  You may not copy or use this file, in either
# source code or executable form, except in compliance with the License.  You
# may obtain a copy of the License at http://www.bittorrent.com/license/.
#
# Software distributed under the License is distributed on an AS IS basis,
# WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
# for the specific language governing rights and limitations under the
# License.

# Written by Petru Paler

"""bencode.py - bencode encoder + decoder."""

from collections import OrderedDict

class BencodeDecodeError(Exception):
    """Decoder exception"""

__all__ = (
    'BencodeDecodeError',
    'bdecode',
    'decode'
)


def decode_int(x, f):
    """Decode torrent becncoded 'int' in x starting at f."""
    f += 1
    newf = x.index(b'e', f)
    n = int(x[f:newf])

    if x[f:f + 1] == b'-':
        if x[f + 1:f + 2] == b'0':
            raise ValueError
    elif x[f:f + 1] == b'0' and newf != f + 1:
        raise ValueError

    return n, newf + 1


def decode_string(x, f, try_decode_utf8=True, force_decode_utf8=False):
    """Decode torrent bencoded 'string' in x starting at f.

    An attempt is made to convert the string to a python string from utf-8.
    However, both string and non-string binary data is intermixed in the
    torrent bencoding standard. So we have to guess whether the byte
    sequence is a string or just binary data. We make this guess by trying
    to decode (from utf-8), and if that fails, assuming it is binary data.
    There are some instances where the data SHOULD be a string though.
    You can check enforce this by setting force_decode_utf8 to True. If the
    decoding from utf-8 fails, an UnidcodeDecodeError is raised. Similarly,
    if you know it should not be a string, you can skip the decoding
    attempt by setting try_decode_utf8=False.
    """
    colon = x.index(b':', f)
    n = int(x[f:colon])

    if x[f:f + 1] == b'0' and colon != f + 1:
        raise ValueError

    colon += 1
    s = x[colon:colon + n]

    if try_decode_utf8:
        try:
            return s.decode(encoding='utf-8', errors='replace'), colon + n
        except UnicodeDecodeError:
            if force_decode_utf8:
                raise

    return bytes(s), colon + n


def decode_list(x, f):
    """Decode bencoded data to an List"""
    r, f = [], f + 1

    while x[f:f + 1] != b'e':
        v, f = decode_func[x[f:f + 1]](x, f)
        r.append(v)

    return r, f + 1


def decode_dict(x, f, force_sort=True):
    """Decode bencoded data to an OrderedDict.

    The BitTorrent standard states that:
        Keys must be strings and appear in sorted order (sorted as raw
        strings, not alphanumerics)
    - http://www.bittorrent.org/beps/bep_0003.html

    Therefore, this function will force the keys to be strings (decoded
    from utf-8), and by default the keys are (re)sorted after reading.
    Set force_sort to False to keep the order of the dictionary as
    represented in x, as many other encoders and decoders do not force this
    property.
    """

    r, f = OrderedDict(), f + 1

    while x[f:f + 1] != b'e':
        k, f = decode_string(x, f, force_decode_utf8=True)
        r[k], f = decode_func[x[f:f + 1]](x, f)

    if force_sort:
        r = OrderedDict(sorted(r.items()))

    return r, f + 1


# noinspection PyDictCreation
decode_func = {}
decode_func[b'l'] = decode_list
decode_func[b'i'] = decode_int
decode_func[b'0'] = decode_string
decode_func[b'1'] = decode_string
decode_func[b'2'] = decode_string
decode_func[b'3'] = decode_string
decode_func[b'4'] = decode_string
decode_func[b'5'] = decode_string
decode_func[b'6'] = decode_string
decode_func[b'7'] = decode_string
decode_func[b'8'] = decode_string
decode_func[b'9'] = decode_string
decode_func[b'd'] = decode_dict

def bdecode(value):
    """
    Decode bencode formatted byte string ``value``.

    :param value: Bencode formatted string
    :type value: bytes

    :return: Decoded value
    :rtype: object
    """
    try:
        r, l = decode_func[value[0:1]](value, 0)
    except (IndexError, KeyError, TypeError, ValueError) as exc:
        raise BencodeDecodeError("not a valid bencoded string") from exc

    if l != len(value):
        raise BencodeDecodeError("invalid bencoded value (data after valid prefix)")

    return r

# Method proxies (for compatibility with other libraries)
decode = bdecode
