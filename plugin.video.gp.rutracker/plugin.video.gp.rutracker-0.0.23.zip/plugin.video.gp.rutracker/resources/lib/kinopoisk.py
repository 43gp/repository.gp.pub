# -*- coding: utf-8 -*-
"""KinoPoisk scraper module."""

import json

from debug import Debug
from network import Network, ReqParams
from scraper import Scraper

# pylint: disable=too-few-public-methods
class KinoPoisk:
    """ Скрапер Кинопоиска"""
    ###
    def __init__(self, proxy):
        """Инициализация модуля"""
        Debug.log('K', 2, f'KinoPoisk.init({proxy})')
        self.country = 1
        self.city= 2
        self.proxy = proxy
        self.url = 'https://graphql.kinopoisk.ru'
        self.net_params = ReqParams(
                 proxy=proxy,
                 headers={
                    'accept': 'application/json',
                    'user-agent': '"Android Tablet client (T40; Android 11; api30), ru.kinopoisk/6.112.1 (31733)"', # pylint: disable=line-too-long
                    'content-type': 'application/json; charset=utf-8',
                    'accept-encoding':'gzip',
                    'x-yandex-appinfo': 'eyJ2ZXJzaW9uIjoiNi4xMTIuMSJ9',
                    'service-id': '76',
                    'countryid': f'{self.country}',
                    'cityid': f'{self.city}',
                    'x-preferred-language': 'ru'
                },
        )

    def __getinfo(self, info, kpid):
        """
        Грузит инфу о kpid с сайта Кинопоиск и возвращает ее в виде:
        {'success': True, 'info': {}}
        """
        result = {'success': False, 'info': {}}
        movie = self.__loadinfo(info['Id'], kpid)
        if not movie:
            return result
        result['success'] = True
        myinfo = Scraper.info_new()
        myinfo['Id'] = info['Id']
        myinfo['kpId'] = kpid
        myinfo['Scraper'] = Scraper.SCRAPERS['kp']
        myinfo['ruTitle'] = Scraper.nested_get(movie, ['title', 'localized'], '')
        myinfo['origTitle'] = Scraper.nested_get(movie, ['title', 'original'], '')
        myinfo['Countries'] = [
                country['name'] for country in Scraper.nested_get(movie, ['countries'], [])
        ]
        myinfo['Genres'] = [
                genre['name'] for genre in Scraper.nested_get(movie, ['genres'], [])
        ]
        myinfo['Plot'] = Scraper.nested_get(movie, ['kpSynopsis'], '').replace('\xa0', ' ')
        # год.
        myinfo['Year'] = movie.get('kpYear', 0)
        if not myinfo.get('Year'):
            myinfo['Year'] = movie.get('productionYear', 0)
        if not myinfo.get('Year'):
            myinfo['Year'] = movie.get('fallbackYear', 0)
        if not myinfo.get('Year'):
            myinfo['Year'] = Scraper.nested_get(movie, ['releaseYears', 'start'], 0)
        # обложка.
        cover = Scraper.nested_get(
                movie,
                ['gallery', 'posters', 'kpVertical', 'avatarsUrl'], ''
        )
        if not cover:
            cover = Scraper.nested_get(
                movie,
                ['gallery', 'posters', 'vertical', 'avatarsUrl'], ''
        )
        if cover:
            myinfo['Cover'] = 'https:' + cover + '/orig'
        myinfo['Directors'] = self.__get_persons(movie, 'directors')
        myinfo['Writers'] = self.__get_persons(movie, 'writers')
        myinfo['Artists'] = self.__get_persons(movie, 'actors')
        Scraper.is_success(myinfo)
        Debug.log('K', 3, f'KinoPoisk.getinfo(#{info["Id"]}, {kpid}): {myinfo}')
        Debug.log('K', 1, f'KinoPoisk.getinfo(#{info["Id"]}, {kpid}): {myinfo["Success"]}')
        result['info'] = myinfo
        return result

    ###
    @staticmethod
    def __get_persons(movie, tag):
        """Заполняет и возвращает словарь с описанием Режиссеров/Сценаристов/Актеров"""
        persons = []
        for entry in Scraper.nested_get(movie, [tag, 'items'], []):
            role = Scraper.nested_get(entry, ['roleDetails'], '')
            if not role:
                role = Scraper.nested_get(entry, ['role'], '')
            if role and role in ['ACTOR', 'DIRECTOR', 'WRITER']:
                role = ''
            if Scraper.is_rus(Scraper.nested_get(entry, ['person', 'name'], '')):
                ru_name = Scraper.nested_get(entry, ['person', 'name'], '')
                en_name = ''
            else:
                ru_name = ''
                en_name = Scraper.nested_get(entry, ['person', 'name'], '')
            if not ru_name and Scraper.is_rus(Scraper.nested_get(entry, ['person', 'originalName'], '')): # pylint: disable=line-too-long
                ru_name = Scraper.nested_get(entry, ['person', 'originalName'], '')
            elif not en_name:
                en_name = Scraper.nested_get(entry, ['person', 'originalName'], '')
            poster = Scraper.nested_get(entry, ['person', 'poster', 'avatarsUrl'], '')
            if poster:
                if not poster.startswith('http'):
                    poster = 'https:' + poster
                poster = poster + '/orig'
            gender = Scraper.nested_get(entry, ['person', 'gender'])
            persons.append({
                'ruName': ru_name,
                'enName': en_name,
                'Gender': gender if gender else '',
                'Role': role,
                'Img': poster
            })
        Debug.log('K', 3, f'KinoPoisk.get_persons({tag}): {persons}')
        return persons

    ###
    def __loadinfo(self, tid, kpid):
        params = self.net_params
        params.data = json.dumps({'operationName': 'MovieDetails', 'variables': {'movieId': kpid, 'countryId': self.country, 'cityId': self.city, 'sequelsAndPrequelsLimit': 10, 'relatedMoviesLimit': 10, 'actorsLimit': 12, 'trailersLimit': 10, 'creatorsPerGroupLimit': 12, 'imagesPerGroupLimit': 10, 'factsLimit': 10, 'bloopersLimit': 10, 'criticReviewsLimit': 10, 'userReviewsLimit': 10, 'userRecommendationMoviesLimit': 10, 'postsLimit': 10, 'premieresLimit': 10, 'isAppendUserData': False, 'isInternationalUserData': False, 'movieListsLimit': 9, 'streamsLimit': 10, 'sequelsAndPrequelsRelationsOrder': ['AFTER', 'BEFORE'], 'relatedMoviesRelationsOrder': ['REMAKE', 'VERSION', 'SPOOFS', 'SPOOFED', 'SPIN_OFF', 'SPUN_OFF_FROM', 'REFERENCES', 'REFERENCES_IN', 'EDITED_FROM', 'EDITED_INTO', 'ALTERNATE_LANGUAGE'], 'friendsVotesLimit': 10, 'isTariffSubscriptionActive': True, 'mediaBillingTarget': 'kp-mobile-sdk-android-mooviecard', 'checkSilentInvoiceAvailability': True, 'isInternational': False, 'skipTrailers': False}, 'query': 'query MovieDetails($movieId: Long!, $countryId: Long!, $cityId: Int!, $sequelsAndPrequelsLimit: Int!, $relatedMoviesLimit: Int!, $actorsLimit: Int!, $trailersLimit: Int!, $creatorsPerGroupLimit: Int!, $imagesPerGroupLimit: Int!, $factsLimit: Int!, $bloopersLimit: Int!, $criticReviewsLimit: Int!, $userReviewsLimit: Int!, $userRecommendationMoviesLimit: Int!, $postsLimit: Int!, $premieresLimit: Int!, $isAppendUserData: Boolean!, $isInternationalUserData: Boolean!, $movieListsLimit: Int!, $streamsLimit: Int!, $sequelsAndPrequelsRelationsOrder: [RelatedMovieType!]!, $relatedMoviesRelationsOrder: [RelatedMovieType!]!, $friendsVotesLimit: Int!, $isTariffSubscriptionActive: Boolean!, $mediaBillingTarget: String!, $checkSilentInvoiceAvailability: Boolean!, $isInternational: Boolean!, $skipTrailers: Boolean!) { movie(id: $movieId) { __typename id contentId url userData @include(if: $isAppendUserData) { __typename ... movieFullUserDataFragment } editorAnnotation gallery { __typename posters { __typename ... moviePostersFragment kpVertical: vertical(override: DISABLED) @skip(if: $isInternational) { __typename ... imageFragment } } covers { __typename square { __typename ... imageFragment } horizontal { __typename ... imageFragment } } logos { __typename rightholderForPoster { __typename ... imageFragment } rightholderForCover(filter: {formFactor: S, theme: LIGHT}) { __typename image { __typename ... imageFragment } } } } ... movieLogoFragment rating @skip(if: $isInternational) { __typename ... fullRatingFragment } title { __typename ... titleFragment } ... movieDetailsImagesFragment @skip(if: $isInternational) viewOption { __typename ... viewOptionDetailedFragment } releaseOptions { __typename ... movieReleaseOptionsFragment } ... movieDetailsCreatorsFragment @skip(if: $isInternational) countries { __typename ... countryFragment } ...movieDetailsDurationFragment genres { __typename ... genreFragment } restriction { __typename ... restrictionFragment } distribution @skip(if: $isInternational) { __typename ... distributionFragment } kpSynopsis: synopsis(override: DISABLED) @skip(if: $isInternational) ottSynopsis: synopsis(override: OTT_WHEN_EXISTS) shortDescription isTicketsAvailableByKpCityId(kpCityId: $cityId) @skip(if: $isInternational) ... movieDetailsActorsFragment ... movieDetailsWatchabilityFragment @skip(if: $isInternational) mainTrailer @skip(if: $skipTrailers) { __typename ... trailerFragment } trailers(limit: $trailersLimit, orderBy: IS_MAIN_MAKE_DATE_DESC) @skip(if: $skipTrailers) { __typename total items { __typename ... trailerFragment } } facts: trivias(type: FACT, limit: $factsLimit) @skip(if: $isInternational) { __typename total items { __typename ... triviaFragment } } bloopers: trivias(type: BLOOPER, limit: $bloopersLimit) @skip(if: $isInternational) { __typename total items { __typename ... triviaFragment } } ... movieTopsFragment ... movieDetailsSequelsAndPrequelsFragment @skip(if: $isInternational) ... movieDetailsRelatedMoviesFragment @skip(if: $isInternational) ... movieOttFragment ... movieOttTrailersFragment ... movieYearsFragment ... on VideoInterface @skip(if: $isInternational) { kpYear: productionYear(override: DISABLED) } ... movieEpisodesFragment posts: post(mainOnly: true, limit: $postsLimit) @skip(if: $isInternational) { __typename total items { __typename ... postFragment } } ... reviewsFragment @skip(if: $isInternational) ... movieDetailsAwardsFragment @skip(if: $isInternational) dvdSales @skip(if: $isInternational) { __typename totalAmount { __typename ... moneyAmountFragment } } boxOffice @skip(if: $isInternational) { __typename budget { __typename ... moneyAmountFragment } marketing { __typename ... moneyAmountFragment } rusBox { __typename ... moneyAmountFragment } usaBox { __typename ... moneyAmountFragment } worldBox { __typename ... moneyAmountFragment } } userRecommendations(limit: $userRecommendationMoviesLimit) @skip(if: $isInternational) { __typename total items { __typename movie { __typename ... movieSummaryFragment } } } movieLists(limit: $movieListsLimit) @skip(if: $isInternational) { __typename total items { __typename ... movieListRelationFragment } } } } fragment movieLogoFragment on Movie { __typename gallery { __typename logos { __typename horizontal { __typename ... imageFragment origSize { __typename width height } } } } } fragment movieDetailsImagesFragment on Movie { __typename gallery { __typename filteredImagesTotal: images(types: [STILL, SHOOTING, POSTER], offset: 0, limit: 0) { __typename total } filteredImagesStill: images(types: [STILL], offset: 0, limit: $imagesPerGroupLimit) { __typename ... movieImageCollectionFragment } filteredImagesShooting: images(types: [SHOOTING], offset: 0, limit: $imagesPerGroupLimit) { __typename ... movieImageCollectionFragment } filteredImagesPosters: images(types: [POSTER], offset: 0, limit: $imagesPerGroupLimit) { __typename ... movieImageCollectionFragment } } } fragment movieDetailsCreatorsFragment on Movie { __typename directors: members(role: [DIRECTOR], offset: 0, limit: $creatorsPerGroupLimit) { __typename ... membersListFragment } producers: members(role: [PRODUCER], offset: 0, limit: $creatorsPerGroupLimit) { __typename ... membersListFragment } writers: members(role: [WRITER], offset: 0, limit: $creatorsPerGroupLimit) { __typename ... membersListFragment } operators: members(role: [OPERATOR], offset: 0, limit: $creatorsPerGroupLimit) { __typename ... membersListFragment } composers: members(role: [COMPOSER], offset: 0, limit: $creatorsPerGroupLimit) { __typename ... membersListFragment } artists: members(role: [ART], offset: 0, limit: $creatorsPerGroupLimit) { __typename ... membersListFragment } editors: members(role: [EDITOR], offset: 0, limit: $creatorsPerGroupLimit) { __typename ... membersListFragment } others: members(role: [CAMEO, COSTUMER, DECORATOR, DESIGN, TRANSLATOR, VOICEOVER, VOICE_DIRECTOR], offset: 0, limit: $creatorsPerGroupLimit) { __typename ... membersListFragment } } fragment movieDetailsDurationFragment on Movie { __typename ... on Film { duration: duration } ... on TvSeries { duration: seriesDuration } ... on MiniSeries { duration: seriesDuration } ... on Video { duration: duration } ... on TvShow { duration: seriesDuration } } fragment movieDetailsActorsFragment on Movie { __typename actors: members(role: [ACTOR, CAMEO, GROUP_CAMEO, VOICEOVER, UNCREDITED, GROUP_UNCREDITED], limit: $actorsLimit, orderBy: BY_ROLE_POSITION_BY_CREW_PRIORITY) { __typename total items { __typename ... movieCrewMemberSummaryFragment } } } fragment movieDetailsWatchabilityFragment on Movie { __typename watchability { __typename total } } fragment movieTopsFragment on Movie { __typename top10 ... on Film @skip(if: $isInternational) { top250 } ... on TvSeries @skip(if: $isInternational) { top250 } ... on MiniSeries @skip(if: $isInternational) { top250 } ... on TvShow @skip(if: $isInternational) { top250 } } fragment movieDetailsSequelsAndPrequelsFragment on Movie { __typename sequelsAndPrequels: relatedMovies(orderBy: PREMIERE_DATE_ASC, offset: 0, limit: $sequelsAndPrequelsLimit, type: $sequelsAndPrequelsRelationsOrder) { __typename total items { __typename movie { __typename ... movieSummaryFragment } } } } fragment movieDetailsRelatedMoviesFragment on Movie { __typename related: relatedMovies(orderBy: TYPE_POSITION__MOVIE_ID_ASC, offset: 0, limit: $relatedMoviesLimit, type: $relatedMoviesRelationsOrder) { __typename total items { __typename relationType movie { __typename ... movieSummaryFragment } } } } fragment movieOttFragment on Movie { __typename ott { __typename preview { __typename ...previewFeatureFragment streams(filter: {isSupportedByClient: true}, offset: 0, limit: $streamsLimit) { __typename ...movieOttStreamsFragment } } ... movieOttNextEpisodeFragment } } fragment movieOttTrailersFragment on Movie { __typename ott { __typename promoTrailer: trailers(onlyPromo: true, limit: 1) { __typename items { __typename ...ottTrailerFragment } } ottTrailers: trailers(limit: 10) @include(if: $isInternational) { __typename items { __typename main ...ottTrailerFragment } } } } fragment movieYearsFragment on Movie { __typename ... on VideoInterface { productionYear(override: OTT_WHEN_EXISTS) } ... on Series { fallbackYear: productionYear releaseYears { __typename start end } } } fragment movieEpisodesFragment on Movie { __typename ... on MiniSeries { episodesCount seasons { __typename total } } ... on TvSeries { episodesCount seasons { __typename total } } ... on TvShow { episodesCount seasons { __typename total } } } fragment reviewsFragment on Movie { __typename criticReviews(limit: $criticReviewsLimit, orderBy: TEXT_DATE_DESC) { __typename total items { __typename ... criticReviewFragment } } criticReviewsTotalPositive: criticReviews(types: [POSITIVE]) { __typename total } criticReviewsTotalNegative: criticReviews(types: [NEGATIVE]) { __typename total } ... userReviewsFragment userReviewsTotalPositive: userReviews(types: [POSITIVE]) { __typename total } userReviewsTotalNegative: userReviews(types: [NEGATIVE]) { __typename total } userReviewsTotalNeutral: userReviews(types: [NEUTRAL]) { __typename total } } fragment movieDetailsAwardsFragment on Movie { __typename mainAwardsInfo: awards(offset: 0, limit: 1, isMain: true, orderBy: WIN_FIRST_YEAR_DESC_NOMINATION_ASC) { __typename total items { __typename ... movieAwardNomineeFragment } } mainAndWinAwardsInfo: awards(offset: 0, limit: 1, isMain: true, isWin: true, orderBy: WIN_FIRST_YEAR_DESC_NOMINATION_ASC) { __typename total } allAwardsInfo: awards(offset: 0, limit: 0, orderBy: WIN_FIRST_YEAR_DESC_NOMINATION_ASC) { __typename total } } fragment imageFragment on Image { __typename avatarsUrl fallbackUrl } fragment movieImageCollectionFragment on PagingList_MovieImage { __typename total offset limit items { __typename ... movieImageFragment } } fragment movieImageFragment on MovieImage { __typename type copyright author { __typename login } image { __typename origSize { __typename width height } ... imageFragment } } fragment membersListFragment on PagingList_FilmCrewMember { __typename total items { __typename ... movieCrewMemberFragment } } fragment movieCrewMemberFragment on FilmCrewMember { __typename role roleDetails: details person { __typename ... personSummaryFragment bestFilms: bestMovies(type: FILM) { __typename ... bestMoviesFilmpographyListFragment } bestSeries: bestMovies(type: SERIES) { __typename ... bestMoviesFilmpographyListFragment } } } fragment personSummaryFragment on Person { __typename id name gender originalName dateOfBirth { __typename ...incompleteDateFragment } dateOfDeath { __typename ...incompleteDateFragment } age poster { __typename ...imageFragment } published } fragment incompleteDateFragment on IncompleteDate { __typename date accuracy } fragment bestMoviesFilmpographyListFragment on PagingList_PersonBestMovie { __typename items { __typename movie { __typename id title { __typename ...titleFragment } rating { __typename ... ratingFragment } } } } fragment titleFragment on Title { __typename localized original } fragment ratingFragment on Rating { __typename kinopoisk { __typename ... ratingValueFragment } expectation { __typename ... ratingValueFragment } } fragment ratingValueFragment on RatingValue { __typename isActive count value(precision: 1) } fragment movieCrewMemberSummaryFragment on FilmCrewMember { __typename role roleDetails: details person { __typename ... personSummaryFragment } } fragment movieSummaryFragment on Movie { __typename id gallery { __typename posters { __typename ... moviePostersFragment } } genres { __typename ... genreFragment } title { __typename ... titleFragment } rating { __typename ... ratingFragment } } fragment genreFragment on Genre { __typename name } fragment moviePostersFragment on MoviePosters { __typename vertical(override: OTT_WHEN_EXISTS) { __typename ... imageFragment } verticalWithRightholderLogo { __typename ... imageFragment } } fragment movieOttNextEpisodeFragment on Ott_AbstractSeries { __typename nextEpisode @include(if: $isAppendUserData) { __typename episode { __typename contentId number season { __typename number } } } } fragment previewFeatureFragment on OttPreview { __typename features(filter: {layout: OTT_TITLE_CARD}) { __typename alias displayName group } } fragment movieOttStreamsFragment on PagingList_OttStream { __typename items { __typename audioMetas { __typename languageName quality studio forAdult } subtitleMetas { __typename languageName studio forAdult type } videoMetas { __typename dynamicRange } videoDescriptorName } } fragment ottTrailerFragment on OttTrailer { __typename streamUrl contentGroupUuid } fragment userReviewsFragment on Movie { __typename userReviews(limit: $userReviewsLimit, orderBy: TOP_USEFULNESS_THEN_CREATED_AT_DESC) { __typename total items { __typename ... userReviewFragment } } } fragment criticReviewFragment on CriticReview { __typename id text author { __typename id firstName lastName } source { __typename icon { __typename ... imageFragment } title } sourceUrl type } fragment userReviewFragment on UserReview { __typename id text title createdAt author { __typename id avatar { __typename ... imageFragment } login } type votes { __typename positiveCount negativeCount } userData @include(if: $isAppendUserData) { __typename ... on UserReviewUserData { voting } } } fragment movieAwardNomineeFragment on MovieAwardNominee { __typename nomination { __typename ... nominationFragment } win awardImage: image { __typename ... imageFragment } persons(offset: 0, limit: 10) { __typename items { __typename ... personSummaryFragment } } } fragment nominationFragment on AwardNomination { __typename title award { __typename ... awardFragment } } fragment awardFragment on Award { __typename title year } fragment movieFullUserDataFragment on MovieUserData { __typename ... movieUserDataFragment friendsVoting(orderBy: VOTE_VALUE_DESC, limit: $friendsVotesLimit) @skip(if: $isInternationalUserData) { __typename averageVote total items { __typename ... friendVoteFragment } } } fragment movieUserDataFragment on MovieUserData { __typename isPlannedToWatch folders @skip(if: $isInternationalUserData) { __typename ... folderFragment } voting @skip(if: $isInternationalUserData) { __typename ... voteFragment } expectation @skip(if: $isInternationalUserData) { __typename value } watchStatuses { __typename ...watchStatusesFragment } } fragment friendVoteFragment on FriendVote_Friend { __typename attitude friend { __typename user { __typename ... userFragment } } vote { __typename ... voteFragment } } fragment voteFragment on Vote { __typename value } fragment userFragment on User { __typename login avatar { __typename ... imageFragment } } fragment folderFragment on Folder { __typename id name } fragment watchStatusesFragment on WatchStatuses { __typename notInterested { __typename value } watched { __typename value } } fragment fullRatingFragment on Rating { __typename kinopoisk { __typename ... ratingValueFragment } expectation { __typename ... percentRatingValueFragment } imdb { __typename ... ratingValueFragment } worldwideCritics { __typename ... ratingWithVotesValueFragment } russianCritics { __typename ... percentRatingValueFragment } positiveReviewRate { __typename ... percentRatingValueFragment } } fragment percentRatingValueFragment on RatingValue { __typename isActive count value(precision: 0) } fragment ratingWithVotesValueFragment on RatingWithVotesValue { __typename isActive count value } fragment viewOptionDetailedFragment on ViewOption { __typename ... movieViewOptionSummaryFragment purchaseRejectionReason { __typename ... watchingRejection } watchingRejectionReason { __typename ... watchingRejection } downloadRejectionReason { __typename ... watchingRejection } subscriptionCompositeOffers(mediaBillingTarget: $mediaBillingTarget, checkSilentInvoiceAvailability: $checkSilentInvoiceAvailability) @include(if: $isTariffSubscriptionActive) { __typename ... subscriptionOfferCompositeDataFragment } watchPeriod { __typename ...movieWatchPeriodFragment } texts { __typename ...viewOptionsTextFragment } descriptionText mainPromotionAbsoluteAmount { __typename ... moneyAmountFragment } mastercardPromotionAbsoluteAmount { __typename ... moneyAmountFragment } } fragment movieViewOptionSummaryFragment on ViewOption { __typename type purchasabilityStatus isWatchableOnDeviceInCurrentRegion: isWatchable(filter: {anyDevice: false, anyRegion: false}) subscriptionPurchaseTag buttonText ... movieViewOptionPurchasedSubscriptionFragment availabilityAnnounce { __typename ... availabilityAnnounceFragment } contentPackageToBuy { __typename ... movieContentPackageFragment } contentPackageToUnfreeze { __typename ... movieContentPackageFragment } transactionalPrice { __typename ... moneyAmountFragment } transactionalMinimumPrice { __typename ... moneyAmountFragment } priceWithTotalDiscount { __typename ... moneyAmountFragment } optionMonetizationModels watchabilityStatus promotionActionType downloadabilityStatus } fragment watchingRejection on WatchingRejection { __typename details reason } fragment subscriptionOfferCompositeDataFragment on SubscriptionCompositeOffers { __typename batchPositionId offers { __typename ... subscriptionOfferCompositeOffersFragment customPayload { __typename ... subscriptionOfferCustomPayloadFragment } } } fragment subscriptionOfferCompositeOffersFragment on OttCompositeOffer { __typename compositeOffer { __typename forActiveOffers { __typename ... subscriptionOfferForActiveOffersFragment } structureType tariffOffer { __typename ... subscriptionOfferTariffFragment } optionOffers { __typename ... subscriptionOfferOptionFragment } positionId silentInvoiceAvailable } } fragment subscriptionOfferForActiveOffersFragment on PlusOfferUnion { __typename ... on PlusOptionOffer { ... subscriptionOfferOptionFragment } ... on PlusTariffOffer { ... subscriptionOfferTariffFragment } } fragment subscriptionOfferOptionFragment on PlusOptionOffer { __typename additionText description name title text option { __typename name } plans { __typename } } fragment subscriptionOfferTariffFragment on PlusTariffOffer { __typename additionText description name title text tariff { __typename name } plans { __typename } } fragment subscriptionOfferCustomPayloadFragment on OttCompositeOfferCustomPayload { __typename overridedAdditionalText overridedText overridedTarget } fragment movieWatchPeriodFragment on WatchPeriod { __typename timeToExpire watchPeriodStatus } fragment viewOptionsTextFragment on ViewOptionText { __typename disclaimer } fragment moneyAmountFragment on MoneyAmount { __typename amount currency { __typename ... currencyFragment } } fragment currencyFragment on Currency { __typename symbol } fragment movieViewOptionPurchasedSubscriptionFragment on ViewOption { __typename purchasedSubscriptionTextId purchasedSubscriptionName } fragment availabilityAnnounceFragment on AvailabilityAnnounce { __typename announcePromise availabilityDate type } fragment movieContentPackageFragment on ContentPackage { __typename billingFeatureName } fragment movieReleaseOptionsFragment on ReleaseOptions { __typename is3d isImax } fragment countryFragment on Country { __typename id name } fragment restrictionFragment on Restriction { __typename age mpaa } fragment distributionFragment on Distribution { __typename countrySpecificPremiere: premieres(limit: 1, countryId: $countryId) { __typename items { __typename ... moviePremiereFragment } } worldPremiere { __typename ... moviePremiereFragment } allReleases: releases(types: [BLURAY, DIGITAL, DVD]) { __typename items { __typename ... movieDetailsReleaseFragment } } premieres(limit: $premieresLimit) { __typename items { __typename ... moviePremiereFragment } } } fragment moviePremiereFragment on Premiere { __typename country { __typename ...countryFragment } incompleteDate { __typename ...incompleteDateFragment } } fragment movieDetailsReleaseFragment on Release { __typename type companies { __typename displayName } country { __typename ... countryFragment } date { __typename ...incompleteDateFragment } } fragment trailerFragment on Trailer { __typename id title isMain createdAt duration movie { __typename id } preview { __typename ... imageFragment } streamUrl } fragment triviaFragment on Trivia { __typename id isSpoiler text type } fragment postFragment on Post { __typename id title publishedAt commentsCount coverImage { __typename ... imageFragment } thumbImage { __typename ... imageFragment } } fragment movieListRelationFragment on MovieListRelation { __typename position movieList { __typename ... movieListFragment movies(offset: 0, limit: 0) { __typename total } } } fragment movieListFragment on MovieListMeta { __typename id autoList name description url cover { __typename ... imageFragment } }'}) # pylint: disable=line-too-long
        response = Network.geturl(
                self.url + '/graphql?operationName=MovieDetails',
                method='POST',
                params=params
        )
        if response.status_code != 200:
            Debug.log('K', 0, f'KinoPoisk.loadinfo(#{tid}, kpid): request failed.')
            return {}
        try:
            movie = Scraper.nested_get(json.loads(response.text), ['data', 'movie'], {})
        except json.JSONDecodeError as e:
            Debug.log('K', 0, f'KinoPoisk.loadinfo(#{tid}, {kpid}): bad response: {e}')
            movie = {}
        if not movie:
            Debug.log('K', 0, f'KinoPoisk.loadinfo(#{tid}, {kpid}): bad response {response.text}')
        return movie

    ###
    def __search(self, info_id, query):
        """
        Отправляет query на Кинопоиск и возвращает словарь вида:
         {'success': bool, 'kpids': []}
        """
        result = {'success': False, 'kpids': []}
        qparams = self.net_params
        qparams.data = json.dumps({'operationName': 'SearchGlobalV2', 'variables': {'keyword': query, 'groupLimit': 3, 'regionId': self.city, 'latitude': None, 'longitude': None, 'includeMovieTops': False, 'includeMovieRating': True, 'includeSeriesSeasonsCount': False, 'includeFilmDuration': False, 'includeMovieHorizontalCover': False, 'includeMovieHorizontalLogo': False, 'includeMovieRightholderForPoster': True, 'includeMovieUserVote': False, 'includeMovieUserPlannedToWatch': False, 'includeMovieUserFolders': False, 'includeMovieUserWatched': False, 'includeMovieUserNotInterested': False, 'includeCinemaUserData': False, 'includeMovieListMetaTotal': True, 'includePersonAgeAndDates': True, 'includeMovieContentFeatures': False, 'includeMovieOnlyClientSupportedContentFeatures': False, 'includeMovieViewOption': True, 'includeMovieTop250': False}, 'query': 'query SearchGlobalV2($keyword: String!, $groupLimit: Int!, $regionId: Int, $latitude: String, $longitude: String, $includeMovieTops: Boolean!, $includeMovieRating: Boolean!, $includeSeriesSeasonsCount: Boolean!, $includeFilmDuration: Boolean!, $includeMovieHorizontalCover: Boolean!, $includeMovieHorizontalLogo: Boolean!, $includeMovieRightholderForPoster: Boolean!, $includeMovieUserVote: Boolean!, $includeMovieUserPlannedToWatch: Boolean!, $includeMovieUserFolders: Boolean!, $includeMovieUserWatched: Boolean!, $includeMovieUserNotInterested: Boolean!, $includeCinemaUserData: Boolean!, $includeMovieListMetaTotal: Boolean!, $includePersonAgeAndDates: Boolean!, $includeMovieContentFeatures: Boolean!, $includeMovieOnlyClientSupportedContentFeatures: Boolean, $includeMovieViewOption: Boolean!, $includeMovieTop250: Boolean!) { search(keyword: $keyword) { mostRelevant: global(types: [MOVIE,PERSON,CINEMA,MOVIE_LIST], offset: 0, limit: 1, regionID: $regionId, latitude: $latitude, longitude: $longitude) { items { global { __typename ...movieSummaryFragment ...personSummaryFragment ...cinemaSummaryFragment ...movieListMetaBaseFragment } } } movies(offset: 0, limit: $groupLimit) { limit total items { movie { __typename ...movieSummaryFragment } } } persons(offset: 0, limit: $groupLimit) { limit total items { person { __typename ...personSummaryFragment } } } cinemas(offset: 0, limit: $groupLimit, regionID: $regionId, latitude: $latitude, longitude: $longitude) { limit total items { cinema { __typename ...cinemaSummaryFragment } } } movieLists(offset: 0, limit: $groupLimit) { limit total items { movieList { __typename ...movieListMetaBaseFragment } } } } }  fragment movieYearsFragment on Movie { __typename ... on VideoInterface { productionYear(override: OTT_WHEN_EXISTS) } ... on Series { fallbackYear: productionYear releaseYears { start end } } }  fragment movieTopsFragment on Movie { top10 top250 @include(if: $includeMovieTop250) }  fragment imageFragment on Image { avatarsUrl fallbackUrl }  fragment baseMoviePostersFragment on MoviePosters { vertical(override: OTT_WHEN_EXISTS) { __typename ...imageFragment } verticalWithRightholderLogo { __typename ...imageFragment } horizontal { __typename ...imageFragment } horizontalWithRightholderLogo { __typename ...imageFragment } }  fragment movieIntroPostersFragment on MoviePosters { verticalIntro { __typename ...imageFragment } verticalIntroWithRightholderLogo { __typename ...imageFragment } horizontalIntro { __typename ...imageFragment } horizontalIntroWithRightholderLogo { __typename ...imageFragment } }  fragment moviePostersFragment on MoviePosters { __typename ...baseMoviePostersFragment ...movieIntroPostersFragment }  fragment imageWithSizeFragment on Image { __typename ...imageFragment origSize { width height } }  fragment titleFragment on Title { localized original }  fragment genreFragment on Genre { name }  fragment countryFragment on Country { id name }  fragment ratingValueFragment on RatingValue { isActive count value(precision: 1) }  fragment ratingFragment on Rating { kinopoisk { __typename ...ratingValueFragment } expectation { __typename ...ratingValueFragment } }  fragment movieViewOptionPurchasedSubscriptionFragment on ViewOption { purchasedSubscriptionTextId purchasedSubscriptionName }  fragment availabilityAnnounceFragment on AvailabilityAnnounce { announcePromise availabilityDate type }  fragment movieContentPackageFragment on ContentPackage { billingFeatureName }  fragment currencyFragment on Currency { symbol currencyCode }  fragment moneyAmountFragment on MoneyAmount { amount currency { __typename ...currencyFragment } }  fragment movieViewOptionSummaryFragment on ViewOption { __typename type purchasabilityStatus isWatchableOnDeviceInCurrentRegion: isWatchable(filter: { anyDevice: false anyRegion: false } ) subscriptionPurchaseTag buttonText ...movieViewOptionPurchasedSubscriptionFragment availabilityAnnounce { __typename ...availabilityAnnounceFragment } contentPackageToBuy { __typename ...movieContentPackageFragment } contentPackageToUnfreeze { __typename ...movieContentPackageFragment } transactionalPrice { __typename ...moneyAmountFragment } transactionalMinimumPrice { __typename ...moneyAmountFragment } priceWithTotalDiscount { __typename ...moneyAmountFragment } optionMonetizationModels watchabilityStatus watchabilityExpirationTime promotionActionType downloadabilityStatus }  fragment restrictionFragment on Restriction { age mpaa }  fragment voteFragment on Vote { value }  fragment movieUserVoteFragment on MovieUserData { voting { __typename ...voteFragment } expectation { value } }  fragment movieFolderFragment on Folder { id name public }  fragment movieUserFoldersFragment on MovieUserData { userFolders { items { __typename ...movieFolderFragment } } }  fragment movieUserWatchedFragment on MovieUserData { watchStatuses { watched { value } } }  fragment movieUserNotInterestedFragment on MovieUserData { watchStatuses { notInterested { value } } }  fragment movieContentFeaturesFragment on Ott { preview { features(filter: { layout: OTT_TITLE_CARD onlyClientSupported: $includeMovieOnlyClientSupportedContentFeatures } ) { group alias displayName } } }  fragment movieDurationFragment on Movie { ott { preview { __typename ... on OttPreview_AbstractVideo { duration } } } }  fragment movieSummaryFragment on Movie { __typename id contentId url ...movieYearsFragment ...movieTopsFragment @include(if: $includeMovieTops) gallery { posters { __typename ...moviePostersFragment } logos @include(if: $includeMovieRightholderForPoster) { rightholderForPoster { __typename ...imageFragment } } logos @include(if: $includeMovieHorizontalLogo) { horizontal { __typename ...imageWithSizeFragment } } covers @include(if: $includeMovieHorizontalCover) { horizontal { __typename ...imageFragment } } } title { __typename ...titleFragment } genres { __typename ...genreFragment } countries { __typename ...countryFragment } rating @include(if: $includeMovieRating) { __typename ...ratingFragment } viewOption @include(if: $includeMovieViewOption) { __typename ...movieViewOptionSummaryFragment } restriction { __typename ...restrictionFragment } movieUserVote: userData @include(if: $includeMovieUserVote) { __typename ...movieUserVoteFragment } movieUserPlannedToWatch: userData @include(if: $includeMovieUserPlannedToWatch) { isPlannedToWatch } movieUserFolders: userData @include(if: $includeMovieUserFolders) { __typename ...movieUserFoldersFragment } movieUserWatched: userData @include(if: $includeMovieUserWatched) { __typename ...movieUserWatchedFragment } movieUserNotInterested: userData @include(if: $includeMovieUserNotInterested) { __typename ...movieUserNotInterestedFragment } movieContentFeatures: ott @include(if: $includeMovieContentFeatures) { __typename ...movieContentFeaturesFragment } ... on Series @include(if: $includeSeriesSeasonsCount) { seasonsCount: seasons(offset: 0, limit: 0) { total } } ...movieDurationFragment @include(if: $includeFilmDuration) }  fragment personNameFragment on Person { name originalName }  fragment incompleteDateFragment on IncompleteDate { date accuracy }  fragment personSummaryFragment on Person { __typename id ...personNameFragment gender poster { __typename ...imageFragment } age @include(if: $includePersonAgeAndDates) dateOfBirth @include(if: $includePersonAgeAndDates) { __typename ...incompleteDateFragment } dateOfDeath @include(if: $includePersonAgeAndDates) { __typename ...incompleteDateFragment } published }  fragment cityFragment on City { geoId id name }  fragment locationFragment on Location { latitude longitude }  fragment cinemaUserDataFragment on CinemaUserData { isFavorite }  fragment cinemaSummaryFragment on Cinema { id cinemaTitle: title city { __typename ...cityFragment } address location { __typename ...locationFragment } cinemaUserData: userData @include(if: $includeCinemaUserData) { __typename ...cinemaUserDataFragment } }  fragment movieListMetaBaseFragment on MovieListMeta { id autoList name description url cover { __typename ...imageFragment } moviesCount: movies(offset: 0, limit: 0) @include(if: $includeMovieListMetaTotal) { total } }'}) # pylint: disable=line-too-long
        response = Network.geturl(
                self.url + '/graphql?operationName=SearchGlobalV2',
                method='POST',
                params=qparams
        )
        if response.status_code != 200:
            Debug.log('K', 0, f'KinoPoisk.search(#{info_id}, {query}): request failed.')
            return result
        try:
            movies = Scraper.nested_get(
                    json.loads(response.text),
                    ['data', 'search', 'movies', 'items'],
                    []
            )
        except json.JSONDecodeError as e:
            Debug.log('K', 0, f'KinoPoisk.search(#{info_id}, {query}): bad response: {e}')
            Debug.log('K', 3, f'KinoPoisk.search(#{info_id}, {query}): json={response.text}')
            return result
        result['success'] = True
        for movie in movies:
            if Scraper.nested_get(movie, ['movie', 'id'], 0) > 0:
                result['kpids'].append(Scraper.nested_get(movie, ['movie', 'id'], 0))
        Debug.log('K', 1, f'KinoPoisk.search(#{info_id}, {query}): {result["kpids"]}')
        return result

    ###
    def scrape(self, info):
        """
        Пытается найти данные по видео из info на Кинопоиске
        {'success': True, 'info': {}}
        """
        kpid = info.get('kpId')
        kp_result = {'success': False, 'info': {}}
        if not kpid:
            Debug.log('K', 2, f'KinoPoisk.scrape(#{info["Id"]}): searching kpId')
            checked = []
            queries = [
                    f'"{info.get("origTitle")}",{info.get("Year")}' if
                        info.get('origTitle') and info.get('Year') else '',
                    f'"{info.get("ruTitle")}",{info.get("Year")}' if
                        info.get('ruTitle') and info.get('Year') else '',
            ] + [
                    f'"{other}",{info.get("Year")}' for other in
                    info.get('otherTitles') if info.get('Year')
            ] + [
                    f'"{info.get("origTitle")}"' if info.get('origTitle') else '',
                    f'"{info.get("ruTitle")}"' if info.get('ruTitle') else '',
            ] + [
                    f'"{other}"' for other in info.get('otherTitles')
            ]
            Debug.log('K', 3, f'KinoPoisk.scrape(#{info["Id"]}): {queries=}')
            for query in queries:
                found = False
                if not query:
                    continue
                result = self.__search(info['Id'], query)
                kp_result['success'] = result['success']
                if result['success']:
                    for kpid in result['kpids']:
                        if kpid in checked:
                            continue
                        checked.append(kpid)
                        Debug.log('K', 2, f'KinoPoisk.scrape(#{info["Id"]}): checking {kpid}')
                        kp_result = self.__getinfo(info, kpid)
                        if (
                                kp_result['success'] and
                                kp_result['info'] and
                                Scraper.is_same(info, kp_result['info'])
                        ):
                            Debug.log('K', 2, f'KinoPoisk.scrape(#{info["Id"]}): hit {kpid}')
                            found = True
                            break
                if found:
                    break
                kp_result['info'] = {}
        else:
            # kpId известен
            kp_result = self.__getinfo(info, kpid)
        Debug.log('K', 1,
                f'KinoPoisk.scrape(#{info["Id"]}): '
                f'{kp_result["success"]}/{kp_result["info"].get("Success", False)}'
        )
        return kp_result

    ###
    def trailers(self, tid, kpid):
        """Возвращает список доступных трейлеров для kpid в виде {title, url}"""
        movie = self.__loadinfo(tid, kpid)
        if not movie:
            return []
        trailers = []
        for trailer in Scraper.nested_get(movie, ['trailers', 'items'], []):
            trailers.append({'title': trailer.get('title'), 'url': trailer.get('streamUrl')})
        Debug.log('K', 2, f'KinoPoisk.trailers(#{tid}, {kpid}): {trailers=}')
        return trailers
