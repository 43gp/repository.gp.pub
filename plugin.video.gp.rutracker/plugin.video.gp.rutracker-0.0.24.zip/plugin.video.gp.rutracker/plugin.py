# -*- coding: utf-8 -*-
"""Kodi plugin"""
# pylint: disable=C0302

import json
import os
import re
import sys
import time

from collections import namedtuple
from urllib.parse import parse_qs, unquote, urlencode
from concurrent.futures import ThreadPoolExecutor, wait
from threading import Lock

try:
    import xbmc
    import xbmcaddon
    import xbmcgui
    import xbmcplugin
    import xbmcvfs
    __KODI__ = True
except ModuleNotFoundError:
    __KODI__ = False

sys.path.append(os.path.join(os.path.dirname(__file__), 'resources', 'lib'))
# pylint: disable=wrong-import-position
from cache import Cache
from debug import Debug
from network import Network
from scraper import Scraper
from rutracker import RuTracker, RTS, Title
from torrent import Torrent
from version import VERSIONS
# pylint: enable=wrong-import-position

###
class Plugin:
    """Kodi plugin class."""
    COUNTER = 0
    LOCK = Lock()
    TITLE_TAGS = [
        {'cfg': 'addsize', 'path': ['size'], 'fmt': 8, 'def': '0Mb'},
        {'cfg': 'addquality', 'path': ['info', 'Quality'], 'fmt': 3, 'def': '???'},
        {'cfg': 'addseeders', 'path': ['seeders'], 'fmt': 4, 'def': 0},
        {'cfg': 'addyear', 'path': ['info', 'Year'], 'fmt': 4, 'def': '????'},
    ]

    ###
    def __init__(self):
        """Инициализация"""
        self.prevent_erly_unload = None
        if __KODI__:
            cfg_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
        else:
            cfg_path = './'
        while True:
            self.settings = self.__get_settings(cfg_path)
            if self.__chk_settings():
                break
            if __KODI__:
                xbmcaddon.Addon().openSettings()
            else:
                sys.exit(1)
        if self.settings.dbg_enabled:
            self.__set_debug()
        Debug.log('P', 2, 'Plugin.init()')
        self.prevent_erly_unload = Cache(os.path.join(self.settings.base_dir, 'cache.db'), self.settings.cache_zlib)
        self.__upgrade()
        Network.setproxy(self.settings.net_proxy)
        Network.settimeout(self.settings.net_timeout)
        if __KODI__:
            self.progress_bg = xbmcgui.DialogProgressBG()
        self.rt = RuTracker(
                self.settings.rt_url,
                self.settings.rt_login,
                self.settings.rt_password,
                self.settings.rt_proxy
        )
        self.scrapers = None  # pylint

    ###
    def __del__(self):
        """
        Завершение работы
        Цель - сохранить куки до того как будет выгружен модуль кэша
        """
        Debug.log('P', 2, 'Plugin.del()')
        if self.prevent_erly_unload:
            del self.prevent_erly_unload
        Debug.log('P', 2, 'Plugin.del(): done')

    ###
    def __chk_settings(self):
        """Проверяет настройки аддона"""
        result = True
        msg = 'Ошибка в настройках'
        if not self.settings.rt_url or not self.settings.rt_login or not self.settings.rt_password:
            msg = "Укажите URL, логин и пароль для РуТрекера"
            result = False
        elif self.settings.rt_proxy and '://' not in self.settings.net_proxy:
            msg = "Настройте прокси или выключите проксирование для РуТрекера"
            result = False
        elif self.settings.gpcache_enabled and not self.settings.gpcache_key:
            msg = "Выключите GPcache или укажите ключ доступа"
            result = False
        elif self.settings.tmdb_enabled and not self.settings.tmdb_key:
            msg = "Выключите TMDB или укажите ключ доступа"
            result = False
        elif self.settings.imdb_enabled and self.settings.imdb_proxy and '://' not in self.settings.net_proxy:
            msg = "Настройте прокси или выключите проксирование для IMDb"
            result = False
        elif self.settings.tmdb_enabled and self.settings.tmdb_proxy and '://' not in self.settings.net_proxy:
            msg = "Настройте прокси или выключите проксирование для TMDB"
            result = False
        elif self.settings.kp_enabled and self.settings.kp_proxy and '://' not in self.settings.net_proxy:
            msg = "Настройте прокси или выключите проксирование для КиноПоиска"
            result = False
        if not result:
            if __KODI__:
                xbmcgui.Dialog().ok('РуТрекер', msg)
            else:
                print(msg)
        return result

    ###
    def __get_settings(self, base_dir):
        """Загружает настройки аддона."""
        if __KODI__:
            config = xbmcaddon.Addon().getSettings()
            settings = {'base_dir': base_dir}
            for setting in [
                'plugin_addyear', 'plugin_addseeders', 'plugin_addsize', 'plugin_addquality', 'plugin_new3',
                'plugin_new7', 'plugin_imdbimg', 'plugin_tmdbimg', 'plugin_imgproxy', 'rt_proxy', 'rt_scraper',
                'gpcache_enabled', 'gpcache_proxy', 'imdb_enabled', 'imdb_proxy', 'kp_enabled', 'kp_proxy',
                'tmdb_enabled', 'tmdb_proxy', 'net_usethreads', 'dbg_enabled'
            ]:
                settings[setting] = config.getBool(setting)
            for setting in [
                'plugin_striptitle', 'cache_torrents', 'cache_history', 'cache_info', 'cache_forums', 'cache_zlib',
                'net_timeout', 'net_numthreads', 'net_serverport', 'dbg_plugin', 'dbg_rt', 'dbg_gpcache',
                'dbg_rts', 'dbg_net', 'dbg_scraper', 'dbg_cache', 'dbg_kp', 'dbg_imdb', 'dbg_tmdb'
            ]:
                settings[setting] = config.getInt(setting)
            for setting in [
                'rt_url', 'rt_login', 'rt_password', 'gpcache_key', 'tmdb_key', 'net_proxy',
                'plugin_addyear_color', 'plugin_addsize_color', 'plugin_addquality_color', 'plugin_addseeders_color',
                'plugin_separator', 'plugin_separator_color', 'plugin_title_color', 'plugin_folder_color',
                'plugin_search_color', 'plugin_history_color', 'plugin_page_color',
                'plugin_season_color', 'plugin_episode_color', 'plugin_trailer_quality',
            ]:
                settings[setting] = config.getString(setting)
            # В settings.xml нет возможности задать значение параметра в
            # зависимости от значения другого значения.
            # setSettingBool() объявлена устаревшей, но setBool()
            # срабатывает через раз(
            if settings['plugin_tmdbimg'] or settings['plugin_imdbimg']:
                settings['plugin_imgproxy'] = True
                config.setBool('plugin_imgproxy', True)
                xbmcaddon.Addon().setSettingBool('plugin_imgproxy', True)
        else:
            try:
                with open('settings.json', 'r', encoding='utf-8') as file:
                    settings = json.load(file)
            except (OSError, json.JSONDecodeError) as e:
                print(f'Cannot load settings.json - {e}')
                sys.exit(1)
        settings['cache_info'] =  settings['cache_info'] * 86400 # в днях
        settings['cache_forums'] =  settings['cache_forums'] * 3600 # в часах
        if settings['plugin_separator']:
            settings['plugin_separator'] = settings['plugin_separator'][0]
        return namedtuple('Settings', settings.keys())(**settings)

    ###
    def __get_info(self, content):
        """Подгружает описания видео"""
        if __KODI__:
            self.progress_bg.create('РуТрекер', 'Загрузка...')
        self.__load_scrapers()  # загружаем скраперы.
        to_load = [d for d in content if d.get('mode') == 'topic'] # список item для загрузки
        to_query  = to_load[:] # список item для загрузки из GPcahe
        to_store = [] # список info с Success=False
        to_post = [] # список info для выгрузки в GPcache
        counters = {'from_cache': 0, 'to_cache': 0, 'from_gpcache': 0, 'to_gpcache': 0, 'loaded': 0, 'missing': 0}
        if to_load:
            Debug.log('P', 2, f'Plugin.get_info(): Total {len(to_load)} items to load')
            # сначала ищем в локальном кэше
            self.__get_info_from_cache(to_load, to_query, to_store, counters)
        if to_query and self.settings.gpcache_enabled:
            # если есть что загружать и GPcache включен, то запрашиваем инфу
            self.__get_info_from_gpcache(to_load, to_query, counters)
        if to_load and len(self.scrapers) > 1:
            Plugin.COUNTER = 0
            # Запускаем загрузку в потоках
            with ThreadPoolExecutor(max_workers=self.__get_nworkers()) as pool:
                futures = []
                for entry in to_load:
                    futures.append(pool.submit(self.__load_info, entry, len(to_load)))
                wait(futures)
            for future in futures:
                if info := future.result():
                    self.__get_info_from_scrapers(info, to_load, to_store, to_post, counters)
        if to_load:
            # осталось что загружать, но все скраперы выключены или ничего не вернули
            Debug.log('P', 1, f'Plugin.get_info(): {len(to_load)} items left')
            self.__get_info_for_missing(to_load, to_store, counters)
        if to_post and self.settings.gpcache_enabled:
            self.scrapers.gpcache.set(to_post)
        Debug.log('P', 2, f'Plugin.get_info(): {counters}')
        if __KODI__:
            self.progress_bg.close()
        return content

    ###
    def __get_info_for_missing(self, to_load, to_store, counters):
        for entry in to_load:
            info = next((partial for partial in to_store if partial['Id'] == entry['tid']), None)
            if info:
                entry['info'] = info
                if self.settings.cache_info:
                    Cache.update(info['Id'], self.settings.cache_info)
            else:
                entry.update({'info':
                    self.scrapers.title.scrape(
                        entry['tid'],
                        entry['cid'],
                        entry['title']
                    )
                })
                counters['missing'] += 1

    ###
    def __get_info_from_cache(self, to_load, to_query, to_store, counters):
        """Загружает info из локального кэша и решает что делать дальше."""
        for entry in to_load[:]:
            # Текущие включенные и разрешенные для entry[cid] скраперы.
            cid_scrapers = self.rt.getscrapers(entry['cid'])
            max_scraper_value = 0
            for scraper in self.scrapers._asdict():
                if scraper in cid_scrapers:
                    max_scraper_value += Scraper.SCRAPERS[scraper]
            info = Cache.get(entry['tid'])
            if info and info['Success']:
                # Есть полная инфа, GPcache не запрашиваем, скраперы не запускаем, обновляем expire у записи в кэше.
                to_query.remove(entry)
                to_load.remove(entry)
                entry['info'] = info
                counters['from_cache'] += 1
                if self.settings.cache_info:
                    # Обновляем запись в кэше
                    Cache.update(info['Id'], self.settings.cache_info)
            elif info and info.get('Scraper', 0) >= max_scraper_value:
                # Есть НЕ полная инфа, отработали скраперы не ниже включенных, можно запросить в GPcache.
                to_load.remove(entry)
                to_store.append(info)
                entry['info'] = info
                Debug.log('P', 2, f'Plugin.get_info_from_cche(): {info["Id"]} in cache but {info["Success"]=}')
            elif info:
                # Есть НЕ полная инфа, работали не все включенные сейчас скраперы,
                # можно запускать скраперы, можно запросить в GPcache,
                to_store.append(info)
                Debug.log('P', 2, f'Plugin.get_info_from_cache(): {info["Id"]} in cache but {info["Scraper"]=}')

    ###
    def __get_info_from_gpcache(self, to_load, to_query, counters):
        """Запрашивает info у GPcache."""
        for entry in self.scrapers.gpcache.get(to_query):
            item = next((item for item in to_query if item['tid'] == entry['Id']), None)
            try:
                # item отсутсвует в to_load если info['Scraper'] >= max_scraper_value
                to_load.remove(item)
            except ValueError:
                pass
            item['info'] = entry
            counters['from_gpcache'] += 1
            # не уверен, а нужно ли локально кэшировать полученное из gpcache???
            if self.settings.cache_info:
                counters['to_cache'] += 1
                Cache.add(entry['Id'], self.settings.cache_info, entry)

    ###
    # pylint: disable=too-many-arguments
    def __get_info_from_scrapers(self, info, to_load, to_store, to_post, counters):
        """Обрабатывает info полученное от скраперов"""
        if info.get('Success'):
            counters['loaded'] += 1
            if self.settings.cache_info:
                counters['to_cache'] += 1
                Cache.add(info['Id'], self.settings.cache_info, info)
            if info['Scraper'] > Scraper.SCRAPERS['imdb']:
                to_post.append(info)  # позже отдаем в GPcache
                counters['to_gpcache'] += 1
        else:
            partial = next((partial for partial in to_store if partial['Id'] == info['Id']), None)
            if partial and partial.get('Scraper') > info.get('Scraper'):
                info = partial  # Используем запись из кэша.
                counters['from_cache'] += 1
                if self.settings.cache_info:
                    # Обновляем запись в кэше.
                    Cache.update(info['Id'], self.settings.cache_info)
            else:
                # Используем новую инфу.
                if self.settings.cache_info:
                    # Добавляем запись в кэш.
                    Cache.add(info['Id'], self.settings.cache_info, info)
        item = next((item for item in to_load if item['tid'] == info['Id']), None)
        to_load.remove(item)
        item['info'] = info
    # pylint: enable=too-many-arguments

    ###
    def __get_nworkers(self):
        """Cколько параллельных потоков использовать"""
        if self.settings.net_usethreads:
            nworkers = self.settings.net_numthreads
            if not nworkers:
                nworkers = None
        else:
            nworkers = 1
        return nworkers

    ###
    def __get_serial(self, info, title):
        for tag in ['fromSeason', 'toSeason', 'fromEpisode', 'toEpisode']:
            if tag not in info['Serial']:
                Debug.log('P', 0, f'Plugin.get_serial(#{info["Id"]}, {title}): no {tag}')
                return title
        if info['Serial']['fromSeason'] == info['Serial']['toSeason']:
            _season = info['Serial']['fromSeason']
        else:
            _season = f'{info["Serial"]["fromSeason"]}-{info["Serial"]["toSeason"]}'
        if info['Serial']['fromEpisode'] == info['Serial']['toEpisode']:
            _episode = info['Serial']['fromEpisode']
        else:
            _episode = f'{info["Serial"]["fromEpisode"]}-{info["Serial"]["toEpisode"]}'
        return str(
            f'[COLOR={self.settings.plugin_season_color}]S{_season}[/COLOR]'
            f'[COLOR={self.settings.plugin_separator_color}]{self.settings.plugin_separator}[/COLOR]'
            f'[COLOR={self.settings.plugin_episode_color}]E{_episode}[/COLOR]'
            f'[COLOR={self.settings.plugin_separator_color}]{self.settings.plugin_separator}[/COLOR]'
            f'{title}'
        )

    ###
    def __get_title(self, item):
        """Формирует заголовок ListItem"""
        title = item['title'] # "Как есть"
        if 'info' in item and item.get('is_torrent'):
            title = self.__strip_title(item)
            if item['info'].get('Serial'):
                title = self.__get_serial(item['info'], title)
            if self.settings.dbg_enabled and not item['info'].get('Success'):
                title = f'[COLOR=red]{title}[/COLOR]'
            else:
                title = f'[COLOR={self.settings.plugin_title_color}]{title}[/COLOR]'
            for tag in self.TITLE_TAGS:
                if self.settings._asdict().get(f'plugin_{tag["cfg"]}'):
                    _color = self.settings._asdict().get(f'plugin_{tag["cfg"]}_color')
                    _val = str(Scraper.nested_get(item, tag["path"], tag["def"]))
                    title = (
                        f'[COLOR={_color}]{_val.rjust(tag["fmt"])}[/COLOR]'
                        f'[COLOR={self.settings.plugin_separator_color}]'
                        f'{self.settings.plugin_separator}[/COLOR]{title}'
                    )
        if 'is_search' in item:
            title = f'[B][COLOR={self.settings.plugin_search_color}]{title}[/COLOR][/B]'
        elif 'is_history' in item:
            title = f'[B][COLOR={self.settings.plugin_history_color}]{title}[/COLOR][/B]'
        elif 'is_folder' in item:
            title = f'[B][COLOR={self.settings.plugin_folder_color}]{title}[/COLOR][/B]'
        if 'is_page' in item:
            title = f'{title}[COLOR={self.settings.plugin_page_color}]cледующая страница[/COLOR]'
        if 'is_error' in item:
            title = f'[COLOR=red][B]{title}[/B][/COLOR]'
        return title

    ###
    def __get_url(self, item):
        """Формирует url для вызова item"""
        params = {}
        for key in ['mode', 'cid', 'fid', 'tid',  'sid', 'tm', 'page', 'max', 'query']:
            if item.get(key):
                params[key] = item[key]
        if 'ind' in item:
            params['ind'] = item['ind']
        query = urlencode(params)
        return query

    ###
    def __load_info(self, entry, total):
        """Запускает настроенные скраперы"""
        Debug.log('P', 3, f'Plugin.load_info(#{entry["tid"]})')
        start = time.time()
        info = self.scrapers.title.scrape(entry['tid'], entry['cid'], entry['title'])
        cid_scrapers = self.rt.getscrapers(entry['cid'])
        for scraper in ['kp', 'tmdb', 'imdb', 'rts']:
            if scraper in self.scrapers._asdict() and scraper in cid_scrapers:
                scraper_info = self.scrapers._asdict()[scraper].scrape(info)
                if scraper_info['info']:
                    info = Scraper.merge(info, scraper_info['info'])
                    if info['Success']:
                        break
                elif scraper_info['success']:
                    info['Scraper'] += Scraper.SCRAPERS[scraper]
        Debug.log('P', 3, f'Plugin.load_info(#{entry["tid"]}): {time.time()-start}s')
        if __KODI__:
            with Plugin.LOCK:
                Plugin.COUNTER += 1
                percent = int(Plugin.COUNTER * 100 / total)
                self.progress_bg.update(percent, 'РуТрекер', f'Загрузка {Plugin.COUNTER}/{total}')
        Debug.log('P', 2, f'Plugin.load_info(#{entry["tid"]}): {info["Success"]}')
        return info

    ###
    def __load_scrapers(self):
        # pylint: disable=import-outside-toplevel
        scrapers = {'title': Title()}
        if self.settings.gpcache_enabled:
            from gpcache import GPcache
            scrapers['gpcache'] = GPcache(self.settings.gpcache_key, self.settings.gpcache_proxy)
        if self.settings.imdb_enabled:
            from imdb_api import IMDB
            scrapers['imdb'] = IMDB(self.settings.imdb_proxy)
        if self.settings.kp_enabled:
            from kinopoisk import KinoPoisk
            scrapers['kp'] = KinoPoisk(self.settings.kp_proxy)
        if self.settings.rt_scraper:
            scrapers['rts'] = RTS(self.rt)
        if self.settings.tmdb_enabled:
            from tmdb import TMDB
            scrapers['tmdb'] = TMDB(self.settings.tmdb_key, self.settings.tmdb_proxy)
        # pylint: enable=import-outside-toplevel
        self.scrapers = namedtuple('Scrapers', scrapers.keys())(**scrapers)

    ###
    @staticmethod
    def __select_trailer(trailers):
        """Вывобор трейлера для показа"""
        if len(trailers) == 1:
            return trailers[0]['url']
        selected = xbmcgui.Dialog().select('Трейлеры', [trailer['title'] for trailer in trailers])
        if selected == -1:
            return ''
        return trailers[selected]['url']

    ###
    def __select_trailer_quality(self, m3u):
        """Выбор качества трейлера"""
        if not m3u.startswith('#EXTM3U\n'):
            Debug.log('P', 0, 'Plugin.select_trailer_quality(): bad {m3u=}')
            return ''
        url = ''
        quality = ''
        variants = []
        for line in [line for line in m3u.splitlines() if line.strip()]:
            if line.startswith('#') and 'RESOLUTION' in line:
                quality = re.sub(r'.*RESOLUTION=([0-9]+).*', r'\1', line)
                url = ''
            elif quality and line.startswith('/'):
                if quality in self.settings.plugin_trailer_quality or self.settings.plugin_trailer_quality == 'best':
                    url = 'https://strm.yandex.ru' + line
                    break
                if all(quality not in variant.get('title', '') for variant in variants):
                    variants.append({'title': quality, 'url': 'https://strm.yandex.ru' + line})
            elif not line.startswith('#'):
                Debug.log('P', 0, f'Plugin.select_trailer_quality(): UNSUPPORTED LINK {line=}')
        if not url:
            if len(variants) == 1:
                url = variants[0]['url']
            else:
                selected = xbmcgui.Dialog().select('Качество', [variant['title'] for variant in variants])
                if selected > -1:
                    url = variants[selected]['url']
        return url

    ###
    def __set_content(self, content, params):
        """Выводит content на экран"""
        Debug.log('P', 2, 'Plugin.set_content()')
        if not content:
            Debug.log('P', 1, 'Plugin.set_content(): no content')
            content = [
                {
                    'mode': 'root',
                    'title': 'контент отсутсвует',
                    'is_folder': True
                }
            ]
        else:
            if params.get('mode') in ['content', 'forum'] and not params.get('page'):
                if self.settings.plugin_new7:
                    # добавляем новинки за неделю на первую страницу всех форумов
                    content.insert(0, {
                            'mode': 'query',
                            'cid': params.get('cid', None),
                            'fid': params.get('fid', None),
                            'tm': 7,
                            'title': 'Новинки за неделю',
                            'is_folder': True,
                            'is_search': True,
                    })
                if self.settings.plugin_new3:
                    # добавляем новинки за 3 дня на первую страницу всех форумов
                    content.insert(0, {
                            'mode': 'query',
                            'cid': params.get('cid', None),
                            'fid': params.get('fid', None),
                            'tm': 3,
                            'title': 'Новинки за 3 дня',
                            'is_folder': True,
                            'is_search': True,
                    })
            if params.get('mode') in ['root', 'content', 'forum'] and not params.get('page'):
                # добавляем поиск в главное меню и на первую страницу всех форумов
                content.insert(0, {
                        'mode': 'search',
                        'cid': params.get('cid', None),
                        'fid': params.get('fid', None),
                        'title': 'Поиск',
                        'is_folder': bool(self.settings.cache_history and Cache.get('HISTORY')),
                        'is_search': True,
                })
        for entry in content:
            self.__set_listitem(entry)
        if __KODI__:
            xbmcplugin.setContent(int(sys.argv[1]), 'video')
            xbmcplugin.endOfDirectory(int(sys.argv[1]))

    ###
    def __set_debug(self):
        Debug.setlogfile(os.path.join(self.settings.base_dir, 'rutracker.log'))
        Debug.setloglevel('P', self.settings.dbg_plugin)
        Debug.setloglevel('G', self.settings.dbg_gpcache)
        Debug.setloglevel('R', self.settings.dbg_rt)
        Debug.setloglevel('r', self.settings.dbg_rts)
        Debug.setloglevel('N', self.settings.dbg_net)
        Debug.setloglevel('S', self.settings.dbg_scraper)
        Debug.setloglevel('C', self.settings.dbg_cache)
        Debug.setloglevel('K', self.settings.dbg_kp)
        Debug.setloglevel('T', self.settings.dbg_tmdb)
        Debug.setloglevel('I', self.settings.dbg_imdb)

    ###
    @staticmethod
    def __set_if_defined(videoinfo, info, tag):
        """videoinfo.setXXX(info['XXX'])"""
        if info.get(tag):
            getattr(videoinfo, f'set{tag}')(info[tag])

    ###
    def __set_listitem(self, item):
        """Создает ListItem"""
        # Не уверен, что это подходящее место для правки флагов, но пока так.
        if item.get('is_torrent') and not Scraper.nested_get(item, ['info', 'Serial']):
            item['is_playable'] = True
        title = self.__get_title(item)
        query = self.__get_url(item)
        if __KODI__:
            litem = xbmcgui.ListItem(label=title, offscreen=True)
            # Сохраняем item в виде json для exec_torrent и exec_debug
            litem.setProperty('RuTracker', json.dumps(item))
            self.__set_menu(litem, item)
            if item.get('info'):
                # Обложка
                if 'Cover' in item['info']:
                    img = item['info']['Cover']
                    if self.settings.plugin_tmdbimg and img.startswith('https://image.tmdb'):
                        img = f'http://127.0.0.1:{self.settings.net_serverport}/?{img}'
                    elif self.settings.plugin_imdbimg and 'amazon.com' in img:
                        img = f'http://127.0.0.1:{self.settings.net_serverport}/?{img}'
                    # Сейчас одна картинка на все.
                    litem.setArt({
                        'poster': img,
                        'icon': img,
                        'thumb': img
                    })
                self.__set_videoinfo(litem, title, item['info'])
            if 'is_playable' in item:
                litem.setProperty('isPlayable', 'true')
            url = f'plugin://{xbmcaddon.Addon().getAddonInfo("id")}?{query}'
            xbmcplugin.addDirectoryItem(
                    int(sys.argv[1]),
                    url=url,
                    listitem=litem,
                    isFolder=item.get('is_folder', False)
            )
        else:
            print(f'{title}:::{item}:::?{query}')

    ###
    def __set_menu(self, litem, item):
        """Формирует контекстное меню"""
        menu = []
        if 'info' in item:
            info = item.get('info')
            # Кнопка i
            menu.append(('Информация', 'Action(Info)'))
            # Поиск похожих раздач по всей категории
            query = info.get('ruTitle')
            if not query:
                query = info.get('origTitle')
            qparams = {
                    'mode': 'query',
                    'cid': item['cid'],
                    'query': f'="{query}"'
            }
            url = f'plugin://{xbmcaddon.Addon().getAddonInfo("id")}?{self.__get_url(qparams)}'
            menu.append(('Похожие раздачи', f'Container.Update({url})'))
            # Поиск видео по режиссеру
            director = Scraper.nested_get(info, ['Directors', 0, 'ruName'], '')
            if not director:
                director = Scraper.nested_get(info, ['Directors', 0, 'enName'], '')
            if director:
                qparams['query'] = f'="{director}"'
                url = f'plugin://{xbmcaddon.Addon().getAddonInfo("id")}?{self.__get_url(qparams)}'
                menu.append(('Тот же режиссёр', f'Container.Update({url})'))
        if 'is_page' in item:
            qparams = item
            qparams['mode'] = 'goto'
            url = f'plugin://{xbmcaddon.Addon().getAddonInfo("id")}?{self.__get_url(qparams)}'
            menu.append(('Перейти', f'RunPlugin({url})'))
        if self.settings.dbg_enabled:
            qparams = item
            qparams['mode'] = 'debug'
            url = f'plugin://{xbmcaddon.Addon().getAddonInfo("id")}?{self.__get_url(qparams)}'
            menu.append(('Отладка', f'RunPlugin({url})'))
        litem.addContextMenuItems(menu)

    ###
    def __set_videoinfo(self, litem, title, info):
        """Создает и заполняет VideoInfoTag."""
        videoinfo = litem.getVideoInfoTag() #offscreen=True)
        videoinfo.setTitle(title)
        self.__set_if_defined(videoinfo, info, 'Year')
        self.__set_if_defined(videoinfo, info, 'Genres')
        self.__set_if_defined(videoinfo, info, 'Studios')
        self.__set_if_defined(videoinfo, info, 'Countries')
        self.__set_if_defined(videoinfo, info, 'Plot')
        if info['kpId'] and self.settings.kp_enabled:
            videoinfo.setTrailer(
                f'plugin://plugin.video.gp.rutracker?mode=trailer&tid={info["Id"]}&kpid={info["kpId"]}'
            )
        if info['Directors']:
            directors = []
            for entry in info['Directors']:
                directors.append(Scraper.get_person_name(entry))
            videoinfo.setDirectors(directors)
        if info['Writers']:
            writers = []
            for entry in info['Writers']:
                writers.append(Scraper.get_person_name(entry))
            videoinfo.setWriters(writers)
        if info['Artists']:
            actors = []
            i = 1
            for artist in info['Artists']:
                if Scraper.get_person_name(artist):
                    img = artist.get('Img', '')
                    if self.settings.plugin_tmdbimg and img.startswith('https://image.tmdb'):
                        img = f'http://127.0.0.1:{self.settings.net_serverport}/?{img}'
                    elif self.settings.plugin_imdbimg and 'amazon.com' in img:
                        img = f'http://127.0.0.1:{self.settings.net_serverport}/?{img}'
                    actors.append(
                            xbmc.Actor(
                                Scraper.get_person_name(artist),
                                artist['Role'],
                                i,
                                img)
                    )
                    i += 1
            videoinfo.setCast(actors)

    ###
    def __strip_title(self, item):
        """Обрезает название видео"""
        title = item['title']  # По умолчанию как есть.
        match self.settings.plugin_striptitle:
            case 1:
                # Только русское название.
                if item['info'].get('ruTitle'):
                    title = item['info']['ruTitle']
            case 2:
                # Только оригинальное
                if item['info'].get('origTitle'):
                    title = item['info']['origTitle']
            case 3:
                # Русское и оригинальное.
                if item['info'].get('ruTitle'):
                    title = item['info']['ruTitle']
                if item['info'].get('origTitle'):
                    if not item['info'].get('ruTitle'):
                        title = item['info']['origTitle']
                    elif item['info']['ruTitle'] != item['info']['origTitle']:
                        title = title + ' / ' + item['info']['origTitle']
            case 4:
                # Как есть, но вырезаны первый и последний тэги.
                striped = re.match(r'(?:^\[[^\[]+\])?(.*)(?:\[[^\]]+\].*$)', item['title'])
                if striped:
                    title = striped.group(1).strip()
                    striped = re.match(r'(?:^\[[^\[]+\])?(.*)(?:\[[^\]]+\].*$)', title)
                    if striped:
                        title = striped.group(1).strip()
        return title

    ###
    def __upgrade(self):
        """Обрабатывает смену версий компонентов аддона."""
        update = True
        if versions := Cache.get("VERSIONS"):
            # до v0.0.18 VERSIONS было int
            if isinstance(versions, dict):
                update = False
        if update:
            versions = {}
        # Проверяем есть ли изменения.
        if versions.get('COOKIES', 0) != VERSIONS['COOKIES']:
            Debug.log('P', 1, 'Plugin.init(): upgrade - clear COOKIES')
            Cache.delete('COOKIES')
            update = True
        if versions.get('HISTORY', 0) != VERSIONS['HISTORY']:
            Debug.log('P', 1, 'Plugin.init(): upgrade - clear HISTORY')
            Cache.delete('HISTORY')
            update = True
        if versions.get('INDEX', 0) != VERSIONS['INDEX']:
            Debug.log('P', 1, 'Plugin.init(): upgrade - clear INDEX')
            Cache.delete('FORUM_INDEX')
            Cache.delete('SEARCH_INDEX')
            update = True
        if versions.get('TORRENTS', 0) != VERSIONS['TORRENTS']:
            # XXXX: нужно удалять торрент файлы если есть.
            Debug.log('P', 1, 'Plugin.init(): upgrade - clear TORRENTS')
            Cache.delete('TORRENTS')
            update = True
        if versions.get('INFO', 0) != VERSIONS['INFO']:
            # Зачищаем все кэшированные описания видео и страницы форумов.
            Debug.log('P', 1, 'Plugin.init(): upgrade - clear CACHE')
            Cache.cleanup(9223372036854775807) # max int
            # XXXX: сделать VACUUM ???
            update = True
        if update:
            Cache.add('VERSIONS', 0, VERSIONS)

    ###
    def exec_clear(self, params):
        """Чистит кэш. вызывается кнопкой из настроек аддона."""
        Debug.log('P', 2, f'Plugin.exec_clear({params})')
        msg = ''
        match params.get('what'):
            case 'cookies':
                Network.clear()
                msg = 'Куки удалены'
            case 'history':
                Cache.delete('HISTORY')
                msg = 'История поиска удалена.'
            case 'cache':
                Cache.cleanup(9223372036854775807)  # max int
                msg = 'Кэш очищен'
            case _:
                Debug.log('P', 0, f'Plugin.exec_clear({params}): bad parametr {params.get("what")}')
        if msg:
            xbmcgui.Dialog().ok('РуТрекер', msg)

    ###
    def exec_content(self, params):
        """Подразделы главного экрана"""
        Debug.log('P', 2, f'Plugin.exec_content({params})')
        if len(self.rt.CONTENT.get(params['cid'], {}).get('include', [])) == 1:
            # В категории только 1 форум, переходим на него.
            params['mode'] = 'forum'
            params['fid'] = self.rt.CONTENT.get(params['cid'], {}).get('include', [])[0]
            self.exec_forum(params)
        else:
            # включаем плашку загрузки, т.к. может подгружать индексы
            if __KODI__:
                self.progress_bg.create('РуТрекер', 'Загрузка...')
            content = self.rt.viewcontent(params['cid'])
            if __KODI__:
                self.progress_bg.close()
            self.__set_content(content, params)

    ###
    def exec_debug(self, params):
        """Показывает выбранный ListItem в виде json"""
        Debug.log('P', 2, f'Plugin.exec_debug({params})')
        info = json.dumps(
                json.loads(xbmc.getInfoLabel('ListItem.Property(RuTracker)')),
                ensure_ascii=False,
                indent=4
        )
        xbmcgui.Dialog().textviewer('Отладка', info, True)

    ###
    def exec_forum(self, params):
        """Форум"""
        Debug.log('P', 2, f'Plugin.exec_forum({params})')
        forums = []
        if self.settings.cache_forums:
            forums = Cache.get(self.__get_url(params))
        if not forums:
            if __KODI__:
                self.progress_bg.create('РуТрекер', 'Загрузка...')
            forums = self.rt.viewforum(params['cid'], params['fid'], int(params.get('page', 0)))
            if __KODI__:
                self.progress_bg.close()
            if forums and self.settings.cache_forums:
                Cache.add(self.__get_url(params), self.settings.cache_forums, forums)
        self.__set_content(self.__get_info(forums), params)

    ###
    def exec_goto(self, params):
        """Переход на выбранную страницу форума/результатов поиска."""
        Debug.log('P', 2, f'Plugin.exec_goto({params})')
        page = xbmcgui.Dialog().input(
                f'Перейти к странице [1-{params["max"]}]',
                type=xbmcgui.INPUT_NUMERIC,
        )
        if not page:
            return
        try:
            page = int(page)
        except ValueError:
            page = 0
        if 0 <= page <= params['max']:
            qparams = params
            if 'sid' in qparams:
                # результаты поиска
                qparams['mode'] = 'query'
            else:
                # страница форум
                qparams['mode'] = 'forum'
            qparams['page'] = page
            url = f'plugin://{xbmcaddon.Addon().getAddonInfo("id")}?{self.__get_url(qparams)}'
            Debug.log('P', 3, f'Plugin.exec_goto({params}): {url=}')
            xbmc.executebuiltin(f'Container.Update({url})')

    ###
    def exec_input(self, params):
        """Ввод строки поиска"""
        Debug.log('P', 2, f'Plugin.exec_input({params})')
        if __KODI__:
            skbd = xbmc.Keyboard(str(params.get('query', '')), 'Поиск')
            skbd.doModal()
            if skbd.isConfirmed() and skbd.getText():
                if self.settings.cache_history:
                    history = Cache.get('HISTORY')
                    if not history:
                        history = []
                    if any(str(item).lower() == skbd.getText().lower() for item in history):
                        history.remove(skbd.getText())
                    history.insert(0, skbd.getText())
                    while len(history) > self.settings.cache_history:
                        history.pop()
                    Cache.add('HISTORY', 0, history)
                qparams = params
                qparams['mode'] = 'query'
                qparams['query'] = str(skbd.getText())
                url = f'plugin://{xbmcaddon.Addon().getAddonInfo("id")}?{self.__get_url(qparams)}'
                xbmc.executebuiltin(f'Container.Update({url})')
            else:
                Debug.log('P', 2, f'Plugin.exec_input({params}): canceled')
                xbmc.executebuiltin("Container.Refresh()")
        else:
            if not params.get('query'):
                import random  # pylint: disable=import-outside-toplevel
                params['query'] = random.choice(['2020', '2021', '2022', '2023', '2024', '2025'])
            params['mode'] = 'query'
            print(f'redirect to exec_query::: :::?{self.__get_url(params)}')

    ###
    def exec_query(self, params):
        """Поиск по трекеру"""
        Debug.log('P', 2, f'Plugin.exec_query({params})')
        if __KODI__:
            self.progress_bg.create('РуТрекер', 'Загрузка...')
        found = self.rt.viewtracker(
            params.get('cid', None),
            params.get('fid', None),
            params.get('sid', None),
            params.get('tm', None),
            params.get('page', None),
            params.get('query', None)
        )
        if __KODI__:
            self.progress_bg.close()
        self.__set_content(self.__get_info(found), params)

    ###
    def exec_play(self, params):
        """Запускает TAM для выделенного ListItem"""
        Debug.log('P', 2, f'Plugin.exec_play({params["tid"]})')
        torrent = Torrent(self.settings.base_dir, self.settings.cache_torrents)
        if not torrent.is_cached(params['tid']):
            Debug.log('P', 0, f'Plugin.exec_play({params["tid"]}): torrent not cached')
            return False
        fname = torrent.getfname(params['tid'])
        purl = f'plugin://plugin.video.tam/?mode=play&url={fname}&ind={params["ind"]}'
        Debug.log('P', 3, f'Plugin.exec_play({params["tid"]}): {purl=}')
        if __KODI__:
            item = xbmcgui.ListItem(path=purl)
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
        else:
            print(f'{purl}::: :::?mode=root')
        return True

    ###
    def exec_root(self, params):
        """Главный экран"""
        Debug.log('P', 2, "Plugin.exec_root()")
        self.__set_content(self.rt.viewroot(), params)

    ###
    def exec_search(self, params):
        """
        Если история поиска не пуста, то выводит ее и добавляет
        пункт Новый Поиск, иначе перенаправляет на ввод поискового запроса
        """
        Debug.log('P', 2, f'Plugin.exec_search({params})')
        if self.settings.cache_history and (history := Cache.get('HISTORY')):
            content = [{
                    'mode': 'input',
                    'cid': params.get('cid', ''),
                    'fid': params.get('fid', 0),
                    'title': '[Новый поиск]',
                    'is_search': True,
            }]
            if len(history) >  self.settings.cache_history:
                while len(history) > self.settings.cache_history:
                    history.pop()
                Cache.add('HISTORY', 0, history)
            for entry in history:
                content.append({
                        'mode': 'input',
                        'cid': params.get('cid', ''),
                        'fid': params.get('fid', 0),
                        'query': entry,
                        'is_history': True,
                        'title': entry
                })
            self.__set_content(content, params)
        else:
            self.exec_input(params)

    ###
    def exec_topic(self, params):
        """
        Загружает торрент.
        Торренты с одним видео фалом сразу воспроизводятся,
        c несколькими отдаются в exec_torrent
        """
        Debug.log('P', 2, f'Plugin.exec_topic({params})')
        torrent = Torrent(self.settings.base_dir, self.settings.cache_torrents)
        if not torrent.is_cached(params['tid']):
            Debug.log('P', 3, f'Plugin.exec_topic({params["tid"]}) loading torrent')
            if __KODI__:
                self.progress_bg.create('РуТрекер', 'Загрузка...')
            response = self.rt.viewtopic(params['tid'])
            if response.status_code == 200:
                fname = torrent.getfname(params['tid'])
                try:
                    with open(fname, 'wb') as file:
                        file.write(response.content)
                    torrent.cache(params['tid'])
                except OSError as e:
                    Debug.log("P", 0, f'Plugin.exec_topic({params["tid"]}): write - {e}')
            if __KODI__:
                self.progress_bg.close()
        if torrent.is_cached(params['tid']):
            videos = torrent.getvideos(params['tid'])
            Debug.log('P', 0, f'Plugin.exec_topic({params["tid"]}): {videos=}')
            if len(videos) == 1:
                # торрент содержит только одно видео
                self.exec_play({
                        'mode': 'torrent',
                        'tid': videos[0]['tid'],
                        'ind': videos[0]['ind']
                })
            else:
                query = self.__get_url({
                    'mode': 'torrent',
                    'cid': params['cid'],
                    'fid': params['fid'],
                    'tid': params['tid']
                })
                if __KODI__:
                    url = f'plugin://{xbmcaddon.Addon().getAddonInfo("id")}?{query}'
                    Debug.log('P', 3, f'Plugin.exec_topic({params["tid"]}): redirect to {url}')
                    xbmc.executebuiltin(f'Container.Update("{url}")')
                else:
                    print(f'redirect to exec_torrent::: :::?{query}')
        else:
            Debug.log('P', 0, f'Plugin.exec_topic({params["tid"]}): no torrent')
            sys.exit(1)

    ###
    def exec_torrent(self, params):
        """Выводит содержимое торрента"""
        Debug.log('P', 2, f'Plugin.exec_torrent({params["tid"]})')
        info = {}
        if __KODI__:
            try:
                item = json.loads(xbmc.getInfoLabel('ListItem.Property(RuTracker)'))
            except json.JSONDecodeError as e:
                Debug.log('P', 1, f'Plugin.exec_torrent({params["tid"]}): no/bad item info - {e}')
                item = {}
            info = item.get('info', {})
        content = []
        torrent = Torrent(self.settings.base_dir, self.settings.cache_torrents)
        if torrent.is_cached(params['tid']):
            videos = torrent.getvideos(params['tid'])
            Debug.log('P', 0, f'Plugin.exec_torrent({params["tid"]}): {videos=}')
            for entry in videos:
                entry['cid'] = params['cid']
                entry['fid'] = params['fid']
                entry['mode'] = 'play'
                entry['is_playable'] = True
                entry['info'] = info # Пока одинаковое info для всех файлов.
                content.append(entry)
        else:
            Debug.log('P', 0, f'Plugin.exec_torrent({params["tid"]}): torrent not cached')
        self.__set_content(content, params)

    ###
    def exec_trailer(self, params):
        """Показывает доступные трейлеры для раздачи"""
        Debug.log('P', 2, f'Plugin.exec_trailer({params["tid"]})')
        if not self.settings.kp_enabled:
            xbmcgui.Dialog().ok('РуТрекер', 'КиноПоиск выключен')
            return
        self.__load_scrapers()  # Сейчас реально нужен только КиноПоиск
        trailers = self.scrapers.kp.trailers(params['tid'], params['kpid'])
        Debug.log('P', 3, f'Plugin.exec_trailer({params["tid"]}): {trailers=}')
        if not trailers:
            xbmcgui.Dialog().ok('РуТрекер', 'Трейлеры не найдены.')
            return
        url = self.__select_trailer(trailers)
        if not url:
            return
        response = Network.geturl(url)
        if response.status_code != 200:
            return
        # XXXX: кэшировать на случай если захочется посмотреть несколько???
        url = self.__select_trailer_quality(response.text)
        if url:
            Debug.log('P', 1, f'Plugin.exec_trailer({params["tid"]}: {url}')
            xbmc.Player().play(url)
            # Пытаться вернуться в Инфо???

    ###
    def route(self):
        """Роутинг запроса"""
        params = {}
        args = parse_qs(sys.argv[2][1:])
        for arg, vals in args.items():
            val = unquote(vals[0])
            if val.isdigit():
                val = int(val)
            params[arg] = val
        Debug.log('P', 1, f"Plugin.route(): {params=}")
        if not hasattr(self, f"exec_{params.get('mode')}"):
            if params:
                Debug.log('P', 0, f"Plugin.route(): unsupported mode {params.get('mode')}")
            params = {'mode': 'root'}
        Debug.log('P', 2, f"Plugin.route(): exec_{params['mode']}")
        getattr(self, f"exec_{params['mode']}")(params)
        Network.save()

###
if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("usage: plugin.py any <?url>")
        sys.exit(1)
    plugin = Plugin()
    plugin.route()
