# -*- coding: utf-8 -*-
"""RuTracker module."""
from html import unescape
import re
from string import punctuation

from urllib.parse import urlencode
from cache import Cache
from debug import Debug
from network import Network, ReqParams, ReqAuth
from scraper import Scraper

class RuTracker:
    """Работа с rutracker.org"""
    CONTENT = {
        'movies': {
            'title': 'Фильмы',
            'include': (22, 7, 124, 2198, 718),
            'exclude': (
                44, 65, 69, 93, 94, 96, 100, 101, 106, 125, 149, 166, 185, 186, 212, 254, 267,
                376, 531, 572, 653, 709, 771, 772, 789, 877, 905, 906, 1454, 1543, 1576, 1577,
                1640, 1670, 1692, 2220, 2373, 2374, 2459
            ),
            'scrapers': ['rts', 'imdb', 'tmdb', 'kp']
        },
        'serials': {
            'title': 'Сериалы',
            'include': (9, 189, 2366, 911, 2100),
            'exclude': (
                26, 32, 190, 191, 195, 913, 914, 920, 1147, 1359, 1395, 1498, 1537, 1539, 1574, 2101, 2102, 2369
            ),
            'scrapers': ['rts', 'imdb', 'tmdb', 'kp']
        },
        'cartoons': {
            'title': 'Мультфильмы',
            'include': (84, 930, 2343, 2365, 208, 539, 2183,209, 484, 181),
            'exclude': (86, 521, 665, 822, 1900, 2258),
            'scrapers': ['rts', 'imdb', 'tmdb', 'kp']
        },
    }
    URLS = {
        'forum': 'viewforum.php?sort=2&order=0&f=',
        'topic': 'viewtopic.php?t=',
        'torrent': 'dl.php?t=',
        'tracker': 'tracker.php'
    }
    # pylint: disable=line-too-long
    RE_CLEAR = re.compile(r'<.*?>|&([a-z0-9]+|#[0-9]{1,6}|#x[0-9a-f]{1,6});', re.S)
    RE_FORUM = re.compile(r'class="forumlink"><a href="viewforum\.php\?f=([0-9]+)">([^<]+)</a>')
    RE_TOPIC = re.compile(r'<a id="tt-(?P<id>[0-9]+)"[^>]+>(.*?)</a>.*title="Seeders"><b>([0-9]+).*dl-stub">([^<]+)<', re.S)
    RE_FPAGE = re.compile(r'<a class="pg".{15,60}start=[0-9]+">([0-9]+)</a>.{0,15}<a class="pg".{15,60}start=([0-9]+)">След\.</a>', re.U|re.S)
    RE_SPAGE = re.compile(r'<a class="pg".{15,60}start=[0-9]+">([0-9]+)</a>.{0,15}<a class="pg".{15,60}search_id=([^&]+)&amp;start=([0-9]+)">След\.</a>', re.U|re.S)
    RE_SEARCH = re.compile(r'="tracker\.php\?f=([0-9]+)".*?viewtopic\.php\?t=(?P<id>[0-9]+)">([^<]+)</a>.{100,500}\.php\?t=(?P=id)">([^<]+)</a>.*?<b class="seedmed">([0-9]+)</b>', re.S)
    # pylint: enable=line-too-long
    FORUM_INDEX = {}
    SEARCH_INDEX = {}

    ###
    def __init__(self, url, login, password, proxy):
        Debug.log('R', 2, f'RuTracker.init({url}, {login[0] + "*" * (len(login) - 1)}, {"*" * len(password)}, {proxy})')
        self.base_url = url
        self.req_params = ReqParams(proxy=proxy,)
        self.req_auth = ReqAuth(
                method='POST',
                url=self.base_url + '/forum/login.php',
                data={'login_username': login, 'login_password': password, 'login': 'Вход'},
                validator=RuTracker.__is_authorized
        )
        RuTracker.FORUM_INDEX = Cache.get('FORUM_INDEX')
        if not RuTracker.FORUM_INDEX:
            RuTracker.FORUM_INDEX = {}
        RuTracker.SEARCH_INDEX = Cache.get('SEARCH_INDEX')
        if not RuTracker.SEARCH_INDEX:
            RuTracker.SEARCH_INDEX = {}

    @staticmethod
    def __is_authorized(request_id, response):
        authorized = False
        lvl = 0
        if response.status_code == 200:
            if (
                'logged-in-username' in response.text or
                'attachment; filename=' in response.headers.get('Content-Disposition', '')
            ):
                authorized = True
                lvl = 3
        Debug.log('N', lvl, f'RuTracker.is_authorized(#{request_id}): {authorized}')
        return authorized

    @staticmethod
    def __getforums(html):
        """Returns list of {id, title}."""
        Debug.log('R', 3, 'RuTracker.getforums(): Started')
        forums = []
        for forum in RuTracker.RE_FORUM.findall(html):
            forums.append({'id': int(forum[0]), 'title': forum[1]})
        Debug.log('R', 3, f'RuTracker.getforums(): found {len(forums)} forums')
        return forums


    ###
    @staticmethod
    def __get_forum_index(_html):
        forum_index = {}
        for forum in re.compile(r'<option id="fs-([0-9]+)"[^>]+>([^<]+)', re.U).findall(_html):
            forum_index[forum[0]] = unescape(forum[1]).strip().removeprefix('|-').strip()
        Debug.log('R', 3, f'RuTracker.get_forum_index(): {forum_index}')
        RuTracker.FORUM_INDEX = forum_index
        Cache.add('FORUM_INDEX', 0, RuTracker.FORUM_INDEX)

    @staticmethod
    def __get_search_index(_html):
        search_index = {}
        catalog = {}
        root = None
        for cat, is_root in re.compile(r'<option id="fs\-([0-9]+)"([^>]+)>', re.U).findall(_html):
            cat = int(cat)
            if 'root_forum' in is_root:
                root = cat
                catalog[root] = [cat]
            elif root:
                catalog[root].append(cat)
        for cid, content in RuTracker.CONTENT.items():
            search_index[cid] = []
            for entry in content['include']:
                if entry in catalog:
                    search_index[cid].extend(cat for cat in catalog[entry] if cat not in content['exclude'])
                else:
                    search_index[cid].append(entry)
            for entry in search_index[cid]:
                if entry in catalog:
                    search_index[entry] = []
                    search_index[entry].extend(cat for cat in catalog[entry] if cat not in content['exclude'])
        Debug.log('R', 3, f'RuTracker.get_search_index(): {search_index}')
        RuTracker.SEARCH_INDEX = search_index
        Cache.add('SEARCH_INDEX', 0, RuTracker.SEARCH_INDEX)

    ###
    def __loadindex(self):
        url = self.geturl('tracker')
        Debug.log('R', 2, f'RuTracker.loadindex(): Loading {url}')
        response = Network.geturl(url, params=self.req_params, auth=self.req_auth)
        if response and response.status_code == 200:
            self.__get_forum_index(response.text)
            self.__get_search_index(response.text)

    ###
    @staticmethod
    def __getpages(html):
        """Returns pagenator info as dict()."""
        page = {}
        if 'search_id=' in html and (res := RuTracker.RE_SPAGE.search(html)):
            page = {'max': int(res.group(1)), 'cur': int(int(res.group(3)) / 50), 'key': res.group(2)}
        elif (res := RuTracker.RE_FPAGE.search(html)):
            page = {'max': int(res.group(1)), 'cur': int(int(res.group(2)) / 50)}
        Debug.log('R', 3, f'RuTracker.getpages(): {page}')
        return page

    ###
    @staticmethod
    def __gettopics(html):
        """Returns list of {id, title, seeders, size}."""
        Debug.log('R', 3, 'RuTracker.gettopics(): Started')
        topics = []
        topics_list = html.split('data-topic_id')
        if len(topics_list) > 1:
            topics_list = topics_list[1:]
        for entry in topics_list:
            item = RuTracker.RE_TOPIC.search(entry)
            if item:
                topic = {
                    'id': int(item.group(1)),
                    'title': unescape(RuTracker.RE_CLEAR.sub('', item.group(2))),
                    'seeders': int(item.group(3)),
                    'size': RuTracker.RE_CLEAR.sub('', item.group(4))
                }
                Debug.log('R', 3, f'RuTracker.gettopics(): append {topic}')
                topics.append(topic)
        return topics

    ###
    def __new_search(self, cid, fid, tm, query):
        #параметры поиска
        forums = []
        if not cid:
            #главное меню
            for entry in RuTracker.CONTENT:
                forums += RuTracker.SEARCH_INDEX[entry]
        elif not fid:
            #подраздел главного меню
            forums = RuTracker.SEARCH_INDEX[cid]
        elif str(fid) in RuTracker.SEARCH_INDEX:
            #все вложенные форумы
            forums = RuTracker.SEARCH_INDEX[str(fid)]
        else:
            #только текущий форум
            forums.append(fid)
        Debug.log('R', 3, f'RuTracker.viewtracker(): forums={forums}')
        qparams = {
            'o': 10,
            's': 2,
            'prev_my': 0,
            'prev_new': 0,
            'prev_oop': 0,
            'f[]': forums
        }
        if tm:
            qparams['tm'] = tm
        if query:
            qparams['nm'] = query
        return self.geturl('tracker', None, query=urlencode(qparams, True))

    ###
    def getcid(self, fid):
        """Возвращает cid для указанного fid"""
        if not RuTracker.SEARCH_INDEX:
            self.__loadindex()
        if not RuTracker.SEARCH_INDEX:
            return None
        for cid in RuTracker.CONTENT:
            if fid in RuTracker.SEARCH_INDEX[cid]:
                return cid
        return None

    ###
    @staticmethod
    def getscrapers(cid):
        """Возвращает список скраперов разрешенных для указанного cid"""
        return RuTracker.CONTENT[cid]['scrapers']

    ###
    def geturl(self, view, view_id = 0, page=0, query=None):
        """Формирует url для заданных параметров"""
        url = self.base_url + '/forum/'
        if view in RuTracker.URLS:
            url += RuTracker.URLS[view]
            if view_id:
                url += str(view_id)
        else:
            url += 'index.php'
        if page:
            url += '&start=' + str((page - 1) * 50)
        if query:
            if '?' in url:
                url += '&'
            else:
                url += '?'
            url += query
        Debug.log('R', 3, f'RuTracer.geturl({view}, {view_id}, {page}, {query}): {url}')
        return url


    ###
    @staticmethod
    def viewroot():
        """Returns RuTracker root entries as list()."""
        Debug.log('R', 2, 'RuTracker.viewroot()')
        content = []
        for cid, value in RuTracker.CONTENT.items():
            item = {
                'mode': 'content',
                'cid': cid,
                'title': value['title'],
                'is_folder': True
            }
            Debug.log('R', 3, f'RuTracker.viewroot(): append {item}')
            content.append(item)
        return content

    ###
    def viewcontent(self, cid):
        """Returns content of cid as list()."""
        Debug.log('R', 2, f'RuTracker.viewcontent({cid})')
        if not RuTracker.FORUM_INDEX:
            self.__loadindex()
        content = []
        if RuTracker.FORUM_INDEX:
            for fid in RuTracker.CONTENT[cid]['include']:
                title = RuTracker.FORUM_INDEX.get(str(fid))
                if not title:
                    # Индекс протух?
                    Debug.log('R', 1, f'RuTracker.viewcontent({cid}): {fid} not in FORUM_INDEX, reloading')
                    self.__loadindex()
                    title = RuTracker.FORUM_INDEX.get(str(fid))
                if title:
                    item = {
                        'fid': fid,
                        'mode': 'forum',
                        'title': title,
                        'is_folder': True,
                        'cid': cid
                    }
                    Debug.log('R', 3, f'RuTracker.viewcontent({cid}): append {item}')
                    content.append(item)
                else:
                    Debug.log('R', 0, f'RuTracker.viewcontent({cid}): unknown fid {fid}')
        return content

    ###
    def viewforum(self, cid, fid, page=0):
        """Returns forum content as list()."""
        Debug.log('R', 2, f'RuTracker.viewforum({cid}, {fid}, {page})')
        if not RuTracker.FORUM_INDEX.get(str(fid)):
            # Индекс протух?
            Debug.log('R', 1, f'RuTracker.viewforum({cid}, {fid}, {page}): {fid} not in FORUM_INDEX, reloading')
            self.__loadindex()
        content = []
        response = Network.geturl(self.geturl('forum', fid, page=page), params=self.req_params, auth=self.req_auth)
        if response.status_code == 200:
            sub_forums = self.__getforums(response.text)
            for entry in sub_forums:
                if entry['id'] not in RuTracker.CONTENT[cid]['exclude']:
                    item = {
                        'mode': 'forum',
                        'cid': cid,
                        'fid': entry['id'],
                        'title': unescape(entry['title']),
                        'is_folder': True,
                    }
                    Debug.log('R', 3, f'RuTracker.viewforum({cid}, {fid}, {page}): append {item}')
                    content.append(item)
                else:
                    Debug.log('R', 3, f'RuTracker.viewforum({cid}, {fid}, {page}): exclude {entry}')
            topics = self.__gettopics(response.text)
            for topic in topics:
                item = {
                    'mode': 'topic',
                    'cid': cid,
                    'fid': fid,
                    'tid': topic['id'],
                    'title': topic['title'],
                    'size': topic['size'],
                    'seeders': topic['seeders'],
                    'is_torrent': True,
                }
                Debug.log('R', 3, f'RuTracker.viewforum({cid}, {fid}, {page}): append {item}')
                content.append(item)
            pages = self.__getpages(response.text)
            if pages and pages['cur'] != pages['max']:
                page = pages['cur'] + 1
                item = {
                    'mode': 'forum',
                    'cid': cid,
                    'fid': fid,
                    'page': page,
                    'title': f'[{pages["cur"]}/{pages["max"]}]',
                    'max': pages['max'],
                    'is_folder': True,
                    'is_page': True,
                }
                Debug.log('R', 3, f'RuTracker.viewforum({cid}, {fid}, {page}): append {item}')
                content.append(item)
        return content

    ###
    def viewtopic(self, tid):
        """Загружает torrent"""
        Debug.log('R', 3, 'RuTracker.viewtopic({tid})')
        return Network.geturl(self.geturl('torrent', tid), params=self.req_params, auth=self.req_auth)

    ###
    # pylint: disable=too-many-arguments
    # pylint: disable=too-many-positional-arguments
    def viewtracker(self, cid=None, fid=None, sid=None, tm=None, page=None, query=None):
        """Поиск"""
        Debug.log('R', 2, f'RuTracker.viewtracker({cid}, {fid}, {sid}, {tm}, {page}, {query})')
        if not RuTracker.SEARCH_INDEX or (fid and not RuTracker.FORUM_INDEX.get(str(fid))):
            self.__loadindex()
        if not RuTracker.SEARCH_INDEX:
            return []
        if not sid:
            url = self.__new_search(cid, fid, tm, query)
        else:
            url = self.geturl('tracker', None, query=f'search_id={sid}&start={str((page - 1) * 50)}')
        response = Network.geturl(url, params=self.req_params, auth=self.req_auth)
        if response.status_code != 200:
            return []
        topics = []
        for entry in RuTracker.RE_SEARCH.findall(response.text):
            entry_fid = int(entry[0])
            if not RuTracker.FORUM_INDEX.get(str(entry_fid)):
                # Индекс протух?
                Debug.log('R', 1, f'RuTracker.viewtracker(): {entry_fid} not in FORUM_INDEX, reloading')
                self.__loadindex()
            entry_cid = ''
            for content in RuTracker.CONTENT:
                if entry_fid in RuTracker.SEARCH_INDEX[content]:
                    entry_cid = content
                    break
            if not entry_cid:
                Debug.log('R', 1, f'RuTracker.viewtracker(): {entry_fid} - unknown cid')
                self.__loadindex()
            topics.append({
                'mode': 'topic',
                'cid': entry_cid,
                'fid': entry_fid,
                'tid': int(entry[1]),
                'title': unescape(entry[2]),
                'size': RuTracker.RE_CLEAR.sub('', entry[3]),
                'seeders': int(entry[4]),
                'is_torrent': True,
            })
        pages = self.__getpages(response.text)
        if pages and pages['cur'] != pages['max']:
            page = pages['cur'] + 1
            topics.append({
                'mode': 'query',
                'cid': cid,
                'fid': fid,
                'page': page,
                'sid': pages['key'],
                'title': f'[{pages["cur"]}/{pages["max"]}]',
                'max': pages['max'],
                'is_folder': True,
                'is_page': True
            })
        Debug.log('R', 1, f'RuTracker.viewtracker({query}): found {len(topics)} topics')
        return topics
    # pylint: enable=too-many-arguments
    # pylint: enable=too-many-positional-arguments


class RTS:
    """Cкрапер первого поста раздачи"""
    # pylint: disable=line-too-long
    RE_CID = re.compile(r'(?:<a href="viewforum\.php\?f=)([0-9]+)">', re.S)
    RE_CLEAR = re.compile(r'<.*?>|&([a-z0-9]+|#[0-9]{1,6}|#x[0-9a-f]{1,6});', re.S)
    RE_COVER = re.compile(r'postImg[^>]+title="([^"]+)"', re.S)
    RE_POST = re.compile(r'<div class="post_body"[^>]+>(.+?)<table class="attach bordered med">', re.U|re.S)
    RE_IMDB = re.compile(r'imdb\.com.*?(tt[0-9]+)', re.S)
    RE_KP = re.compile(r'kinopoisk\.ru(?:%2F|/)?(?:images(?:%2F|/)|level(?:%2F|/)[0-9](?:%2F|/))?(?:series|film|rating)(?:%2F|/)?([0-9]+)', re.S)
    INFOTAGS = [
        {'tag': 'Year', 'action': 'get_year', 'keywords': ['год', 'год выпуска']},
        {'tag': 'Plot', 'keywords': ['описание', 'сюжет', 'о фильме']},
        {'tag': 'Countries', 'action': 'get_countries', 'is_list': True, 'keywords': ['страна', 'страна-производитель']},
        {'tag': 'Genres', 'action': 'get_genres', 'is_list': True, 'keywords': ['жанр', 'жанры']},
        {'tag': 'Studios', 'action': 'get_studios', 'is_list': True, 'keywords': ['производство', 'студия', 'студии']},
        {'tag': 'Directors', 'action': 'get_persons', 'is_list': True, 'keywords': ['режиссёр', 'режиссер','режиссеры', 'режиссёры']},
        {'tag': 'Writers', 'action': 'get_persons', 'is_list': True, 'keywords': ['сценарий', 'автор сценария']},
        {'tag': 'Artists', 'action': 'get_persons', 'is_list': True, 'keywords': ['в ролях', 'исполнители', 'актеры']},
    ]
    # pylint: enable=line-too-long

    ###
    def __init__(self, rt):
        self.rt = rt

    @staticmethod
    def __clear_html(_tid, _html):
        """Вырезает все html тэги."""
        data = re.sub('(<a[ >].*?</a>)', '', _html)
        data = re.sub('<span class="post-[a-z]">(.*?)</span>', r'\n\1\n', data)
        data = re.sub('<br>', '\n', data)
        data = re.sub('<hr class="post-hr">', '\n@eot:\n', data)
        data = RTS.RE_CLEAR.sub('', data)
        data = re.sub(r'\|', '', data)
        text = ''
        for line in data.split('\n'):
            if line:
                if line.isspace():
                    continue
                if line.startswith(':'):
                    Debug.log('r', 3, f'RTS.clear_html(#{_tid}): removing NL')
                    text = text.rstrip('\n')
                text += line.strip() + '\n'
        Debug.log('r', 3, f'RTS.clear_html(#{_tid}): text={text}')
        return unescape(text)

    ###
    @staticmethod
    def __get_countries(text):  # pylint: disable=unused-private-member
        countries = []
        # Фильтруем по списку стран
        for country in list(map(str.strip, text.split(','))):
            if country in [country['n'] for country in Scraper.COUNTRIES]:
                countries.append(country)
        return countries

    ###
    @staticmethod
    def __get_cover(_tid, _html):
        # cover
        cover = RTS.RE_COVER.search(_html)
        if not cover:
            return ''
        return cover.group(1)

    ###
    @staticmethod
    def __get_first_post(_tid, data):
        try:
            start = data.index('<div class="post_body"', 0)  # XXXX: можно начинать не с 0
        except ValueError:
            return ''
        end = start
        while True:
            try:
                end = data.index('</div>', end) + 6
            except ValueError:
                return ''
            if data.count('<div', start, end) == data.count('</div>', start, end):
                break
        Debug.log('r', 3, f'RTS.get_first_post(#{_tid}): {data[start:end]}')
        return data[start:end]

    ###
    @staticmethod
    def __get_genres(text):  # pylint: disable=unused-private-member
        # XXXX: проверить по списку жанров TMDB?
        return list(map(str.strip, text.lower().split(',')))

    ###
    @staticmethod
    def __get_imdb(_tid, _html):
        # imdbId
        imdb_id = ''
        imdb = RTS.RE_IMDB.search(_html)
        if imdb:
            imdb_id = imdb.group(1)
        elif 'imdb' in _html:
            Debug.log('r', 0, f'RTS.get_imdb(#{_tid}) imdbId FAIL')
        return imdb_id

    ###
    def __get_info_as_text(self, tid, text):
        my_info = {}
        tag = None
        for line_num, line in enumerate(text.split('\n'), 1):
            if line and line[0] in punctuation:
                line = line[1:].strip()
            if ':' in line and len(line.partition(':')[0].split()) < 4:
                is_tag = line.partition(':')[0].lower()
                if new_tag := [infotag['tag'] for infotag in RTS.INFOTAGS if is_tag in infotag.get('keywords', [])]:
                    if (
                        tag and tag not in 'Plot' and
                        tag in my_info and my_info[tag] and
                        my_info[tag][-1] in punctuation
                    ):
                        my_info[tag] = my_info[tag][0:-1].strip()
                    tag = new_tag[0]
                    my_info[tag] = line.partition(':')[2].strip()
                    dbg = f'SET {tag} to "{my_info[tag]}"'
                else:
                    tag = None
                    dbg = f'SKIP "{line}"'
            elif tag:
                if [infotag.get('is_list') for infotag in RTS.INFOTAGS if infotag['tag'] == tag][0]:
                    my_info[tag] += ', '
                my_info[tag] += line.strip()
                dbg = f'APPEND to {tag} "{line}"'
            else:
                dbg = f'SKIP "{line}"'
            Debug.log('r', 3, f'RTS.get_info_as_text(#{tid}): {line_num}: {dbg}')
        # Иногда страну пишут как Производство: Страна, ...
        if 'Studios' in my_info and 'Countries' not in my_info:
            my_info['Countries'] = my_info['Studios']
        return my_info

    ###
    @staticmethod
    def __get_kp(_tid, _html):
        # KinoPoisk
        kp_id = 0
        kp = RTS.RE_KP.search(_html)
        if kp:
            kp_id = int(kp.group(1))
        elif 'kinopoisk' in _html:
            Debug.log('r', 0, f'RTS.get_kp(#{_tid}) kpId FAIL')
        return kp_id

    ###
    @staticmethod
    def __get_persons(text):  # pylint: disable=unused-private-member
        # XXXX: роли!!!
        persons = []
        for person in list(map(str.strip, text.split(','))):
            role = ''
            if '(' in person:
                parts = person.partition('(')
                role = parts[2].partition(')')[0].strip()
                person = parts[0].strip()
            if '/' in person:
                parts = person.partition('/')
                ru_name = parts[0].strip()
                en_name = parts[2].partition('/')[0].strip()
            else:
                ru_name = person
                en_name = Scraper.to_english(ru_name)
            persons.append({'ruName': ru_name, 'enName': en_name, 'Role': role, 'img': ''})
        return persons

    ###
    @staticmethod
    def __get_studios(text):  # pylint: disable=unused-private-member
        studios = []
        for studio in list(map(str.strip, text.split(','))):
            if studio not in [country['n'] for country in Scraper.COUNTRIES]:
                studios.append(studio)
        return studios

    ###
    @staticmethod
    def __get_year(text):  # pylint: disable=unused-private-member
        if re.match(r'[12][0-9]{3}', text):
            return int(text[0:4])
        return 0

    ###
    def movie_scrape(self, tid, _html):
        """Скрапер первого поста раздачи для фильмов"""
        # Эти тэги берем из html
        my_info = {
            'kpId': self.__get_kp(tid, _html),
            'imdbId': self.__get_imdb(tid, _html),
            'Cover': self.__get_cover(tid, _html),
        }
        # Остальные из очищенного текста
        text = self.__clear_html(tid, _html)
        my_info.update(self.__get_info_as_text(tid, text))
        rts_info = Scraper.info_new()
        for tag, value in my_info.items():
            Debug.log('r', 2, f'RTS.movie_scrape(#{tid}): tag={tag}')
            action = [infotag.get('action', '') for infotag in RTS.INFOTAGS if infotag['tag'] == tag]
            if action and action[0]:
                Debug.log('r', 2, f'RTS.movie_scrape(#{tid}): action={action}')
                rts_info[tag] = getattr(self, f"_RTS__{action[0]}")(value)
            else:
                rts_info[tag] = value
        Debug.log('r', 2, f'RTS.movie_scrape(#{tid}): rts_info={rts_info}')
        return rts_info

    ###
    def scrape(self, info):
        """
        Пытается заполнить info данными из первого поста раздачи РуТрекера
        {'success': True, 'info': {}}
        """
        rts_result = {'success': False, 'info': {}}
        Debug.log('r', 3, f'RTS.scrape(#{info["Id"]})')
        response = Network.geturl(self.rt.geturl('topic', info['Id']), params=self.rt.req_params, auth=self.rt.req_auth)
        if response.status_code != 200:
            Debug.log('r', 0, f'RTS.scrape({info["Id"]}) network error')
            return rts_result
        # fid и cid
        forums = RTS.RE_CID.findall(response.text)
        if not forums:
            Debug.log('r', 0, f'RTS.scrape({info["Id"]}): no forum link')
            return rts_result
        for forum in forums:
            if cid := self.rt.getcid(int(forum)):
                break
            cid = ''
        if not cid:
            Debug.log('r', 0, f'RTS.scrape({info["Id"]}) cannot find cid')
            return rts_result
        # Первое сообщение в теме
        data = self.__get_first_post(info['Id'], response.text)
        if not data:
            Debug.log('r', 0, f'RTS.scrape(#{info["Id"]}): cannot get 1st post')
            return rts_result
        rts_result['success'] = True
        if cid in ['movies', 'serials', 'cartoons']:
            myinfo = self.movie_scrape(info['Id'], data)
        else:
            Debug.log('r', 0, f'RTS.scrape(#{info["Id"]}): bad cid')
            myinfo = info
        myinfo['Id'] = info['Id']
        myinfo['Scraper'] = Scraper.SCRAPERS['rts']
        myinfo['ruTitle'] = info['ruTitle']
        myinfo['origTitle'] = info['origTitle']
        rts_result['info'] = myinfo
        return rts_result


class Title:  # pylint: disable=too-few-public-methods
    """Скрапер заголовков раздач."""
    QUALITY = {
            '4K': ['2160p'],
            'FHD': ['1080', '1080i', '1080p'],
            '720': ['720', '720i', '720p'],
    }
    RE_CLEAR = re.compile(r'(?:^\[[^\]]+\])?(.*\).?\[[^\]]+\]).?(\[[^\]]+\])?.*$')
    RE_PARTS = re.compile(r'(.*)\[(.*)\]')

    ###
    @staticmethod
    def _movie_scrape(tid, title):
        """Парсит title фильмов, возвращает info"""
        Debug.log('r', 2, f'Title.movie_scrape(#{tid}): title={title}')
        info = Scraper.info_new()
        info['Id'] = tid
        info['Scraper'] = Scraper.SCRAPERS['title']
        # Приводим title к виду <titles and directors><tags> обрезая начальные и конечные тэги
        clear = Title.RE_CLEAR.match(title)
        if not clear:
            Debug.log('r', 0, f'Title.movie_scrape(#{tid}): cannot clear - {title}')
            info['origTitle'] = title
            return info
        Debug.log('r', 3, f'Title.movie_scrape(#{tid}): group1={clear.group(1)}')
        Debug.log('r', 3, f'Title.movie_scrape(#{tid}): group2={clear.group(2)}')
        # Разбиваем очищенный title на <titles and directors> и <tags>
        parts = Title.RE_PARTS.match(clear.group(1).strip())
        if not parts:
            Debug.log('r', 0, f'Title.movie_scrape(#{tid}): cannot split TitlesDirectors_Tags  -  {clear.group(1)}')
            info['origTitle'] = clear.group(1).strip()
            return info
        tags = parts.group(2).strip()
        if not tags[0].isdigit() and clear.group(2):
            Debug.log('r', 2, f'Title.movie_scrape(#{tid}): tags - fallback to group2')
            tags = clear.group(2)[1:-1]
        Debug.log('r', 2, f'Title.movie_scrape(#{tid}): tags={tags}')
        titles_dirs = parts.group(1).strip()
        Debug.log('r', 3, f'Title.movie_scrape(#{tid}): titles_dirs={titles_dirs}')
        # Разбиваем <titles and directors> на <titles> и <directors>
        # в <directors> попадает самое правое содержимое круглых скобок.
        split_pos = Title._split_titles_dirs(titles_dirs)
        if not split_pos:
            Debug.log('r', 0, f'Title.movie_scrape(#{tid}): cannot split TitlesDirectors - {titles_dirs}')
            info['origTitle'] = titles_dirs
            return info
        directors = titles_dirs[split_pos+1:-1].strip()
        Debug.log('r', 2, f'Title.movie_scrape(#{tid}): directors={directors}')
        titles = titles_dirs[:split_pos].strip()
        Debug.log('r', 2, f'Title.movie_scrape(#{tid}): titles={titles}')
        # Парсим по частям
        Title._parse_titles(info, titles)
        Title._parse_directors(info, directors)
        Title._parse_other(info, list(map(str.strip, tags.split(','))))
        # Фикс Countries у отечественных фильмов
        if (not info.get('Countries') and info.get('ruTitle') and not info.get('origTitle')):
            if info['Year'] >= 1924 and info['Year'] <= 1993:
                info['Countries'] = ['СССР']
            else:
                info['Countries'] = ['Россия']
        # Фикс Quality
        if not info.get('Quality'):
            info['Quality'] = 'SD'
        Debug.log('r', 2, f'Title.movie_scrape(#{tid}): info={info}')
        return info

    ###
    @staticmethod
    def _parse_directors(info, directors):
        # режиссер(ы):
        for director in list(map(str.strip, directors.split(','))):
            if '/' in director:
                info['Directors'].append({
                        'ruName': director.partition('/')[0].strip(),
                        'enName': director.partition('/')[2].strip()
                })
            elif ' и др' in director:
                info['Directors'].append({'ruName': director.split(' и др', 1)[0].strip()})
            else:
                info['Directors'].append({'ruName': director.strip()})
        Debug.log('r', 3, f'Title.parse_directors(#{info["Id"]}): info.Directors={info["Directors"]}')

    ###
    @staticmethod
    def _parse_numbers(string):
        """Парсит строки вида 123-321 или 123 в числа"""
        numbers = set()
        Debug.log('r', 3, f'Title.parse_numbers({string})')
        parts = string.lower().partition('из')[0].strip().partition('(')[0].strip().split(',')
        Debug.log('r', 3, f'Title.parse_numbers({string}): parts={parts}')
        for part in parts:
            Debug.log('r', 3, f'Title.parse_numbers({string}): part={part}')
            try:
                if '-' in part:
                    # Добавляем диапазон чисел
                    start, end = map(int, part.split('-'))
                    numbers.update(range(start, end + 1))
                else:
                    # Добавляем отдельное число
                    numbers.add(int(part))
            except ValueError:
                pass
        return sorted(numbers)

    ###
    @staticmethod
    def _parse_other(info, other):
        # год, странa, жанр, прочие тэги:
        for tag in other:
            Debug.log('r', 3, f'Title.parse_other(#{info["Id"]}): tag={tag}')
            if not info.get('Year') and Scraper.RE_YEAR.match(tag):
                info['Year'] = int(tag[0:4])
                Debug.log('r', 2, f'Title.parse_other(#{info["Id"]}): info.Year={info["Year"]}')
            elif ((tag.istitle() or tag.isupper())
                    and tag in [country['n'] for country in Scraper.COUNTRIES]
                    and not info.get('Genres')):
                info['Countries'].append(tag)
                Debug.log('r', 2, f'Title.parse_other(#{info["Id"]}): info.Coutries={info["Countries"]}')
            elif not info.get('Quality') and Scraper.is_rus(tag):
                #XXXX: завести список жанров в Scraper.
                info['Genres'].append(tag.lower())
                Debug.log('r', 2, f'Title.parse_other(#{info["Id"]}): info.Genres={info["Genres"]}')
            elif not info.get('Quality'):
                subtags = tag.split(' ')
                Debug.log('r', 3, f'Title.parse_other(#{info["Id"]}): subtags={subtags}')
                for subtag in subtags:
                    info['Quality'] = next(
                            (entry for entry, value in Title.QUALITY.items() if subtag.lower() in value),
                            None
                    )
                    if info['Quality']:
                        Debug.log('r', 2, f'Title.parse_other(#{info["Id"]}): info.Quality={info["Quality"]}')
                        break

    ###
    @staticmethod
    def _parse_serial(info, what, title):
        # Если title начинается с what=("сезон"|"серии"):
        #   то пытаемся распарсить и заполнить соответсвующие ключи в info,
        #   вне зависимости от результата парсинга возвращаем True
        # Иначе:
        #   Возвращаем False
        if title.lower().startswith(what):
            serial = title.lower().removeprefix(what).strip()
            if serial.startswith(':'):
                serial = serial[1:].strip()
            if any(char.isdigit() for char in serial):
                if series := Title._parse_numbers(serial):
                    if what in 'серии':
                        if not info['Serial']:
                            info['Serial'] = {'fromSeason': 1, 'toSeason': 1}
                        tag = 'Episode'
                    else:
                        tag = 'Season'
                    info['Serial'][f'from{tag}'] = min(series)
                    info['Serial'][f'to{tag}'] = max(series)
                    Debug.log('r', 2, f'Title.parse_serial(#{info["Id"]}): info.Serial={info["Serial"]}')
                else:
                    Debug.log('r', 1, f'Title.parse_serial(#{info["Id"]}): cannot parse {what} - {title}')
            return True
        return False

    ###
    @staticmethod
    def _parse_titles(info, titles):
        for title in list(map(str.strip, titles.split('/'))):
            Debug.log('r', 3, f'Title.parse_titles(#{info["Id"]}): title={title}')
            if Title._parse_serial(info, 'сезон', title) or Title._parse_serial(info, 'серии', title):
                continue
            if not info.get('ruTitle') and Scraper.is_rus(title):
                # Русское название.
                info['ruTitle'] =title
            else:
                if info['origTitle']:
                    info['otherTitles'].append(info['origTitle'])
                info['origTitle'] = title
        Debug.log('r', 3, f'Title.parse_titles(#{info["Id"]}): info.ruTitle={info["ruTitle"]}')
        Debug.log('r', 3, f'Title.parse_titles(#{info["Id"]}): info.origTitle={info["origTitle"]}')
        Debug.log('r', 3, f'Title.parse_titles(#{info["Id"]}): info.otherTitles={info["otherTitles"]}')

    @staticmethod
    def _split_titles_dirs(string):
        """Делит string на части, содержимое самых правых '()' считается режиссерами"""
        stack = []
        last_open = string
        last_closing_index = string.rfind(')')
        # Проходим по строке до самой правой закрывающей скобки
        for i, char in enumerate(string[:last_closing_index + 1]):
            if char == '(':
                stack.append(i)
            elif char == ')':
                if not stack:
                    return None
                last_open = stack.pop()
        return last_open

    ###
    @staticmethod
    def scrape(tid, cid, title):
        """Вызывает скрапер заголовка в соответсвии с cid"""
        Debug.log('r', 2, f'Title.scrape(#{tid}, {cid}, {title})')
        if cid in ['movies', 'serials', 'cartoons']:
            return Title._movie_scrape(tid, title)
        # Не верный cid
        Debug.log('r', 0, f'Title.scrape(#{tid}, {cid}, {title}): bad cid')
        info = Scraper.info_new()
        info['Id'] = tid
        info['Scraper'] = Scraper.SCRAPERS['title']
        info['origTitle'] = title
        return info
