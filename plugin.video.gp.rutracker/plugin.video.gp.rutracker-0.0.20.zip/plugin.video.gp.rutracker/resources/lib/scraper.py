# -*- coding: utf-8 -*-
"""Scraper module"""

import re
import string
from functools import reduce
from operator import getitem

from debug import Debug
from version import VERSIONS

class Scraper:
    """Basic scraper functions."""
    SCRAPERS = {
        'title': 0,
        'rts': 1,
        'imdb': 2,
        'tmdb': 4,
        'kp': 8
    }
    COUNTRIES = [
        {'c': 'AU', 'n': 'Австралия'},
        {'c': 'AT', 'n': 'Австрия'},
        {'c': 'AZ', 'n': 'Азербайджан'},
        {'c': 'AX', 'n': 'Аландские острова'},
        {'c': 'AL', 'n': 'Албания'},
        {'c': 'DZ', 'n': 'Алжир'},
        {'c': 'VI', 'n': 'Виргинские Острова (США)'},
        {'c': 'AS', 'n': 'Американское Самоа'},
        {'c': 'AI', 'n': 'Ангилья'},
        {'c': 'AO', 'n': 'Ангола'},
        {'c': 'AD', 'n': 'Андорра'},
        {'c': 'AQ', 'n': 'Антарктида'},
        {'c': 'AG', 'n': 'Антигуа и Барбуда'},
        {'c': 'AR', 'n': 'Аргентина'},
        {'c': 'AM', 'n': 'Армения'},
        {'c': 'AW', 'n': 'Аруба'},
        {'c': 'AF', 'n': 'Афганистан'},
        {'c': 'BS', 'n': 'Багамские Острова'},
        {'c': 'BD', 'n': 'Бангладеш'},
        {'c': 'BB', 'n': 'Барбадос'},
        {'c': 'BH', 'n': 'Бахрейн'},
        {'c': 'BZ', 'n': 'Белиз'},
        {'c': 'BY', 'n': 'Белоруссия'},
        {'c': 'BE', 'n': 'Бельгия'},
        {'c': 'BJ', 'n': 'Бенин'},
        {'c': 'BM', 'n': 'Бермуды'},
        {'c': 'BG', 'n': 'Болгария'},
        {'c': 'BO', 'n': 'Боливия'},
        {'c': 'BQ', 'n': 'Бонэйр, Синт-Эстатиус и Саба'},
        {'c': 'BA', 'n': 'Босния и Герцеговина'},
        {'c': 'BW', 'n': 'Ботсвана'},
        {'c': 'BR', 'n': 'Бразилия'},
        {'c': 'IO', 'n': 'Британская территория в Индийском океане'},
        {'c': 'VG', 'n': 'Виргинские Острова (Великобритания)'},
        {'c': 'BN', 'n': 'Бруней'},
        {'c': 'BF', 'n': 'Буркина-Фасо'},
        {'c': 'BI', 'n': 'Бурунди'},
        {'c': 'BT', 'n': 'Бутан'},
        {'c': 'VU', 'n': 'Вануату'},
        {'c': 'VA', 'n': 'Ватикан'},
        {'c': 'GB', 'n': 'Великобритания'},
        {'c': 'HU', 'n': 'Венгрия'},
        {'c': 'VE', 'n': 'Венесуэла'},
        {'c': 'UM', 'n': 'Внешние малые острова (США)'},
        {'c': 'TL', 'n': 'Восточный Тимор'},
        {'c': 'VN', 'n': 'Вьетнам'},
        {'c': 'GA', 'n': 'Габон'},
        {'c': 'HT', 'n': 'Гаити'},
        {'c': 'GY', 'n': 'Гайана'},
        {'c': 'GM', 'n': 'Гамбия'},
        {'c': 'GH', 'n': 'Гана'},
        {'c': 'GP', 'n': 'Гваделупа'},
        {'c': 'GT', 'n': 'Гватемала'},
        {'c': 'GF', 'n': 'Гвиана'},
        {'c': 'GN', 'n': 'Гвинея'},
        {'c': 'GW', 'n': 'Гвинея-Бисау'},
        {'c': 'DE', 'n': 'Германия'},
        {'c': 'GG', 'n': 'Гернси'},
        {'c': 'GI', 'n': 'Гибралтар'},
        {'c': 'HN', 'n': 'Гондурас'},
        {'c': 'HK', 'n': 'Гонконг'},
        {'c': 'GD', 'n': 'Гренада'},
        {'c': 'GL', 'n': 'Гренландия'},
        {'c': 'GR', 'n': 'Греция'},
        {'c': 'GE', 'n': 'Грузия'},
        {'c': 'GU', 'n': 'Гуам'},
        {'c': 'DK', 'n': 'Дания'},
        {'c': 'JE', 'n': 'Джерси'},
        {'c': 'DJ', 'n': 'Джибути'},
        {'c': 'DM', 'n': 'Доминика'},
        {'c': 'DO', 'n': 'Доминиканская Республика'},
        {'c': 'CD', 'n': 'ДР Конго'},
        {'c': 'AN', 'n': 'Нидерландские Антильские Острова'},
        {'c': 'EG', 'n': 'Египет'},
        {'c': 'ZM', 'n': 'Замбия'},
        {'c': 'EH', 'n': 'САДР'},
        {'c': 'ZW', 'n': 'Зимбабве'},
        {'c': 'IL', 'n': 'Израиль'},
        {'c': 'IN', 'n': 'Индия'},
        {'c': 'ID', 'n': 'Индонезия'},
        {'c': 'JO', 'n': 'Иордания'},
        {'c': 'IQ', 'n': 'Ирак'},
        {'c': 'IR', 'n': 'Иран'},
        {'c': 'IE', 'n': 'Ирландия'},
        {'c': 'IS', 'n': 'Исландия'},
        {'c': 'ES', 'n': 'Испания'},
        {'c': 'IT', 'n': 'Италия'},
        {'c': 'YE', 'n': 'Йемен'},
        {'c': 'CV', 'n': 'Кабо-Верде'},
        {'c': 'KZ', 'n': 'Казахстан'},
        {'c': 'KY', 'n': 'Острова Кайман'},
        {'c': 'KH', 'n': 'Камбоджа'},
        {'c': 'CM', 'n': 'Камерун'},
        {'c': 'CA', 'n': 'Канада'},
        {'c': 'QA', 'n': 'Катар'},
        {'c': 'KE', 'n': 'Кения'},
        {'c': 'CY', 'n': 'Кипр'},
        {'c': 'KG', 'n': 'Киргизия'},
        {'c': 'KI', 'n': 'Кирибати'},
        {'c': 'TW', 'n': 'Тайвань'},
        {'c': 'KP', 'n': 'КНДР'},
        {'c': 'CN', 'n': 'Китай'},
        {'c': 'CC', 'n': 'Кокосовые острова'},
        {'c': 'CO', 'n': 'Колумбия'},
        {'c': 'KM', 'n': 'Коморы'},
        {'c': 'CR', 'n': 'Коста-Рика'},
        {'c': 'CI', 'n': 'Кот-д’Ивуар'},
        {'c': 'CU', 'n': 'Куба'},
        {'c': 'KW', 'n': 'Кувейт'},
        {'c': 'CW', 'n': 'Кюрасао'},
        {'c': 'LA', 'n': 'Лаос'},
        {'c': 'LV', 'n': 'Латвия'},
        {'c': 'LS', 'n': 'Лесото'},
        {'c': 'LR', 'n': 'Либерия'},
        {'c': 'LB', 'n': 'Ливан'},
        {'c': 'LY', 'n': 'Ливия'},
        {'c': 'LT', 'n': 'Литва'},
        {'c': 'LI', 'n': 'Лихтенштейн'},
        {'c': 'LU', 'n': 'Люксембург'},
        {'c': 'MU', 'n': 'Маврикий'},
        {'c': 'MR', 'n': 'Мавритания'},
        {'c': 'MG', 'n': 'Мадагаскар'},
        {'c': 'YT', 'n': 'Майотта'},
        {'c': 'MO', 'n': 'Макао'},
        {'c': 'MK', 'n': 'Северная Македония'},
        {'c': 'MW', 'n': 'Малави'},
        {'c': 'MY', 'n': 'Малайзия'},
        {'c': 'ML', 'n': 'Мали'},
        {'c': 'MV', 'n': 'Мальдивы'},
        {'c': 'MT', 'n': 'Мальта'},
        {'c': 'MA', 'n': 'Марокко'},
        {'c': 'MQ', 'n': 'Мартиника'},
        {'c': 'MH', 'n': 'Маршалловы Острова'},
        {'c': 'MX', 'n': 'Мексика'},
        {'c': 'FM', 'n': 'Микронезия'},
        {'c': 'MZ', 'n': 'Мозамбик'},
        {'c': 'MD', 'n': 'Молдавия'},
        {'c': 'MC', 'n': 'Монако'},
        {'c': 'MN', 'n': 'Монголия'},
        {'c': 'MS', 'n': 'Монтсеррат'},
        {'c': 'MM', 'n': 'Мьянма'},
        {'c': 'NA', 'n': 'Намибия'},
        {'c': 'NR', 'n': 'Науру'},
        {'c': 'NP', 'n': 'Непал'},
        {'c': 'NE', 'n': 'Нигер'},
        {'c': 'NG', 'n': 'Нигерия'},
        {'c': 'NL', 'n': 'Нидерланды'},
        {'c': 'NI', 'n': 'Никарагуа'},
        {'c': 'NU', 'n': 'Ниуэ'},
        {'c': 'NZ', 'n': 'Новая Зеландия'},
        {'c': 'NC', 'n': 'Новая Каледония'},
        {'c': 'NO', 'n': 'Норвегия'},
        {'c': 'AE', 'n': 'ОАЭ'},
        {'c': 'OM', 'n': 'Оман'},
        {'c': 'BV', 'n': 'Остров Буве'},
        {'c': 'IM', 'n': 'Остров Мэн'},
        {'c': 'CK', 'n': 'Острова Кука'},
        {'c': 'NF', 'n': 'Остров Норфолк'},
        {'c': 'CX', 'n': 'Остров Рождества'},
        {'c': 'PN', 'n': 'Острова Питкэрн'},
        {'c': 'SH', 'n': 'Острова Святой Елены, Вознесения и Тристан-да-Кунья'},
        {'c': 'PK', 'n': 'Пакистан'},
        {'c': 'PW', 'n': 'Палау'},
        {'c': 'PS', 'n': 'Палестина'},
        {'c': 'PA', 'n': 'Панама'},
        {'c': 'PG', 'n': 'Новая Гвинея'},
        {'c': 'PY', 'n': 'Парагвай'},
        {'c': 'PE', 'n': 'Перу'},
        {'c': 'PL', 'n': 'Польша'},
        {'c': 'PT', 'n': 'Португалия'},
        {'c': 'PR', 'n': 'Пуэрто-Рико'},
        {'c': 'CG', 'n': 'Республика Конго'},
        {'c': 'KR', 'n': 'Республика Корея'},
        {'c': 'RE', 'n': 'Реюньон'},
        {'c': 'RU', 'n': 'Россия'},
        {'c': 'RW', 'n': 'Руанда'},
        {'c': 'RO', 'n': 'Румыния'},
        {'c': 'SV', 'n': 'Сальвадор'},
        {'c': 'WS', 'n': 'Самоа'},
        {'c': 'SM', 'n': 'Сан-Марино'},
        {'c': 'ST', 'n': 'Сан-Томе и Принсипи'},
        {'c': 'SA', 'n': 'Саудовская Аравия'},
        {'c': 'SZ', 'n': 'Эсватини'},
        {'c': 'MP', 'n': 'Северные Марианские Острова'},
        {'c': 'SC', 'n': 'Сейшельские Острова'},
        {'c': 'BL', 'n': 'Сен-Бартелеми'},
        {'c': 'MF', 'n': 'Сен-Мартен'},
        {'c': 'PM', 'n': 'Сен-Пьер и Микелон'},
        {'c': 'SN', 'n': 'Сенегал'},
        {'c': 'VC', 'n': 'Сент-Винсент и Гренадины'},
        {'c': 'KN', 'n': 'Сент-Китс и Невис'},
        {'c': 'LC', 'n': 'Сент-Люсия'},
        {'c': 'RS', 'n': 'Сербия'},
        {'c': 'SG', 'n': 'Сингапур'},
        {'c': 'SX', 'n': 'Синт-Мартен'},
        {'c': 'SY', 'n': 'Сирия'},
        {'c': 'SK', 'n': 'Словакия'},
        {'c': 'SI', 'n': 'Словения'},
        {'c': 'SB', 'n': 'Соломоновы Острова'},
        {'c': 'SO', 'n': 'Сомали'},
        {'c': 'SD', 'n': 'Судан'},
        {'c': 'SR', 'n': 'Суринам'},
        {'c': 'US', 'n': 'США'},
        {'c': 'SL', 'n': 'Сьерра-Леоне'},
        {'c': 'TJ', 'n': 'Таджикистан'},
        {'c': 'TH', 'n': 'Таиланд'},
        {'c': 'TZ', 'n': 'Танзания'},
        {'c': 'TC', 'n': 'Теркс и Кайкос'},
        {'c': 'TG', 'n': 'Того'},
        {'c': 'TK', 'n': 'Токелау'},
        {'c': 'TO', 'n': 'Тонга'},
        {'c': 'TT', 'n': 'Тринидад и Тобаго'},
        {'c': 'TV', 'n': 'Тувалу'},
        {'c': 'TN', 'n': 'Тунис'},
        {'c': 'TM', 'n': 'Туркмения'},
        {'c': 'TR', 'n': 'Турция'},
        {'c': 'UG', 'n': 'Уганда'},
        {'c': 'UZ', 'n': 'Узбекистан'},
        {'c': 'UA', 'n': 'Украина'},
        {'c': 'WF', 'n': 'Уоллис и Футуна'},
        {'c': 'UY', 'n': 'Уругвай'},
        {'c': 'FO', 'n': 'Фареры'},
        {'c': 'FJ', 'n': 'Фиджи'},
        {'c': 'PH', 'n': 'Филиппины'},
        {'c': 'FI', 'n': 'Финляндия'},
        {'c': 'FK', 'n': 'Фолклендские острова'},
        {'c': 'FR', 'n': 'Франция'},
        {'c': 'PF', 'n': 'Французская Полинезия'},
        {'c': 'TF', 'n': 'Французские Южные и Антарктические Территории'},
        {'c': 'HM', 'n': 'Херд и Макдональд'},
        {'c': 'HR', 'n': 'Хорватия'},
        {'c': 'CF', 'n': 'ЦАР'},
        {'c': 'TD', 'n': 'Чад'},
        {'c': 'ME', 'n': 'Черногория'},
        {'c': 'CZ', 'n': 'Чехия'},
        {'c': 'CL', 'n': 'Чили'},
        {'c': 'CH', 'n': 'Швейцария'},
        {'c': 'SE', 'n': 'Швеция'},
        {'c': 'SJ', 'n': 'Флаг Шпицбергена и Ян-Майена Шпицберген и Ян-Майен'},
        {'c': 'LK', 'n': 'Шри-Ланка'},
        {'c': 'EC', 'n': 'Эквадор'},
        {'c': 'GQ', 'n': 'Экваториальная Гвинея'},
        {'c': 'ER', 'n': 'Эритрея'},
        {'c': 'EE', 'n': 'Эстония'},
        {'c': 'ET', 'n': 'Эфиопия'},
        {'c': 'ZA', 'n': 'ЮАР'},
        {'c': 'GS', 'n': 'Южная Георгия и Южные Сандвичевы Острова'},
        {'c': 'SS', 'n': 'Южный Судан'},
        {'c': 'JM', 'n': 'Ямайка'},
        {'c': 'JP', 'n': 'Япония'},
    ]
    UPPER_LETTERS = {
        'А': 'A', 'Б': 'B', 'В': 'V', 'Г': 'G', 'Д': 'D', 'Е': 'E',
        'Ё': 'Yo', 'Ж': 'Zh', 'З': 'Z', 'И': 'I', 'Й': 'Y', 'К': 'K',
        'Л': 'L', 'М': 'M', 'Н': 'N', 'О': 'O', 'П': 'P', 'Р': 'R',
        'С': 'S', 'Т': 'T', 'У': 'U', 'Ф': 'F', 'Х': 'Kh', 'Ц': 'Ts',
        'Ч': 'Ch', 'Ш': 'Sh', 'Щ': 'Shch', 'Ъ': '', 'Ы': 'Y', 'Ь': '',
        'Э': 'E', 'Ю': 'Yu', 'Я': 'Ya'
    }
    LOWER_LETTERS = {
        'а': 'a', 'б': 'b', 'в': 'v', 'г': 'g', 'д': 'd', 'е': 'e',
        'ё': 'yo', 'ж': 'zh', 'з': 'z', 'и': 'i', 'й': 'y', 'к': 'k',
        'л': 'l', 'м': 'm', 'н': 'n', 'о': 'o', 'п': 'p', 'р': 'r',
        'с': 's', 'т': 't', 'у': 'u', 'ф': 'f', 'х': 'kh', 'ц': 'ts',
        'ч': 'ch', 'ш': 'sh', 'щ': 'shch', 'ъ': '', 'ы': 'y', 'ь': '',
        'э': 'e', 'ю': 'yu', 'я': 'ya'
    }
    RE_LAT = re.compile(r'[A-Za-z]')
    RE_RUS = re.compile(r'[А-Яа-яЁё]')
    RE_YEAR = re.compile(r'[12][0-9]{3}')
    TRANSLATOR = str.maketrans('', '', string.punctuation + '«»')

    @staticmethod
    def __merge_persons(orig, diff):
        """Объединяет описания людей (Режиссеры, Сценаристы, Артисты)"""
        Debug.log('S', 3, f'Scraper.merge_persons(): orig={orig}')
        Debug.log('S', 3, f'Scraper.merge_persons(): diff={diff}')
        new = []
        for person in diff:
            Debug.log('S', 3, f'Scraper.merge_persons(): person={person}')
            #
            oid = None
            if person.get('ruName'):
                oid = next((item for item in orig if item.get('ruName', '').lower() == person.get('ruName').lower()), None) # pylint: disable=line-too-long
                if not oid:
                    oid = next((item for item in orig if Scraper.to_english(person.get('ruName', '').lower()) == item.get('enName', '').lower()), None) # pylint: disable=line-too-long
            if person.get('enName') and not oid:
                oid = next((item for item in orig if item.get('enName', '').lower() == person.get('enName').lower()), None) # pylint: disable=line-too-long
                if not oid:
                    oid = next((item for item in orig if Scraper.to_english(item.get('ruName', '')).lower() == person.get('enName').lower()), None) # pylint: disable=line-too-long
            if oid:
                Debug.log('S', 3, f'Scraper.merge_persons():    oid={oid}')
                merged = person
                for tag in ['ruName', 'enName', 'Gender', 'img', 'Role']:
                    if oid.get(tag) and not person.get(tag):
                        merged[tag] = oid[tag]
                Debug.log('S', 3, f'Scraper.merge_persons(): merged={merged}')
                new.append(merged)
            else:
                new.append(person)
        Debug.log('S', 3, f'Scraper.merge_persons():  new={new}')
        return new

    ###
    @staticmethod
    def get_person_name(person):
        """Возвращает имя человека, преимущество русскому языку."""
        if person['ruName']:
            return person['ruName']
        return person['enName']

    ###
    @staticmethod
    def info_new():
        """Возвращает пустой словарь info"""
        return {
                'Id': 0,
                'kpId': 0,
                'imdbId': '',
                'ruTitle': '',
                'origTitle': '',
                'otherTitles': [],
                'Year': 0,
                'Cover': '',
                'Plot': '',
                'Studios': [],
                'Countries': [],
                'Genres': [],
                'Directors': [],
                'Writers': [],
                'Artists': [],
                'Serial': {},
                'Extra': {},
                'Quality': '',
                'Scraper': 0,
                'Version': VERSIONS['INFO'],
                'Success': False
        }

    ###
    @staticmethod
    def is_lat(text):
        """Определяет есть ли в text латиница"""
        if text:
            return re.search(Scraper.RE_LAT, text)
        return None

    ###
    @staticmethod
    def is_rus(text):
        """Определяет является text русской"""
        if text:
            return re.search(Scraper.RE_RUS, text)
        return None

    ###
    @staticmethod
    def is_same(orig, diff):
        """Определяет, что orig и diff содержат информацию об одном и том же видео"""
        verdict = 0
        # Названия.
        titles = [title for title in list(set(
            [
                orig.get('ruTitle', ''),
                Scraper.title_cleanup(orig.get('ruTitle', '')),
                orig.get('origTitle', ''),
                Scraper.title_cleanup(orig.get('origTitle', ''))
            ] + orig.get('otherTitles', []) +
            [
                Scraper.title_cleanup(other) for other in orig.get('otherTitles', [])
            ])) if title
        ]
        Debug.log('S', 3, f'Scraper.is_same(#{orig["Id"]}): titles={titles}')
        for tag in ['ruTitle', 'origTitle']:
            if (title := diff.get(tag)) and (
                title in titles or Scraper.title_cleanup(title) in titles
            ):
                verdict += 25
        verdict += 10 if verdict > 25 else 5 if verdict == 25 else 0
        Debug.log('S', 3, f'Scraper.is_same(#{orig["Id"]}): title {verdict}')
        # Год (может отличаться на +- 2).
        if orig.get('Year') and diff.get('Year'):
            if orig.get('Year') == diff.get('Year'):
                verdict += 15
            elif orig.get('Year') in [diff.get('Year') + 1, diff.get('Year') - 1]:
                verdict += 10
            elif orig.get('Year') in [diff.get('Year') + 2, diff.get('Year') - 2]:
                verdict += 5
        verdict += 10 if verdict >= 40 else 5 if verdict >= 35 else 0
        Debug.log('S', 3,
                f'Scraper.is_same(#{orig["Id"]}):'
                f' diff year {diff.get("Year")},'
                f' orig year {orig.get("Year")}: {verdict}'
        )
        # Режессеры.
        directors = [director for director in list(set(
            [director.get('ruName', '') for director in orig.get('Directors', [])] +
            [director.get('enName', '') for director in orig.get('Directors', [])] +
            [Scraper.name_cleanup(director.get('ruName', ''))
                for director in orig.get('Directors', [])
            ] + [Scraper.name_cleanup(director.get('enName', ''))
                for director in orig.get('Directors', [])
            ])) if director
        ]
        Debug.log('S', 3, f'Scraper.is_same(#{orig["Id"]}): orig directors={directors}')
        for director in diff.get('Directors', []):
            names = [name for name in list(set(
                    [
                        director.get('ruName', ''),
                        Scraper.name_cleanup(director.get('ruName', '')),
                        director.get('enName', ''),
                        Scraper.name_cleanup(director.get('enName', ''))
                    ]
                )) if name
            ]
            Debug.log('S', 3, f'Scraper.is_same(#{orig["Id"]}): diff names={names}')
            for name in names:
                if name in directors:
                    verdict += 20
            # Добавляем еще 10 за каждое совпадение.
            verdict += 10 if verdict >= 55 else 0
        if not orig.get('Directors') and diff.get('Directors'):
            verdict += 20
        Debug.log('S', 3, f'Scraper.is_same(#{orig["Id"]}): director {verdict}')
        Debug.log('S', 3, f'Scraper.is_same(#{orig["Id"]}): verdict {verdict}')
        Debug.log('S', 1, f'Scraper.is_same(#{orig["Id"]}): {verdict > 55}')
        return verdict > 55

    ###
    @staticmethod
    def is_success(info):
        """Check {info} and set info['Success']."""
        success = True
        if (not info.get('ruTitle') and not info.get('origTitle')):
            # нужно хотя бы одно название
            Debug.log('S', 1, f'Scraper.is_success({info["Id"]}): need ruTitle or origTitle')
            success = False
        if success and (not info.get('kpId') and not info.get('imdbId')):
            # нужен хотя бы один Id
            Debug.log('S', 1, f'Scraper.is_success({info["Id"]}): need kpId or imdbId')
            success = False
        if success:
            # все остальные тэги кроме otherTtiles, Serial, Studios, Writers и Extra обязательны
            for tag in ['Year', 'Cover', 'Plot', 'Countries', 'Genres', 'Directors', 'Artists']:
                if not info.get(tag):
                    Debug.log('S', 1, f'Scraper.is_success({info["Id"]}): empty {tag}')
                    success = False
                    break
        info['Success'] = success
        return success

    @staticmethod
    def merge(orig, diff):
        """Сливает orig и diff"""
        Debug.log('S', 3, f'Scraper.merge({orig["Id"]}): {[key for key, value in Scraper.SCRAPERS.items() if value & orig["Scraper"]]} with {[key for key, value in Scraper.SCRAPERS.items() if value & diff["Scraper"]]}') # pylint: disable=line-too-long
        Debug.log('S', 3, f'Scraper.merge({orig["Id"]}): orig={orig}')
        Debug.log('S', 3, f'Scraper.merge({orig["Id"]}): diff={diff}')
        new = Scraper.info_new()
        for tag in list(new.keys()):
            if tag in ['Artists', 'Directors', 'Writers']:
                if diff[tag] and orig[tag]:
                    Debug.log('S', 3, f'Scraper.merge({orig["Id"]}) merge {tag}')
                    new[tag] = Scraper.__merge_persons(orig[tag], diff[tag])
                elif diff[tag]:
                    new[tag] = diff.get(tag, [])
                else:
                    new[tag] = orig.get(tag, [])
            elif 'Title' in tag:
                if tag == 'otherTitles':
                    # Объединяем.
                    new['otherTitles'] = list(set(orig['otherTitles'] +
                            [other for other in diff['otherTitles'] if other.lower() not in
                                [other.lower() for other in orig['otherTitles']]
                            ]
                    ))
                else:
                    # Сохраняем названия РуТрекера.
                    new[tag] = orig[tag]
            else:
                if (orig.get(tag) and diff.get(tag)) or diff.get(tag):
                    new[tag] = diff[tag]
                elif orig.get(tag):
                    new[tag] = orig[tag]
        new['Scraper'] = orig['Scraper'] | diff['Scraper']
        Debug.log('S', 3, f'Scraper.merge({orig["Id"]}): new={new}')
        Scraper.is_success(new)
        return new

    ###
    @staticmethod
    def name_cleanup(name):
        """Преобразует name в нижний регистр с заменой ё на е и вырезает знаки пунктуации."""
        return Scraper.title_cleanup(name)

    ###
    @staticmethod
    def nested_get(data_dict, map_keys, default=None):
        """Итерация по вложенным словарям"""
        ret = default
        try:
            ret = reduce(getitem, map_keys, data_dict)
        except (KeyError, TypeError, IndexError):
            return default
        if not ret:
            return default
        return ret

    ###
    @staticmethod
    def title_cleanup(title):
        """Преобразует title в нижний регистр с заменой ё на е и вырезает знаки пунктуации."""
        return ' '.join(title.lower().replace('ё', 'е').translate(Scraper.TRANSLATOR).split())

    @staticmethod
    def to_english(text):
        """Меняет все русские символы в text на транслит"""
        english = ''
        text_len = len(text)
        for index, char in enumerate(text, 1):
            repl = Scraper.LOWER_LETTERS.get(char)
            if repl is not None:
                english += repl
                continue
            repl = Scraper.UPPER_LETTERS.get(char)
            if repl is not None:
                if text_len > index:
                    if text[index] not in Scraper.LOWER_LETTERS:
                        repl = repl.upper()
                else:
                    repl = repl.upper()
            else:
                repl = char
            english += repl
        return english
